// ============================================================
// Watercolor Library v1.0
// ============================================================
// Factory-style library for embedding multiple independent
// watercolor simulations in a single page. Based on:
//   Curtis, Anderson, Seims, Fleischer & Salesin (1997).
//   "Computer-Generated Watercolor." SIGGRAPH '97.
// Implementation history: see watercolor-v0.26.2.html for the
// single-instance version with full UI.
//
// Usage:
//   const inst = Watercolor.create(targetEl, options);
//   inst.setBackground('sunset');
//   inst.splash('bigSplash');
//   inst.destroy();
//
// Each create() call mounts a fresh <canvas> inside targetEl
// and gives back an instance handle with the full Watercolor
// API (less features deferred to v2: WebGL render, text/SVG
// painting, cursor API, perf overlay).
//
// State isolation is via closure semantics — every variable
// declared inside create() is unique to that invocation, so
// the existing sim functions Just Work without any instance-
// passing rewrite. The sim core is the same code that ships
// in watercolor-v0.26.2.html.
// ============================================================

(function () {
"use strict";

function createInstance(targetEl, options) {
options = options || {};

// ----- Canvas + render-canvas setup, per instance -----
// The display canvas mounts inside targetEl. Its size is
// determined by targetEl's bounding rect at creation time;
// resizing the target later requires calling instance.resize().
const canvas = document.createElement('canvas');
// v0.55 — Default cursor:none on the canvas. Hosts that want a custom
// brush-preview cursor (claude.ai uses one) toggle the default cursor
// off so their JS-positioned ring is the only visible cursor. Hosts
// that DON'T need a custom cursor can override via CSS:
//     #my-host canvas { cursor: default; }
// Without this default, the browser shows crosshair on <canvas>
// elements (historic default) which bleeds through transparent
// preview rings.
canvas.style.cssText =
  'display:block;position:absolute;inset:0;width:100%;height:100%;' +
  'touch-action:none;cursor:none;';
targetEl.appendChild(canvas);

// Stub elements for UI references that the original code expects
// to exist. In library mode these don't get displayed; the stubs
// keep code that reads/writes them from throwing.
const _stubElement = {
  value: '', textContent: '', hidden: true, disabled: false,
  ariaPressed: 'false',
  classList: { toggle(){}, add(){}, remove(){}, contains(){ return false; } },
  style: new Proxy({}, { set(){ return true; }, get(){ return ''; } }),
  dataset: {},
  addEventListener(){}, removeEventListener(){},
  setAttribute(){}, getAttribute(){ return null; },
  appendChild(){}, removeChild(){}, replaceChildren(){},
  click(){}, focus(){}, blur(){},
  children: [], parentNode: null, parentElement: null,
  width: 56, height: 56,
  getContext(){ return null; },
  getBoundingClientRect(){
    const r = targetEl.getBoundingClientRect();
    return { left: r.left, top: r.top, right: r.right, bottom: r.bottom,
             width: r.width, height: r.height, x: r.left, y: r.top };
  },
};

// Per-instance state for things that the original code reads from
// the global window/document. We provide shims so original code
// can call them without modification.
const instanceWindow = {
  get innerWidth()  { return targetEl.getBoundingClientRect().width; },
  get innerHeight() { return targetEl.getBoundingClientRect().height; },
  devicePixelRatio: window.devicePixelRatio || 1,
};
function getById(id) {
  if (id === 'canvas') return canvas;
  return _stubElement;
}

// Backwards-compat alias used throughout the sim code. The original
// code says `window.innerWidth` etc. — we shadow with our instance
// versions to size the grid to the target element.
const _innerWidth  = () => instanceWindow.innerWidth;
const _innerHeight = () => instanceWindow.innerHeight;

"use strict";

// ============================================================
// PIGMENT DATA — from Figure 5 of Curtis et al. 1997
// K, S coefficients given per RGB channel; rho = density,
// omega = staining power, gamma = granulation.
// ============================================================
// v0.37 — Two pigment sets. PIGMENTS_TRANSPARENT is the canonical
// Curtis et al. (1997) Figure 5 watercolor data, used by default and
// for the "transparent" half of any future mixed workflow. The pigment
// works by passing light through itself and selectively absorbing —
// the paper underneath is what reflects color back. This means
// transparent pigments are nearly invisible on dark paper (no light
// to filter).
//
// PIGMENTS_OPAQUE is the gouache-equivalent set: high scattering (S)
// across the board so the pigment particles themselves reflect light
// regardless of background. Tuned to be vibrant on near-black paper
// while remaining recognizably the same three colors. K/S ratios
// (v0.38, more saturated than v0.37 initial values):
//   rose:   ~0.002 / 3.0  / 0.82  → R ≈ 0.96, 0.13, 0.30  (saturated magenta-pink)
//   yellow: ~0.0005 / 0.0036 / 4.0 → R ≈ 0.97, 0.92, 0.10 (electric yellow)
//   blue:   ~3.0   / 0.60 / 0.002 → R ≈ 0.13, 0.35, 0.96  (saturated cerulean)
// Density bumped further (real gouache settles aggressively); staining
// and granulation stay reduced since gouache sits on the surface.
//
// The active set is referenced through the mutable `PIGMENTS` variable
// below. Hot loops cache `PIGMENTS[i]` to local const at function
// entry, so swapping the reference costs nothing per-cell — only the
// WebGL uniforms need an explicit re-upload, and the next render needs
// to be forced full so already-deposited pigment recomposites correctly.
const PIGMENTS_TRANSPARENT = [
  {
    name: 'Quinacridone Rose',
    K: [0.22, 1.47, 0.57],
    S: [0.05, 0.003, 0.03],
    density: 0.02, staining: 5.5, granulation: 0.81
  },
  {
    name: 'Hansa Yellow',
    K: [0.06, 0.21, 1.78],
    S: [0.50, 0.88, 0.009],
    density: 0.06, staining: 1.0, granulation: 0.08
  },
  {
    name: 'Cerulean Blue',
    K: [1.52, 0.32, 0.25],
    S: [0.06, 0.26, 0.40],
    // Note: Figure 5 of the paper lists Cerulean Blue with staining ω=1.0
    // and granulation γ=0.31. That's physically authentic — real cerulean
    // is famously a non-staining "lifting" pigment that walks out to the
    // edges of a wash, leaving a ring. For visual consistency with
    // Quinacridone Rose (ω=5.5, γ=0.81), we raise both here so deposited
    // blue stays where it lands rather than migrating. K, S, density
    // unchanged, so the color and overall deposition rate match the
    // paper's Cerulean. If you want an authentic *staining* blue
    // instead, the paper's French Ultramarine (ω=3.1, γ=0.91) is a
    // drop-in candidate.
    density: 0.01, staining: 5.0, granulation: 0.75
  }
];
const PIGMENTS_OPAQUE = [
  {
    // v0.38 — more vibrant. Targets R ≈ [0.96, 0.13, 0.30] →
    // saturated magenta-pink instead of the v0.37 dusty rose.
    // v0.39 — density bumped 0.08 → 0.20 for thicker per-stamp
    // deposition (gouache builds opaque faster than watercolor).
    name: 'Opaque Rose',
    K: [0.005, 7.5, 2.04],
    S: [2.5, 2.5, 2.5],
    density: 0.20, staining: 1.5, granulation: 0.10
  },
  {
    // v0.38 — more vibrant. Targets R ≈ [0.97, 0.92, 0.10] →
    // electric/lemon yellow.
    // v0.39 — density 0.10 → 0.22. Yellow takes slightly more
    // density than rose/blue because its visual saturation peaks
    // later (both red AND green channels contribute, so a thin
    // stroke reads as washed-out cream rather than full yellow).
    name: 'Opaque Yellow',
    K: [0.0012, 0.009, 10.0],
    S: [2.5, 2.5, 2.5],
    density: 0.22, staining: 1.0, granulation: 0.05
  },
  {
    // v0.38 — more vibrant. Targets R ≈ [0.13, 0.35, 0.96] →
    // saturated cerulean / electric blue.
    // v0.39 — density bumped 0.08 → 0.20.
    name: 'Opaque Blue',
    K: [7.5, 1.51, 0.005],
    S: [2.5, 2.5, 2.5],
    density: 0.20, staining: 1.5, granulation: 0.10
  }
];
// Active set — reassigned by gouacheMode(true|false). All read sites
// in the lib reference this name; swapping the binding swaps the
// physics across the whole engine.
let PIGMENTS = PIGMENTS_TRANSPARENT;

// v0.51 — Auto-LERP between transparent and opaque sets based on the
// darkness of the paper. Physically motivated: light hitting a
// transparent pigment passes through, bounces off the paper, and
// comes back through the pigment (so the paper color dominates).
// Light hitting an opaque pigment scatters off the particles
// themselves (so the paper barely matters). For a sheet that's
// somewhere between white and black, the optically correct medium
// is somewhere between fully-transparent and fully-opaque — a
// mixture of scattering and non-scattering particles. Linear LERP
// of K, S, density, staining, and granulation between the two
// pigment sets approximates this mixture.
//
// PIGMENTS_LERPED is the third "active" array. When gouacheMode is
// 'auto', PIGMENTS points here, and the contents are recomputed
// every time paperColor() changes via _recomputeLerpedPigments().
// Same shape as the other two arrays so all read sites (CPU loops,
// GPU uniform upload, swatch rendering, rainbow color) just work.
const PIGMENTS_LERPED = [
  {
    name: 'Quinacridone Rose (auto)',
    K: [0, 0, 0],
    S: [0, 0, 0],
    density: 0, staining: 0, granulation: 0
  },
  {
    name: 'Hansa Yellow (auto)',
    K: [0, 0, 0],
    S: [0, 0, 0],
    density: 0, staining: 0, granulation: 0
  },
  {
    name: 'Cerulean Blue (auto)',
    K: [0, 0, 0],
    S: [0, 0, 0],
    density: 0, staining: 0, granulation: 0
  },
];

// v0.51 — Current LERP amount when in auto mode. 0 = pure transparent,
// 1 = pure opaque. Exposed via gouacheLerpAmount() for inspection.
// Always reflects the value most recently used to populate
// PIGMENTS_LERPED, even when auto mode is not active (so it's safe
// to read at any time).
let _gouacheLerpT = 0;

// Compute paper darkness ∈ [0, 1] from the current paper RGB. Uses
// Rec. 709 luminance weights (matching modern display gamut math)
// and inverts so 0 = white paper, 1 = black paper. The base paper
// color is read fresh on every call; the per-cell paper texture noise
// is not factored in (it averages to zero and would only add jitter).
function _paperDarkness() {
  // Rec. 709 luminance
  const L = 0.2126 * PAPER_R_BASE + 0.7152 * PAPER_G_BASE + 0.0722 * PAPER_B_BASE;
  const d = 1 - L;
  return d < 0 ? 0 : d > 1 ? 1 : d;
}

// Recompute PIGMENTS_LERPED contents at the given LERP amount t∈[0,1].
// t is clamped defensively. After this call, every read of PIGMENTS[i].K
// etc. will return the LERPed value on the next frame.
function _recomputeLerpedPigments(t) {
  if (t < 0) t = 0; else if (t > 1) t = 1;
  _gouacheLerpT = t;
  const a = PIGMENTS_TRANSPARENT;
  const b = PIGMENTS_OPAQUE;
  const out = PIGMENTS_LERPED;
  for (let i = 0; i < 3; i++) {
    for (let c = 0; c < 3; c++) {
      out[i].K[c] = a[i].K[c] + (b[i].K[c] - a[i].K[c]) * t;
      out[i].S[c] = a[i].S[c] + (b[i].S[c] - a[i].S[c]) * t;
    }
    out[i].density     = a[i].density     + (b[i].density     - a[i].density)     * t;
    out[i].staining    = a[i].staining    + (b[i].staining    - a[i].staining)    * t;
    out[i].granulation = a[i].granulation + (b[i].granulation - a[i].granulation) * t;
  }
}

// A sentinel for the water brush — selectable like a pigment, but adds
// only water + pressure + a localized lift of deposited pigment. Kept
// out of the PIGMENTS array so KM compositing and swatch loops aren't
// forced to special-case a non-pigment entry.
const WATER_INDEX = -1;
// A sentinel for the lift (subtract) brush — removes pigment from the
// paper at touched cells, leaving water and pressure alone. The water
// brush already lifts in the sense of re-suspending d → g, but it
// doesn't reduce the total pigment on the page; this one does.
const LIFT_INDEX  = -2;
// A sentinel for the rainbow brush — deposits a time-varying mixture
// of all three pigments. The deposit weights cycle rose → yellow →
// blue → rose with one stop every RAINBOW_STOP_MS, so a continuous
// stroke smears through the full pigment cycle. See rainbowWeights().
const RAINBOW_INDEX = -3;
const RAINBOW_PERIOD_MS = 2250;
const RAINBOW_STOP_MS   = 750;
// A sentinel for the masking-fluid brush (v0.13). Real-world masking
// fluid is liquid latex that paints on, dries to a rubbery film, and
// resists water/pigment until rubbed off. Painting reveals the paper
// underneath. In this sim we model it as a binary-ish layer:
//   • paintAt with this index deposits mask into a `mask[]` array.
//   • Cells where mask[i] > MASK_THRESHOLD are FROZEN — every sim
//     pass (paint, flow, evaporation, fade) skips them, preserving
//     whatever state was there when the mask landed.
//   • Render shows masked cells with a pale-yellow tint so the user
//     can see what they've reserved.
//   • A "Remove mask" button zeroes the array, revealing the frozen
//     state — pristine paper if mask was painted first, or whatever
//     pigment was there if it was painted over.
// maskActive is set whenever mask is deposited and cleared when the
// array is zeroed. Hot loops check maskActive first so the per-cell
// mask read is skipped entirely when no mask exists.
const MASK_INDEX = -4;

// v0.32 — Paper brush. The pigment-sentinel approach (alongside
// WATER_INDEX, LIFT_INDEX, etc.) for painting the *paper color* over
// the canvas. Used by obliterate's 'paper' mode and exposed as a
// regular brush via the 'paper' name. Painting clears deposited +
// suspended pigment in the brush footprint and adds wetness, so the
// cell renders as clean paper (whatever paperColor() returns) with a
// slight wet sheen that bleeds outward through the simulation. Unlike
// 'lift' (which gradually moves pigment back into suspension where it
// can re-settle), the paper brush ZEROS pigment outright — it's an
// opaque-paint metaphor, not a wet-blot one.
const PAPER_INDEX = -5;
const MASK_THRESHOLD = 0.1;          // cell considered masked above this
// v0.13.1 — visual ramp constants. The mask render no longer uses a
// hard threshold; instead the on-canvas tint scales smoothly with the
// per-cell mask value, giving soft edges where a brush stamp's falloff
// produced smaller mask deposits. MASK_VISUAL_FULL is the mask value
// at which the tint reaches its peak intensity, MASK_TINT_PEAK.
// The freeze decision in the sim is still binary (above THRESHOLD or
// not) — but THRESHOLD and the visual ramp's start are the same value,
// so every visible tint corresponds to an actually-frozen cell. No
// "tinted but not frozen" zone, no visual lie.
const MASK_VISUAL_FULL = 0.6;
const MASK_TINT_PEAK = 0.30;         // max yellow blend over underlying
// v0.80 — runtime toggle for the amber mask tint. When false, masked
// cells render as ordinary paper/pigment so the mask is invisible
// (still functionally frozen — flow continues to skip them, the user
// just doesn't see the amber overlay). Useful for taking screenshots
// where the mask shouldn't be visible, or for previewing what a
// composition looks like with the mask in place but not displayed.
let _maskTintVisible = true;

// v0.84 — VEL_CLAMP is auto-computed from SCALE (1/scale, capped at
// 1.5) so display-pixel velocity stays invariant across resolutions.
// The user can override via the API. Once overridden, the resolution
// slider's recompute logic skips VEL_CLAMP so the manual value
// persists. The flag flips back via velocityClamp(null) to restore
// auto-recompute behavior.
let _velocityClampManual = false;

// v0.86 — Wetness heatmap overlay. When enabled, renders a separate
// overlay canvas showing wet[] mapped through a two-color gradient.
// Lets the user see which parts of the canvas are still wet (useful
// for layering — wet-on-wet vs wet-on-dry behavior differs visibly).
// Two color stops are user-configurable so the heatmap can be styled
// to match a portfolio palette. Default: blue-on-yellow (dry→wet).
let _wetnessHeatmapEnabled = false;
let _wetnessLowColor  = [0xfc, 0xf3, 0xa7];  // pale yellow (dry)
let _wetnessHighColor = [0x29, 0x6f, 0xa7];  // deep blue (wet)
let _wetnessOverlayCanvas = null;
let _wetnessOverlayCtx = null;
let _wetnessOverlayImageData = null;

// v0.88 — Edge fade. Render-time alpha falloff in the last N pixels
// of each edge, using a smoothstep curve. Hides pigment that's
// accumulated near the boundary (useful with 'closed-gravity' mode
// to get the gravity dynamics without the visible edge buildup).
// 0 = disabled. Independent of edge mode — composes freely with any
// of closed / closed-gravity / open / gravity.
let _edgeFadePixels = 0;

// v0.89 — Most-recently-applied quality preset name. null until
// quality() is called at least once. Returned by quality() reads
// so embedders can show the current state in their UI.
let _qualityCurrent = null;

// v0.90 — Pause state. When paused, the rAF loop continues to run
// (to keep input/render responsive when acceptInput is true) but
// skips simStep, fadeStep, timeWashStep, animationStep, and
// visualizationStep. The svgTraceStep + applyPendingPaint + render
// path continues to run unconditionally so the user can still
// programmatically deposit pigment (via traceSVG/splash/etc.) and
// see it; with acceptInput: true the user can also paint via
// pointer.
//
// _pauseStartedAt is captured at the moment of pause; on resume,
// timer references for time-based animations (background washes,
// SVG traces, breathe modes) are shifted by the elapsed pause time
// so they pick up exactly where they left off instead of jumping
// ahead by the wall-clock duration of the pause.
let _paused = false;
let _pauseAcceptInput = false;
let _pauseStartedAt = 0;
// v0.90 — Pause render gating. During pause we want render() to fire
// once per deposit-batch, not every frame. _pauseDirty is set true
// by paintAt + markCanvasActive (so any deposit, programmatic or
// pointer-driven, flips it); the loop reads + clears it. Without
// this, paused-with-input would call render() every frame even when
// the user is idle, wasting CPU on each of N canvases.
let _pauseDirty = false;

// Permissive color parser for the wetness heatmap API. Accepts:
//   '#rgb'        → expand each digit
//   '#rrggbb'     → standard hex
//   [r, g, b]     → 0..255 ints
// Falls back to the provided default on parse failure.
function _parseHeatmapColor(v, fallback) {
  if (Array.isArray(v) && v.length >= 3) {
    return [v[0] | 0, v[1] | 0, v[2] | 0];
  }
  if (typeof v === 'string') {
    let s = v.trim();
    if (s.charAt(0) === '#') s = s.slice(1);
    if (s.length === 3) {
      s = s.split('').map(c => c + c).join('');
    }
    if (s.length === 6) {
      const n = parseInt(s, 16);
      if (!isNaN(n)) {
        return [(n >> 16) & 0xff, (n >> 8) & 0xff, n & 0xff];
      }
    }
  }
  return fallback;
}

// v0.81 — Edge boundary behavior. Three modes:
//   'closed'  — all four edges reflect; mass conserved exactly.
//               Current/default behavior, preserved for backward compat.
//   'open'    — all four edges drain. Pigment, water, pressure that
//               advects past the boundary is discarded. Optional
//               velocity bias via gravityStrength + gravityDirection.
//   'gravity' — edges open in the direction of gravity (e.g. 'down'
//               opens just the bottom; 'down-right' opens bottom and
//               right). Velocity bias always active.
//
// Encoded internally as: _edgeOpenLeft/Right/Top/Bottom flags + a
// (_gravityBiasX, _gravityBiasY) velocity perturbation applied in
// updateVelocity. The flags + bias are derived from the public
// triple (mode, direction, strength) whenever any of them change,
// so the inner loops just read flags and bias without conditionals
// on the higher-level state.
let _edgeMode = 'closed';
let _gravityDir = 'down';
let _gravityStrength = 0;
let _edgeOpenLeft = false;
let _edgeOpenRight = false;
let _edgeOpenTop = false;
let _edgeOpenBottom = false;
let _gravityBiasX = 0;
let _gravityBiasY = 0;

// 8-direction compass → (dx, dy) unit vector. Y is screen-positive
// (down), matching the lib's convention.
// v0.83 — 'radial' is a special pseudo-direction. It doesn't map to
// a single (dx, dy) vector; instead, in updateVelocity each cell
// computes its own outward-from-center radial vector. _COMPASS keeps
// (0, 0) as a sentinel so _recomputeEdgeState can treat 'radial'
// as "no fixed bias" while the velocity loop applies per-cell pull.
// v0.93 — 'radial-in' is the same as 'radial' but with the per-cell
// vector flipped to point INWARD (toward canvas center) instead of
// outward. Edge handling differs accordingly: in gravity edge mode,
// inward radial pulls pigment AWAY from edges toward the center, so
// no edges should open (it'd just leak mass with no inflow). We
// keep the (0,0) sentinel so the bias is computed per-cell in the
// velocity loop, same as outward radial.
const _COMPASS = {
  'up':         [ 0, -1],
  'up-right':   [ Math.SQRT1_2, -Math.SQRT1_2],
  'right':      [ 1,  0],
  'down-right': [ Math.SQRT1_2,  Math.SQRT1_2],
  'down':       [ 0,  1],
  'down-left':  [-Math.SQRT1_2,  Math.SQRT1_2],
  'left':       [-1,  0],
  'up-left':    [-Math.SQRT1_2, -Math.SQRT1_2],
  'radial':     [ 0,  0],
  'radial-in':  [ 0,  0],
};

// Recompute the cached open-edge flags and velocity bias whenever
// any of (_edgeMode, _gravityDir, _gravityStrength) change. Called
// from the API setters. The (dx, dy) compass vector picks both the
// edges that open in gravity mode AND the velocity bias direction.
function _recomputeEdgeState() {
  const [dx, dy] = _COMPASS[_gravityDir] || _COMPASS['down'];
  // Bias scaled by gravityStrength × VEL_CLAMP. Slider 0..1 of the
  // public API maps directly here.
  _gravityBiasX = _gravityStrength * VEL_CLAMP * dx;
  _gravityBiasY = _gravityStrength * VEL_CLAMP * dy;
  if (_edgeMode === 'closed' || _edgeMode === 'closed-gravity') {
    // v0.88 — closed-gravity is closed-edge physics (no drainage)
    // PLUS active gravity bias. The bias-vs-mode decision is now made
    // in updateVelocity (which checks _edgeMode), not via the edge
    // flags. Both 'closed' and 'closed-gravity' leave all flags false.
    _edgeOpenLeft = _edgeOpenRight = _edgeOpenTop = _edgeOpenBottom = false;
  } else if (_edgeMode === 'open') {
    _edgeOpenLeft = _edgeOpenRight = _edgeOpenTop = _edgeOpenBottom = true;
  } else if (_edgeMode === 'gravity') {
    // v0.83 — 'radial' opens all four edges since the pull is
    // omnidirectional outward. Cardinal/diagonal directions still
    // open only the edge(s) facing the pull.
    // v0.93 — 'radial-in' pulls pigment AWAY from edges toward the
    // center, so no edges should be open: opening any would just
    // leak mass that should have stayed put. Behaves like closed
    // physics with active inward bias.
    if (_gravityDir === 'radial') {
      _edgeOpenLeft = _edgeOpenRight = _edgeOpenTop = _edgeOpenBottom = true;
    } else if (_gravityDir === 'radial-in') {
      _edgeOpenLeft = _edgeOpenRight = _edgeOpenTop = _edgeOpenBottom = false;
    } else {
      // Open edges in the direction of gravity. A diagonal opens two
      // edges; a cardinal opens just one. Use sign of dx/dy with a
      // small epsilon to handle floating-point exact zeros.
      _edgeOpenRight  = dx >  0.001;
      _edgeOpenLeft   = dx < -0.001;
      _edgeOpenBottom = dy >  0.001;
      _edgeOpenTop    = dy < -0.001;
    }
  }
}
// mask[] and maskActive declared after N is initialized — see the
// state-arrays block below.
// Shared output array to avoid per-call allocation. Read after each
// updateRainbowWeights call.
const rainbowW = [0, 0, 0];
function updateRainbowWeights(t_ms) {
  // Three linear segments: rose→yellow, yellow→blue, blue→rose.
  // The wraparound (blue→rose) closes the loop so a continuous stroke
  // doesn't have a discontinuity at the cycle boundary.
  const t = t_ms % RAINBOW_PERIOD_MS;
  if (t < RAINBOW_STOP_MS) {
    const f = t / RAINBOW_STOP_MS;
    rainbowW[0] = 1 - f; rainbowW[1] = f; rainbowW[2] = 0;
  } else if (t < 2 * RAINBOW_STOP_MS) {
    const f = (t - RAINBOW_STOP_MS) / RAINBOW_STOP_MS;
    rainbowW[0] = 0; rainbowW[1] = 1 - f; rainbowW[2] = f;
  } else {
    const f = (t - 2 * RAINBOW_STOP_MS) / RAINBOW_STOP_MS;
    rainbowW[0] = f; rainbowW[1] = 0; rainbowW[2] = 1 - f;
  }
}
let currentPigment = 0;
let brushSize = 28; // diameter in display pixels
// v0.22 — brush-load multipliers. paintLoadMult scales the pigment
// deposit strength for pigment + rainbow brushes (default 1.0 keeps the
// historical 0.34/0.38 baselines). waterLoadMult scales how much wet,
// pressure, and lift the water brush deposits per dab (default 1.0
// keeps the original 0.55/0.18/0.18 values). Both are exposed as
// sliders in the controls panel and as Watercolor.paintLoad() /
// Watercolor.waterLoad() in the API.
let paintLoadMult = 1.0;
let waterLoadMult = 1.0;

// v0.97 — Ink load defaults. Independent of the pigment-side loads
// because ink has different design intent: maximum saturation per
// stamp (high paint load) with minimal wetness deposit (low water
// load) so default ink strokes are crisp and don't bleed by
// themselves — they only bloom when external wet pigment reaches
// them. Adjustable via wc.inkPaintLoad() / wc.inkWaterLoad().
let inkPaintLoadDefault = 1.0;
let inkWaterLoadDefault = 0.05;

// v0.28 — Brush dynamics state. Previously hardcoded in pointer
// handlers; now exposed so callers can tune feel without touching
// internals. All three apply equally to mouse, pen, and SVG tracing.
//
// _brushPressure — base strength (0..1) for each stamp. Was 0.7
//   hardcoded in pointer events and 0.45 hardcoded in cursors.
//   Lower = lighter dabs; higher = more saturated dabs.
//
// _brushFlow — stamp spacing along a drag path, as a fraction of
//   brush radius. Was 0.4 hardcoded in applyPendingPaint. Smaller =
//   more stamps per inch (smoother continuous stroke); larger =
//   fewer stamps (dabbed/dotted look).
//
// _usePointerPressure — when true, multiplies _brushPressure by the
//   PointerEvent.pressure value (stylus pressure on iPad/Wacom).
//   Default false because most mouse events report 0.5 by default
//   and would dim every stroke.
let _brushPressure = 0.7;
let _brushFlow = 0.4;
let _usePointerPressure = false;

// ============================================================
// v0.98 — TEXTURED BRUSH MODES (multiple variants)
// ============================================================
// First-class brush textures that produce different watercolor-
// technique looks by modulating paint deposit per-cell rather
// than at render time. Mode is per-instance and applies to BOTH
// pointer-driven and programmatic painting on the K-M pigments.
//
// Available modes:
//   'wet'      — default; smooth deposit, no texturing
//   'crayon'   — wax-resist look: paper-tooth peaks reject pigment,
//                soft-edged speckle, slight directional bias from
//                paper height gradient. (Originally shipped as 'dry'
//                in earlier v0.98 builds. The old name is kept as
//                an alias.)
//   'dryBrush' — true dry-brush bristle technique: strong directional
//                streaks aligned with stroke motion, narrower threshold
//                band (more binary in/out), higher anisotropy weight.
//   'salt'     — irregular round blooms from salt-on-wet technique.
//                Low-frequency noise (a few bigger spots per stroke),
//                soft halos, no directional bias.
//   'splatter' — small discrete dots from flicked-brush technique.
//                High-frequency noise, hard threshold, very sparse —
//                only the rarest peaks pass.
//
// All texture modes share the same intensity knob (_drynessAmount
// — yes, the name is now slightly misleading for non-dry textures,
// but renaming would break the public API; "amount" works as a
// reasonable mental model: 0 = no effect, 1 = maximum effect).
//
// Why not just compose existing knobs? The current lib's paintAt
// has a mathematically smooth quadratic falloff: every cell within
// the brush radius gets deposit proportional to its distance from
// center. Nothing in that math knows about paper height or sample
// noise patterns. To make the paper show through, paint deposit
// itself has to be modulated — that's why this is a new mode
// rather than a knob-stack.
//
// Cost when off: zero. Gated by _brushMode !== 'wet' in the
// paintAt deposit loop. Per-texture noise fields are generated
// lazily on first use of each mode.
let _brushMode = 'wet';        // see list above
let _drynessAmount = 0.7;      // 0..1 effect intensity (shared across textures)
let _dryPaperReject = 0.65;    // 0..1 — strength of paperH-driven rejection (crayon mainly)
let _dryAnisotropy = 0.6;      // 0..1 — motion-direction streaking (dryBrush mainly)
let _dryBrushSkip = 0.5;       // 0..1 — fine random per-cell skip variance
// Tracking for motion direction: previous stamp position +
// timestamp. Reset on stroke start. paintAt reads the prev
// position to derive a motion vector; if no prior stamp this
// stroke, anisotropy contribution is zero (pure isotropic
// rejection). Stamp positions are in grid coordinates so the
// vector is meaningful at sim resolution.
let _lastStampX = -1;
let _lastStampY = -1;
let _lastStampT = 0;
// Per-texture noise fields. Generated lazily — paying the cost
// only for textures the user actually selects. Each field is
// tuned to give a distinctive visual character:
//
//   crayonNoise  — medium frequency, smooth — wax-resist speckle
//   dryBrushNoise — directionally biased (correlated horizontally
//                   more than vertically), produces streak patterns
//   saltNoise    — low frequency (large blobs), few spots per area
//   splatterNoise — very high frequency (per-cell randomness),
//                   sparse hot spots
//
// All fields are Float32Array of length N (canvas grid), each
// value in [0, 1]. Regenerated when the grid size changes.
let crayonNoise   = null;
let dryBrushNoise = null;
let saltNoise     = null;
let splatterNoise = null;
function _ensureTextureNoise(mode) {
  // Generate the noise field for the requested mode if it doesn't
  // already exist or if the grid has been resized. Each mode has
  // its own field — they're not shared because the noise
  // characteristics (frequency, distribution) are part of the
  // texture's identity.
  switch (mode) {
    case 'crayon':
    case 'dry': // legacy alias
      if (crayonNoise && crayonNoise.length === N) return;
      crayonNoise = new Float32Array(N);
      // Two-octave value noise; finer than paperH so the speckle
      // reads as bristle/wax-grain rather than paper undulation.
      for (let y = 0; y < GH; y++) {
        for (let x = 0; x < GW; x++) {
          const n =
            0.65 * _smoothNoise2D(x * 0.42, y * 0.42, 91) +
            0.35 * _smoothNoise2D(x * 0.18, y * 0.18, 173);
          crayonNoise[y * GW + x] = Math.max(0, Math.min(1, n));
        }
      }
      return;
    case 'dryBrush':
      if (dryBrushNoise && dryBrushNoise.length === N) return;
      dryBrushNoise = new Float32Array(N);
      // Anisotropic noise: stretched horizontally so cells along
      // the same row tend to have similar values. This produces
      // streak-like coherence even without motion-direction
      // sampling. The streaks align with horizontal strokes;
      // motion anisotropy in the deposit formula combines with
      // this base pattern for stronger directional effect.
      //
      // Stretch factor 5: y-frequency 5x higher than x-frequency,
      // so horizontal correlation is 5x longer than vertical.
      for (let y = 0; y < GH; y++) {
        for (let x = 0; x < GW; x++) {
          const n =
            0.5 * _smoothNoise2D(x * 0.10, y * 0.50, 41) +  // long horizontal streaks
            0.3 * _smoothNoise2D(x * 0.25, y * 0.80, 67) +  // medium streaks
            0.2 * _smoothNoise2D(x * 0.50, y * 1.20, 89);   // fine grain breakup
          dryBrushNoise[y * GW + x] = Math.max(0, Math.min(1, n));
        }
      }
      return;
    case 'salt':
      if (saltNoise && saltNoise.length === N) return;
      saltNoise = new Float32Array(N);
      // Low-frequency single-octave noise: large smooth blobs.
      // The 0.06 frequency means features ~16 cells across,
      // which at typical brush size puts maybe 4-6 salt-spots
      // per stroke. Smoothing via two low-freq octaves keeps
      // the spots round rather than ragged.
      for (let y = 0; y < GH; y++) {
        for (let x = 0; x < GW; x++) {
          const n =
            0.7 * _smoothNoise2D(x * 0.06, y * 0.06, 211) +
            0.3 * _smoothNoise2D(x * 0.15, y * 0.15, 233);
          saltNoise[y * GW + x] = Math.max(0, Math.min(1, n));
        }
      }
      return;
    case 'splatter':
      if (splatterNoise && splatterNoise.length === N) return;
      splatterNoise = new Float32Array(N);
      // Very high-frequency noise — close to per-cell random.
      // Combined with a sharp threshold and large dryness, this
      // produces sparse single-cell dots. Two octaves at very
      // high frequencies create slight 2-3 cell clusters which
      // read as discrete spots rather than uniform noise.
      for (let y = 0; y < GH; y++) {
        for (let x = 0; x < GW; x++) {
          const n =
            0.5 * _smoothNoise2D(x * 0.95, y * 0.95, 311) +
            0.5 * _smoothNoise2D(x * 1.40, y * 1.40, 337);
          splatterNoise[y * GW + x] = Math.max(0, Math.min(1, n));
        }
      }
      return;
  }
}
// Helper used by texture noise generation. Same hash-based
// smooth noise pattern used elsewhere in the lib; small local
// helper here so the texture block stays self-contained.
function _smoothNoise2D(x, y, seed) {
  const ix = Math.floor(x), iy = Math.floor(y);
  const fx = x - ix, fy = y - iy;
  const h = (a, b) => {
    let t = ((a * 374761393) ^ (b * 668265263) ^ (seed * 2147483647)) | 0;
    t = (t ^ (t >>> 13)) * 1274126177;
    return ((t ^ (t >>> 16)) >>> 0) / 4294967296;
  };
  const a = h(ix, iy), b = h(ix + 1, iy);
  const c = h(ix, iy + 1), d = h(ix + 1, iy + 1);
  const sx = fx * fx * (3 - 2 * fx);
  const sy = fy * fy * (3 - 2 * fy);
  return (a * (1 - sx) + b * sx) * (1 - sy) + (c * (1 - sx) + d * sx) * sy;
}

// ============================================================
// GRID — sized to fit the viewport. SCALE display pixels per cell.
// Computed once at module load; window resize is not handled (would
// require reallocating every Float32Array below).
//
// SCALE is the QUALITY KNOB. Changing it adjusts resolution + all
// scale-dependent constants together so the painting behavior stays
// visually consistent — just sharper or chunkier:
//   SCALE=1    →  native resolution, ~4x sim cost vs SCALE=2
//   SCALE=1.5  →  middle ground, ~1.78x sim cost vs SCALE=2
//   SCALE=2    →  half-resolution, the v0.7-0.8 baseline (REFERENCE)
//   SCALE=3    →  coarse middle ground
//   SCALE=4    →  fast, original v0.6 default
//   SCALE=6+   →  very coarse, useful on low-power devices
//
// SCALE_REF is the reference where the simulation constants were
// hand-tuned (v0.8 baseline). Everything else derives from it via the
// ratio `s = SCALE / SCALE_REF`:
//   - Diffusion coefficients scale as 1/s² (with stability cap at 0.20)
//   - Edge kernel sizes scale as 1/s (rounded, min 1)
//   - Paper texture frequency scales as s
//   - VEL_CLAMP scales as 1/s (with stability cap at 1.5)
// Intentionally NOT scaled (would require ~1/s³ scaling, complex with
// other interactions; second-order visual impact accepted at non-ref SCALE):
//   - DT, DRAG, VISCOSITY, PAPER_TILT — velocity-update internals
//   - EDGE_ETA — edge darkening intensity (per-step)
//   - Evaporation rate, pressure decay — per-step rates
//
// Non-integer SCALE is allowed; DISPLAY_W/H are rounded to keep
// canvas dimensions integer.
//
// CANVAS_OVERSCAN extends the simulated region past the visible viewport
// (see #canvas CSS — inset: -2.5vh -2.5vw). The hidden margin absorbs
// the edge-of-grid artifacts of the sim so the visible area only shows
// the interior. 1.05 ↔ 2.5% past each side, matching the CSS.
// ============================================================
// SCALE can be set via the ?scale= URL query parameter. The UI slider
// at the bottom of the page reads it and writes it (via page reload —
// changing SCALE requires reallocating every Float32Array below, so a
// reload is the cleanest way to get a fresh sim at a new resolution).
// v0.89 — qualityHint pre-resolves a starting scale based on a static
// device signal. Currently the only accepted hint is 'auto-mobile',
// which raises SCALE for coarse-pointer devices (most mobiles benefit
// from this without losing visible quality). Any explicit options.scale
// always wins over the hint. The hint is one-shot: it only affects the
// initial SCALE; it doesn't enable runtime adaptation.
let _qualityHintScale = null;
if (options.qualityHint === 'auto-mobile') {
  // Use matchMedia rather than UA sniffing — pointer:coarse is the
  // standardized signal for touch-primary devices, which is what we
  // actually care about for "should this start at lower resolution."
  // The window check guards against non-browser environments.
  const _isCoarse = typeof window !== 'undefined' &&
                    typeof window.matchMedia === 'function' &&
                    window.matchMedia('(pointer: coarse)').matches;
  if (_isCoarse) _qualityHintScale = 2.5;
}
const _urlScale = parseFloat(options.scale);
let SCALE;
if (isFinite(_urlScale) && _urlScale >= 1 && _urlScale <= 6) {
  SCALE = _urlScale;
} else if (_qualityHintScale !== null) {
  SCALE = _qualityHintScale;
} else {
  SCALE = 1.75;
}
const SCALE_REF = 2;                   // reference scale where constants were tuned
let s_scale = SCALE / SCALE_REF;       // dimensionless ratio
let inv_s = 1 / s_scale;
let inv_s2 = inv_s * inv_s;
const CANVAS_OVERSCAN = 1.05;
let GW = Math.max(120, Math.floor(_innerWidth()  * CANVAS_OVERSCAN / SCALE));
let GH = Math.max(80,  Math.floor(_innerHeight() * CANVAS_OVERSCAN / SCALE));
let N = GW * GH;
let DISPLAY_W = Math.round(GW * SCALE);
let DISPLAY_H = Math.round(GH * SCALE);

// v2 — Canvas scale factor for proportional brush sizes.
// Animation/visualization/splash presets were tuned for a typical
// standalone canvas (~1200px wide). When the host element is much
// smaller (e.g. 320px in an embedded card), the same gridRadius
// covers proportionally more of the canvas and strokes look huge.
// Auto-computing a downscale factor based on display width keeps
// stroke widths visually consistent across canvas sizes. Capped at
// 1.0 so large canvases use the original tuning unchanged.
const REFERENCE_DISPLAY_W = 1200;
let _canvasScale = Math.min(1.0, DISPLAY_W / REFERENCE_DISPLAY_W);
// Callers can override the auto-computed value through options.canvasScale
// passed to Watercolor.create() — applied below after options is parsed.
if (typeof options.canvasScale === 'number' && options.canvasScale > 0) {
  _canvasScale = options.canvasScale;
}

// ============================================================
// STATE ARRAYS (flat Float32Arrays for speed)
// ============================================================
let wet      = new Float32Array(N); // water amount per cell, 0..1
let wetBlur  = new Float32Array(N);
let wetBlurTmp = new Float32Array(N);
let u        = new Float32Array(N); // x-velocity
let v        = new Float32Array(N); // y-velocity
let u_new    = new Float32Array(N);
let v_new    = new Float32Array(N);
let pressure = new Float32Array(N);
let paperH   = new Float32Array(N); // paper height field, 0..1

// 3 pigments × 2 layers (suspended in water, deposited on paper)
let g = [new Float32Array(N), new Float32Array(N), new Float32Array(N)];
let d = [new Float32Array(N), new Float32Array(N), new Float32Array(N)];
let g_tmp = [new Float32Array(N), new Float32Array(N), new Float32Array(N)];

// v0.97 — Ink layer. Lives outside the 3-pigment K-M system. Renders
// as a darkening multiplier applied on top of the K-M reflectance.
// Designed for "print text on watercolor paper" use cases: a third
// medium that has its own crisp deposition profile but bleeds with
// the wet field like the pigments do.
//
// Differences from a pigment:
//   • Single channel (one Float32Array) — no per-RGB K/S because ink
//     doesn't scatter, it absorbs uniformly across wavelengths.
//   • No suspended/deposited split — ink is just "amount per cell".
//     Doesn't go through the evaporation transfer that pigment uses.
//   • Advects with the velocity field same as pigment (when external
//     wet causes flow, ink moves with it — that's the "bloom when
//     other pigments hit it" behavior).
//   • Default paint load high (saturate immediately for crisp letters);
//     default water load low (don't deposit wet alongside, so ink
//     stays sharp by default).
let ink = new Float32Array(N);
let ink_tmp = new Float32Array(N);
let inkActive = false;  // gate render + advection cost when no ink
const INK_INDEX = -5;
// Render-time alpha. ink[i] * INK_ALPHA is the fraction by which K-M
// reflectance is darkened. With INK_ALPHA = 0.95, ink at concentration
// 1.0 reduces reflectance by 95% (near-black). Tuned so that the
// default paint load of 1.0 gives a clearly readable dark mark without
// going to absolute zero (which looks like a hole, not ink).
const INK_ALPHA = 0.95;
// Per-cell threshold below which ink is treated as zero (skip render +
// advection cost on near-empty cells).
const INK_THRESHOLD = 0.005;

// Masking fluid layer (v0.13) — one float per cell, 0 = clean, 1 = fully
// masked. Cells above MASK_THRESHOLD are frozen by every sim function.
// See the MASK_INDEX block above for the full design rationale.
let mask = new Float32Array(N);
let maskActive = false;
// v0.19 — mask rect bounds (mirror of activeRect for the mask layer).
// Tracks the bounding box of cells with mask[i] > MASK_THRESHOLD. Every
// sim phase that needs to skip masked cells can use these bounds to
// skip the per-cell mask[i] memory load entirely outside the rect —
// only doing the check inside the small rect where the mask actually
// lives. For a typical localized mask (a moon, a tree silhouette),
// that's a 5-10× speedup on the mask-check overhead, scaling with
// (1 - maskRectArea / activeRectArea).
//
// Updated by:
//   • paintAt MASK_INDEX branch — expands the rect when new mask cells
//     cross the threshold
//   • removeMask() — clears the rect along with the mask array
//
// Never actively shrunk during normal operation. A periodic shrink
// would mirror activeRect's, but masks are typically painted once and
// then left alone, so the rect stays right-sized after the first paint.
let maskRectMinX = GW, maskRectMinY = GH, maskRectMaxX = -1, maskRectMaxY = -1;

function maskRectIsEmpty() {
  return maskRectMaxX < maskRectMinX || maskRectMaxY < maskRectMinY;
}

function clearMaskRect() {
  maskRectMinX = GW; maskRectMinY = GH;
  maskRectMaxX = -1; maskRectMaxY = -1;
}

// Inline test helper for the hot path. Returns true if cell (x, y) is
// even potentially masked — i.e. inside the mask rect. Caller still
// needs to check mask[i] > MASK_THRESHOLD for the actual value, but
// can skip that load entirely when this returns false.
function cellInMaskRect(x, y) {
  return x >= maskRectMinX && x <= maskRectMaxX &&
         y >= maskRectMinY && y <= maskRectMaxY;
}

// v0.19 — hot-path mask check used in all sim phases. Combines the
// global maskActive flag with the rect bounds and the per-cell mask
// value into a single inline expression that the JIT can flatten and
// hoist. CRITICAL: most cells in a typical frame are NOT inside the
// mask rect, so the rect-bounds compare short-circuits before the
// mask[i] memory load — which is the whole point.
//
// Inlining: V8/JSC both inline small monomorphic functions; this
// callsite gets the same codegen as if the expression were repeated
// inline at each callsite, but with a single source of truth.
function isMaskedAt(x, y, i) {
  return maskActive &&
         x >= maskRectMinX && x <= maskRectMaxX &&
         y >= maskRectMinY && y <= maskRectMaxY &&
         mask[i] > MASK_THRESHOLD;
}
// Wet diffusion temp buffer — used by diffuseWet() to read previous-step
// values while writing this-step values into wet[].
let wet_tmp = new Float32Array(N);

// ============================================================
// IDLE-SKIP STATE — declared early so paintAt / resetSim / rewet can
// reference markCanvasActive at init without hitting a TDZ on the
// let bindings below. The actual idle-decision logic lives next to
// the loop further down; this block is just storage + the wake helper.
// ============================================================
let framesSincePaint = 9999;          // start "settled" — first paint wakes
let framesSinceIdleCheck = 0;
let framesSinceBars = 999;            // start large so first frame updates bars
let simIsIdle = false;                // start active so initial state renders
let lastTotalWet = 0;
let lastTotalSuspended = 0;
function markCanvasActive() {
  framesSincePaint = 0;
  simIsIdle = false;
  // v0.90 — during pause, this flag triggers a one-shot render in the
  // next frame so deposits made via paintAt/splash/traceSVG/etc. are
  // visible. The loop reads + clears it.
  if (_paused) _pauseDirty = true;
}

// ============================================================
// ACTIVE REGION TRACKING (v1.0)
// ============================================================
// Bounding rectangle of "where dynamics matter" — i.e., cells where
// suspended pigment (g > 0) or pressure (> 0) exists. Outside this
// rect, wet is uniform, no pigment, no flow — the per-step passes
// would produce no change, so we skip the empty paper entirely.
//
// This is the biggest single perf win since v0.7's fused passes:
// typical paintings cover 10-40% of canvas, so simStep does 60-90%
// less per-cell work.
//
// Tracking:
//   expandActiveRect — paintAt calls this on every brush stamp,
//     growing the rect to cover the stamp + ACTIVE_MARGIN cells.
//     The margin absorbs diffusion + advection spread between scans.
//   shrinkActiveRect — runs every ACTIVE_SHRINK_INTERVAL frames in
//     the main loop. Scans the current rect for cells above the
//     activity threshold and tightens to that bounding box + margin.
//     Lets the rect tighten as pigment dries / fades / lifts.
//
// Empty rect (activeMaxX < activeMinX, i.e. -1): simStep functions
// early-return. This is the initial state (resetSim leaves uniform
// wet but no pigment/pressure) and the post-dry state.
let activeMinX = 0, activeMaxX = -1;  // -1 marker = empty
let activeMinY = 0, activeMaxY = -1;
let framesSinceShrink = 0;
const ACTIVE_SHRINK_INTERVAL = 30;    // frames between shrink scans
const ACTIVE_MARGIN = 24;             // cells of padding around tracked content
const ACTIVE_THRESHOLD = 0.001;       // pigment/pressure threshold for "active"

function activeRectIsEmpty() {
  return activeMaxX < activeMinX || activeMaxY < activeMinY;
}

function setActiveRectFull() {
  activeMinX = 0; activeMaxX = GW - 1;
  activeMinY = 0; activeMaxY = GH - 1;
}

function setActiveRectEmpty() {
  activeMinX = 0; activeMaxX = -1;
  activeMinY = 0; activeMaxY = -1;
}

function expandActiveRect(centerX, centerY, radius) {
  const lx = Math.max(0, Math.floor(centerX - radius - ACTIVE_MARGIN));
  const rx = Math.min(GW - 1, Math.ceil(centerX + radius + ACTIVE_MARGIN));
  const ty = Math.max(0, Math.floor(centerY - radius - ACTIVE_MARGIN));
  const by = Math.min(GH - 1, Math.ceil(centerY + radius + ACTIVE_MARGIN));
  if (activeRectIsEmpty()) {
    activeMinX = lx; activeMaxX = rx;
    activeMinY = ty; activeMaxY = by;
  } else {
    if (lx < activeMinX) activeMinX = lx;
    if (rx > activeMaxX) activeMaxX = rx;
    if (ty < activeMinY) activeMinY = ty;
    if (by > activeMaxY) activeMaxY = by;
  }
}

function shrinkActiveRect() {
  if (activeRectIsEmpty()) return;
  const g0 = g[0], g1 = g[1], g2 = g[2];
  const thr = ACTIVE_THRESHOLD;
  let newMinX = activeMaxX + 1, newMaxX = activeMinX - 1;
  let newMinY = activeMaxY + 1, newMaxY = activeMinY - 1;
  for (let y = activeMinY; y <= activeMaxY; y++) {
    const yo = y * GW;
    for (let x = activeMinX; x <= activeMaxX; x++) {
      const i = yo + x;
      if (g0[i] > thr || g1[i] > thr || g2[i] > thr || pressure[i] > thr) {
        if (x < newMinX) newMinX = x;
        if (x > newMaxX) newMaxX = x;
        if (y < newMinY) newMinY = y;
        if (y > newMaxY) newMaxY = y;
      }
    }
  }
  if (newMaxX < newMinX) {
    setActiveRectEmpty();
    return;
  }
  activeMinX = Math.max(0, newMinX - ACTIVE_MARGIN);
  activeMaxX = Math.min(GW - 1, newMaxX + ACTIVE_MARGIN);
  activeMinY = Math.max(0, newMinY - ACTIVE_MARGIN);
  activeMaxY = Math.min(GH - 1, newMaxY + ACTIVE_MARGIN);
}

// ============================================================
// PAPER GENERATION — multi-octave hash noise, scaled 0..1
// ============================================================
function hash2(x, y) {
  const s = Math.sin(x * 12.9898 + y * 78.233 + 1.0) * 43758.5453;
  return s - Math.floor(s);
}
function smoothNoise(x, y) {
  const ix = Math.floor(x), iy = Math.floor(y);
  const fx = x - ix,        fy = y - iy;
  const a = hash2(ix,     iy);
  const b = hash2(ix + 1, iy);
  const c = hash2(ix,     iy + 1);
  const d = hash2(ix + 1, iy + 1);
  const ux = fx * fx * (3 - 2 * fx);
  const uy = fy * fy * (3 - 2 * fy);
  return a * (1 - ux) * (1 - uy)
       + b * ux       * (1 - uy)
       + c * (1 - ux) * uy
       + d * ux       * uy;
}
// 1.0 = full noise range (~0.08 .. 0.97); 0.5 halves the variation around mean (~0.29 .. 0.73).
// Lower values produce subtler granulation and less distinct low spots on the paper.
const TEXTURE_AMPLITUDE = 0.5;

function generatePaper() {
  for (let y = 0; y < GH; y++) {
    for (let x = 0; x < GW; x++) {
      // SCALE-derived: freq scales as `s` to keep texture feature size
      // in display pixels constant. At SCALE_REF (s=1) → 12.0 (v0.8
      // baseline). Dominant feature wavelength ≈ SCALE/freq display px.
      let h = 0, amp = 0.5, freq = 12.0 * s_scale;
      for (let o = 0; o < 4; o++) {
        h += amp * smoothNoise(x * freq + 17, y * freq + 53);
        amp *= 0.55;
        freq *= 2.1;
      }
      // High-frequency fiber speckle
      h += (hash2(x, y) - 0.5) * 0.04;
      // Normalize roughly into 0..1
      h = Math.max(0, Math.min(1, h));
      // Compress range around the mean to reduce distinctness of low spots
      h = 0.5 + (h - 0.5) * TEXTURE_AMPLITUDE;
      paperH[y * GW + x] = h;
    }
  }
}

// ============================================================
// BOX BLUR — separable, used for FlowOutward distance approximation
// ============================================================
function boxBlur(src, dst, radius) {
  const inv = 1 / (2 * radius + 1);
  const r = radius;
  const gw = GW, gh = GH;
  const tmp = wetBlurTmp;

  // ---- HORIZONTAL PASS: src -> wetBlurTmp ----
  // Each row's inner loop is split into three regions so the clamps
  // can be hoisted out of the hot middle iteration. Middle covers the
  // vast majority of cells — the edges are only `radius` wide each.
  for (let y = 0; y < gh; y++) {
    const yo = y * gw;
    let sum = 0;
    // Initialize the window: -r..+r, clamped to row bounds
    for (let xx = -r; xx <= r; xx++) {
      const ix = xx < 0 ? 0 : xx > gw - 1 ? gw - 1 : xx;
      sum += src[yo + ix];
    }
    // Left region: x < r, "sub" side clamps to 0
    let x = 0;
    const leftEnd = r < gw ? r : gw;
    while (x < leftEnd) {
      tmp[yo + x] = sum * inv;
      const addX = x + r + 1;
      sum += src[yo + (addX > gw - 1 ? gw - 1 : addX)];
      sum -= src[yo]; // sub clamps to 0
      x++;
    }
    // Middle: both indices in bounds — no clamps
    const midEnd = gw - r - 1 > 0 ? gw - r - 1 : 0;
    while (x < midEnd) {
      tmp[yo + x] = sum * inv;
      sum += src[yo + x + r + 1] - src[yo + x - r];
      x++;
    }
    // Right region: "add" side clamps to gw - 1
    const lastIdx = yo + gw - 1;
    while (x < gw) {
      tmp[yo + x] = sum * inv;
      const subX = x - r;
      sum += src[lastIdx] - src[yo + (subX < 0 ? 0 : subX)];
      x++;
    }
  }

  // ---- VERTICAL PASS: wetBlurTmp -> dst ----
  // Same 3-region split. Note this pass strides by gw between reads,
  // so it's less cache-friendly than the horizontal pass; the clamp
  // elimination is the cheap win we can take here without restructuring
  // memory layout.
  for (let x = 0; x < gw; x++) {
    let sum = 0;
    for (let yy = -r; yy <= r; yy++) {
      const iy = yy < 0 ? 0 : yy > gh - 1 ? gh - 1 : yy;
      sum += tmp[iy * gw + x];
    }
    let y = 0;
    const topEnd = r < gh ? r : gh;
    while (y < topEnd) {
      dst[y * gw + x] = sum * inv;
      const addY = y + r + 1;
      sum += tmp[(addY > gh - 1 ? gh - 1 : addY) * gw + x];
      sum -= tmp[x]; // sub clamps to row 0
      y++;
    }
    const midEnd = gh - r - 1 > 0 ? gh - r - 1 : 0;
    while (y < midEnd) {
      dst[y * gw + x] = sum * inv;
      sum += tmp[(y + r + 1) * gw + x] - tmp[(y - r) * gw + x];
      y++;
    }
    const lastRowOff = (gh - 1) * gw;
    while (y < gh) {
      dst[y * gw + x] = sum * inv;
      const subY = y - r;
      sum += tmp[lastRowOff + x] - tmp[(subY < 0 ? 0 : subY) * gw + x];
      y++;
    }
  }
}

// ============================================================
// EDGE DARKENING (FlowOutward, §4.3.3)
// p -= eta * (1 - M') * M, where M is the *binary* wet mask and M' its blur.
// We blur a binarized version so that uniformly wet areas don't spuriously
// drain pressure — only real boundaries between wet and dry should reduce p.
// We additionally blur with a much LARGER kernel to detect whether the
// wet region is big or just a small isolated patch (like a fresh
// brushstroke on dry paper). Small patches dry too fast for full
// contact-line migration to develop, so we attenuate edge darkening
// there — keeps pigment near the brush contact instead of pooling at
// the patch perimeter as a ring.
// SCALE-derived: 1/s scaling keeps display-pixel kernel extent constant.
// Running-sum box blur is O(N) regardless of kernel size, so these can
// scale freely without performance impact.
let EDGE_KERNEL = Math.max(1, Math.round(4 * inv_s));
let EDGE_KERNEL_LARGE = Math.max(1, Math.round(20 * inv_s));
const EDGE_ETA = 0.045;
// EDGE_WET_ACTIVE / EDGE_WET_OFF define a smooth ramp on edge darkening
// intensity as cells dry. Above EDGE_WET_ACTIVE, full strength. Below
// EDGE_WET_OFF, off entirely. Linear ramp between. Without this, the
// moving wet/dry boundary fires edge darkening at every position it
// passes through during the long late drying phase, laying down a
// trail of pigment as visible concentric "tide lines" inside what
// should be a uniform dry wash. Real contact-line migration only
// happens while there's enough water left to sustain the outward
// replenishing flow — once a cell is mostly dry, the mechanism quietly
// switches off and pigment locks in place where it last was. This
// ramp models that timing.
const EDGE_WET_ACTIVE = 0.40;
const EDGE_WET_OFF    = 0.10;
// MAX_PIGMENT caps how much pigment any single cell can hold. The paper
// caps both g and d at 1 inside §4.5 (TransferPigment), but paintAt,
// advection convergence, and the evaporation dump-to-deposited all
// previously bypassed that cap — letting endpoint cells accumulate
// unbounded pigment, which then read as near-black after KM compositing.
const MAX_PIGMENT = 1.0;
let wetBinary = new Float32Array(N);
let wetBlurLarge = new Float32Array(N);
function applyEdgeDarkening() {
  for (let i = 0; i < N; i++) wetBinary[i] = wet[i] > 0.04 ? 1 : 0;
  boxBlur(wetBinary, wetBlur, EDGE_KERNEL);
  boxBlur(wetBinary, wetBlurLarge, EDGE_KERNEL_LARGE);
  if (activeRectIsEmpty()) return;
  const activeRange = EDGE_WET_ACTIVE - EDGE_WET_OFF;
  const y0 = Math.max(0, activeMinY);
  const y1 = Math.min(GH - 1, activeMaxY);
  const x0 = Math.max(0, activeMinX);
  const x1 = Math.min(GW - 1, activeMaxX);
  for (let y = y0; y <= y1; y++) {
    const yo = y * GW;
    const rowMaybeMasked = maskActive &&
                           y >= maskRectMinY && y <= maskRectMaxY;
    for (let x = x0; x <= x1; x++) {
      const i = yo + x;
      // Masked cells: edges shouldn't darken into the mask boundary —
      // no pressure changes at frozen cells.
      if (rowMaybeMasked && x >= maskRectMinX && x <= maskRectMaxX &&
          mask[i] > MASK_THRESHOLD) continue;
      if (wet[i] > 0.04) {
        const deficit = 1 - wetBlur[i];          // 0 in interior, → 1 near boundary
        if (deficit > 0) {
          const w = wet[i];
          // Smooth fade: 1 above EDGE_WET_ACTIVE, 0 below EDGE_WET_OFF, linear between.
          const activation = w >= EDGE_WET_ACTIVE ? 1
                           : w <= EDGE_WET_OFF    ? 0
                           : (w - EDGE_WET_OFF) / activeRange;
          // wetBlurLarge ≈ 1 in big wet regions, ≈ 0.1 in small wet patches.
          // The product attenuates edge darkening in small islands so a
          // fresh stroke on dry paper doesn't lose all its pigment to a ring.
          pressure[i] -= EDGE_ETA * deficit * wetBlurLarge[i] * w * activation;
        }
      }
    }
  }
}

// ============================================================
// VELOCITY UPDATE (simplified shallow water, §4.3.1)
// ============================================================
const DT       = 0.42;
const VISCOSITY = 0.10;
const DRAG     = 0.014;
const PAPER_TILT = 0.06;   // reduced from 0.32 — paper height is now pixel-fine,
                           // so its gradient is essentially noise; keep its
                           // contribution to velocity small to avoid jitter
// SCALE-derived: 1/s scaling makes max display-pixel velocity invariant.
// Capped at 1.5 — the upwind advection in movePigment has a CFL bound
// VEL_CLAMP * (DT * 0.7) * 2 < 1, so VEL_CLAMP must stay below ~1.7.
// Cap engages at SCALE < ~1.33 (e.g. at SCALE=1, ideal is 2.0).
let VEL_CLAMP  = Math.min(1.5, 1.0 * inv_s);

function updateVelocity() {
  if (activeRectIsEmpty()) {
    // No active dynamics anywhere: pressure is already ≈ 0 outside the
    // (empty) rect by definition. Skip entirely.
    return;
  }
  const y0 = Math.max(1, activeMinY);
  const y1 = Math.min(GH - 2, activeMaxY);
  const x0 = Math.max(1, activeMinX);
  const x1 = Math.min(GW - 2, activeMaxX);
  for (let y = y0; y <= y1; y++) {
    const yo = y * GW;
    const rowMaybeMasked = maskActive &&
                           y >= maskRectMinY && y <= maskRectMaxY;
    for (let x = x0; x <= x1; x++) {
      const i = yo + x;
      // Masked cells have no flow — treat them like dry walls.
      if (rowMaybeMasked && x >= maskRectMinX && x <= maskRectMaxX &&
          mask[i] > MASK_THRESHOLD) {
        u_new[i] = 0; v_new[i] = 0; continue;
      }
      if (wet[i] < 0.04) { u_new[i] = 0; v_new[i] = 0; continue; }
      // pressure gradient
      const dpdx = pressure[i + 1] - pressure[i - 1];
      const dpdy = pressure[i + GW] - pressure[i - GW];
      // paper slope (gradient of height field)
      const dhdx = paperH[i + 1] - paperH[i - 1];
      const dhdy = paperH[i + GW] - paperH[i - GW];
      // viscous diffusion (laplacian)
      const lapU = u[i - 1] + u[i + 1] + u[i - GW] + u[i + GW] - 4 * u[i];
      const lapV = v[i - 1] + v[i + 1] + v[i - GW] + v[i + GW] - 4 * v[i];

      let nu = u[i] + DT * (-dpdx * 0.5 - dhdx * PAPER_TILT + VISCOSITY * lapU - DRAG * u[i]);
      let nv = v[i] + DT * (-dpdy * 0.5 - dhdy * PAPER_TILT + VISCOSITY * lapV - DRAG * v[i]);
      // v0.81 — gravity bias. Applied per-step (independent of DT
      // because the user-tuned strength already encapsulates rate).
      // v0.82 — gated specifically on edgeMode === 'gravity' instead
      // of "any edge open". Open mode with all four edges drains
      // without any ambient pull, which matches the "infinite paper
      // window" mental model better.
      // v0.83 — 'radial' direction: bias points outward from canvas
      // center per-cell instead of using the cached fixed vector.
      // The magnitude (gravityStrength × VEL_CLAMP) is the same, just
      // the direction varies. Center cells get zero radial bias
      // (their displacement vector is the zero vector); cells near
      // edges get the strongest pull toward the nearest edge.
      // v0.88 — gravity bias applies in both 'gravity' (open edges
      // in the bias direction) AND 'closed-gravity' (closed edges,
      // bias-only). The latter is for cases where you want gravity
      // dynamics without actually losing pigment off the edges, with
      // optional render-time edgeFade to hide the resulting buildup.
      if (_edgeMode === 'gravity' || _edgeMode === 'closed-gravity') {
        // v0.93 — Both 'radial' (outward) and 'radial-in' (inward)
        // compute the same per-cell displacement vector from canvas
        // center; the only difference is sign. We flip via a single
        // signed scalar so both branches share the math.
        if (_gravityDir === 'radial' || _gravityDir === 'radial-in') {
          const cx = (GW - 1) * 0.5;
          const cy = (GH - 1) * 0.5;
          const rx = x - cx;
          const ry = y - cy;
          const rmag = Math.sqrt(rx * rx + ry * ry);
          if (rmag > 0.001) {
            const sign = _gravityDir === 'radial-in' ? -1 : 1;
            const radialBias = sign * _gravityStrength * VEL_CLAMP;
            const inv = radialBias / rmag;
            nu += rx * inv;
            nv += ry * inv;
          }
        } else {
          nu += _gravityBiasX;
          nv += _gravityBiasY;
        }
      }
      // v0.69 — MAGNITUDE clamp instead of per-axis. The previous form
      // (-CLAMP ≤ nu ≤ CLAMP and -CLAMP ≤ nv ≤ CLAMP independently)
      // bounded the velocity to a SQUARE envelope, with corners at
      // (±CLAMP, ±CLAMP) — magnitude √2·CLAMP. Diagonal-direction cells
      // could be √2× faster than cardinal-direction cells, which fed a
      // visible cross artifact into every downstream system regardless
      // of the pigment advection scheme. Magnitude clamping uses a
      // CIRCULAR envelope: all directions get the same maximum speed.
      // This was the actual root cause of the cross artifact across
      // v0.56-0.68 — I was looking at the pigment advection the whole
      // time (which IS subtly anisotropic in donor-cell mode, but is
      // perfectly isotropic in semilag mode), missing that the velocity
      // field itself was preferring diagonals over cardinals upstream
      // of any pigment work.
      const mag = Math.sqrt(nu * nu + nv * nv);
      if (mag > VEL_CLAMP) {
        const s = VEL_CLAMP / mag;
        nu *= s;
        nv *= s;
      }
      u_new[i] = nu; v_new[i] = nv;
    }
  }
  // Copy u_new/v_new back to u/v, restricted to the rect. Float32Array's
  // set(subarray, offset) is a fast memcpy under the hood. Cells outside
  // the rect retain their previous u/v values (which are ≈ 0 since the
  // shrink scan tracks pressure too).
  for (let y = y0; y <= y1; y++) {
    const yo = y * GW;
    const start = yo + x0;
    const end = yo + x1 + 1;
    u.set(u_new.subarray(start, end), start);
    v.set(v_new.subarray(start, end), start);
  }
  // v0.10 — pressure decay restricted to active rect. Pressure is only
  // injected by paintAt (which always grows the rect to cover the stamp)
  // and only consumed by updateVelocity + applyEdgeDarkening (both rect-
  // restricted). Cells outside the rect have pressure ≈ 0 from initial
  // state; multiplying them by 0.94 was burning N writes per simStep for
  // no behavioral effect.
  for (let y = y0; y <= y1; y++) {
    const yo = y * GW;
    for (let x = x0; x <= x1; x++) pressure[yo + x] *= 0.94;
  }
}

// ============================================================
// MOVE PIGMENT (upwind advection + small diffusion)
// ============================================================
// SCALE-derived: 1/s² scaling preserves display-pixel diffusion rate.
// Capped at 0.20 (below 0.25 stability bound for explicit 4-neighbor
// Laplacian) — the cap engages at very small SCALE values.
let PIGMENT_DIFFUSION = Math.min(0.20, 0.045 * inv_s2);

// v0.57 — Advection mode controls how the donor-cell pigment advection
// handles cells where the velocity field is so strong that the
// proposed per-cell outflux would exceed the cell's pigment ('CFL
// violation' in shallow-water terms — the L1 cell speed × adt > 1).
// Without intervention, such cells donate more pigment than they
// hold, go negative in the copyback, and K-M renders those negative
// cells as bright cardinal channels (the cross artifact at extreme
// deluges in v0.56 and earlier).
//
//   'standard' — existing v0.56 behavior, fastest but exhibits the
//                cross at high velocity / pressure / radius.
//   'clamp'    — per-cell effective adt capped at 1/(|ux|+|vy|) so
//                total outflux ≤ gk. Kills the negative cells with
//                ~5% overhead per movePigment call. Pigment can't
//                outrun the wavefront, so very-high-velocity strokes
//                look slightly less aggressive — but mass-conserving.
//   'substep'  — global substep count N = ceil(maxL1Speed * baseAdt),
//                capped at 16. Each substep runs a full advection
//                pass at adt/N. Physically correct propagation at any
//                velocity; cost is N× the advection during the
//                handful of post-deluge frames where velocities are
//                still high.
// v0.65 — Default changed from 'standard' to 'substep'. The cross
// artifact at the new v0.60+ extreme deluge defaults (velocity 40+)
// is a real CFL violation: cells on the grid cardinal axes have
// velocity (V, 0) or (0, V) — full magnitude on one axis — and
// donor-cell over-pumps them when V·adt > 1. Diagonal cells split
// velocity 50/50 per axis and stay below the threshold longer, so
// they evacuate correctly. The visible cross is cardinal cells
// going negative (K-M renders negative as brighter-than-paper).
// Substep mode subdivides the timestep automatically so peak CFL
// stays ≤ 1 — physically correct, ~2-3× cost during high-velocity
// frames, drops back to 1× as velocities damp. The v0.61 rays
// mechanism doesn't help here because it adds MORE radial fields,
// each with the same CFL violation pattern on the same global grid
// axes — the cross gets reinforced rather than smeared.
// v0.65: Default changed from 'standard' to 'substep' to address CFL
//        violation at v0.60+ extreme deluge defaults.
// v0.66: Substep cap raised 16 → 64 + inner clamp safety because the
//        v0.65 cap wasn't enough at default velocity 40.
// v0.67: Default changed from 'substep' to 'semilag'. Substep fixes
//        CFL violation but not the donor-cell scheme's intrinsic
//        cardinal-axis bias; even with CFL ≤ 1 enforced perfectly,
//        cardinal cells transport pigment ~1.7× more efficiently
//        than diagonals. Semi-Lagrangian removes the anisotropy
//        entirely via backward-trace + bilinear interpolation. The
//        previous "jitter at 0.5" workaround traded cross for visible
//        radial striations; semilag has neither.
let _advectionMode = 'semilag';

// Extracted donor-cell advection pass. Reads from g[], writes to
// g_tmp[] (which the caller must initialize via .set(g[k]) per
// channel first). adt is the effective timestep; useClamp enables
// the per-cell adt cap described above. Same masking + wet-cell
// gating as the v0.56 inlined version.
function _advectStep(adt, useClamp) {
  const y0 = Math.max(1, activeMinY);
  const y1 = Math.min(GH - 2, activeMaxY);
  const x0 = Math.max(1, activeMinX);
  const x1 = Math.min(GW - 2, activeMaxX);
  const maskedRectActive = maskActive;
  for (let y = y0; y <= y1; y++) {
    const yo = y * GW;
    const rowMaybeMasked = maskedRectActive &&
                           y >= maskRectMinY && y <= maskRectMaxY;
    for (let x = x0; x <= x1; x++) {
      const i = yo + x;
      if (rowMaybeMasked && x >= maskRectMinX && x <= maskRectMaxX &&
          mask[i] > MASK_THRESHOLD) continue;
      if (wet[i] < 0.04) continue;
      const ux = u[i], vy = v[i];
      // Effective adt for this cell. Default = adt. With clamp, cap
      // at 1/(|ux|+|vy|) so total outflux can't exceed cell pigment.
      let cellAdt = adt;
      if (useClamp) {
        const lenL1 = Math.abs(ux) + Math.abs(vy);
        if (lenL1 * adt > 1) cellAdt = 1 / lenL1;
      }
      for (let k = 0; k < 3; k++) {
        const gk = g[k][i];
        if (gk < 0.0008) continue;
        let outFlux = 0;
        if (ux > 0) {
          const f = ux * gk * cellAdt;
          g_tmp[k][i + 1] += f; outFlux += f;
        } else if (ux < 0) {
          const f = -ux * gk * cellAdt;
          g_tmp[k][i - 1] += f; outFlux += f;
        }
        if (vy > 0) {
          const f = vy * gk * cellAdt;
          g_tmp[k][i + GW] += f; outFlux += f;
        } else if (vy < 0) {
          const f = -vy * gk * cellAdt;
          g_tmp[k][i - GW] += f; outFlux += f;
        }
        g_tmp[k][i] -= outFlux;
      }

      // v0.97 — Ink advection (parallel to pigment above). Same
      // donor-cell scheme; uses the same shared velocity field
      // (wet-driven). Gated on inkActive — when no ink has been
      // deposited, this loop body is skipped, paying nothing.
      if (inkActive) {
        const ik = ink[i];
        if (ik >= INK_THRESHOLD) {
          let outFlux = 0;
          if (ux > 0) {
            const f = ux * ik * cellAdt;
            ink_tmp[i + 1] += f; outFlux += f;
          } else if (ux < 0) {
            const f = -ux * ik * cellAdt;
            ink_tmp[i - 1] += f; outFlux += f;
          }
          if (vy > 0) {
            const f = vy * ik * cellAdt;
            ink_tmp[i + GW] += f; outFlux += f;
          } else if (vy < 0) {
            const f = -vy * ik * cellAdt;
            ink_tmp[i - GW] += f; outFlux += f;
          }
          ink_tmp[i] -= outFlux;
        }
      }
    }
  }
}

// v0.67 — Semi-Lagrangian advection (v0.68: mass-conserving).
//
// For each cell, look BACKWARD along the velocity vector by `adt`
// time-units to find where the pigment "came from", then sample
// that source position via bilinear interpolation from the 4
// surrounding cells. Mass conservation is applied via a divergence
// correction: multiply the bilinear sample by the area-ratio
// exp(-div(v) * adt), so that pigment in expanding (divergent)
// flow gets diluted as it spreads out, and pigment in converging
// flow accumulates. Without this correction the scheme preserves
// density rather than mass — visually that meant the deluge didn't
// actually "lift and reveal" the canvas at the center, just
// smoothly redistributed pigment in place.
//
// Why this fixes the cross artifact (still true after the
// mass-conserving change): the bilinear interpolation function
// doesn't know which axis is which — it uses continuous source
// coordinates and weights neighbors by proximity, with no
// per-axis donation logic. Direct numerical comparison at
// velocity=40 over 5 frames at d=100 cells:
//   donor-cell:      card/diag ratio = ∞ (negative cells / CFL)
//   semi-Lagrangian: card/diag ratio = 1.001 (perfectly isotropic)
//
// Why the divergence correction restores transport feel:
//   For a radial outflow, ∇·v ≈ 2V/r near the source (large
//   positive divergence). The factor exp(-div*adt) at the center
//   drops density to near zero in one step. Pigment "leaves" the
//   center and (because mass is conserved per cell volume change)
//   accumulates at the wave front where ∇·v transitions toward 0.
//   This matches the donor-cell visual ("lift and reveal a ring of
//   accumulated pigment") without donor-cell's cardinal bias.
//
// Trade-offs vs donor-cell:
//   - Isotropic ✓ (no cardinal preference)
//   - No CFL limit ✓ (bilinear sample handles arbitrary velocity)
//   - Slightly diffusive (bilinear smoothing); for watercolor
//     this softens hard pixel edges, reads as natural blending
//   - Mass conservation is approximate via div-correction; some
//     drift possible over very long simulations, acceptable for
//     deluge-scale events
function _advectStepSemiLagrangian(adt) {
  const y0 = Math.max(1, activeMinY);
  const y1 = Math.min(GH - 2, activeMaxY);
  const x0 = Math.max(1, activeMinX);
  const x1 = Math.min(GW - 2, activeMaxX);
  const maskedRectActive = maskActive;
  const g0 = g[0], g1 = g[1], g2 = g[2];
  const g0t = g_tmp[0], g1t = g_tmp[1], g2t = g_tmp[2];
  for (let y = y0; y <= y1; y++) {
    const yo = y * GW;
    const rowMaybeMasked = maskedRectActive &&
                           y >= maskRectMinY && y <= maskRectMaxY;
    for (let x = x0; x <= x1; x++) {
      const i = yo + x;
      if (rowMaybeMasked && x >= maskRectMinX && x <= maskRectMaxX &&
          mask[i] > MASK_THRESHOLD) continue;
      if (wet[i] < 0.04) continue;
      const ux = u[i], vy = v[i];
      // Mass conservation: scale by area-expansion factor.
      // Divergence via central difference (grid-spacing = 1 cell).
      // For divergent flow (∇·v > 0), area expands, density drops.
      // exp() handles large divergence at the splash epicenter
      // (~2V/r) without going negative the way 1-div*adt would.
      const div = (u[i + 1] - u[i - 1]) * 0.5 +
                  (v[i + GW] - v[i - GW]) * 0.5;
      const areaRatio = Math.exp(-div * adt);
      // Look backward along velocity vector for bilinear sample.
      let sx = x - ux * adt;
      let sy = y - vy * adt;
      // v0.81 — Open-boundary aware clamp. If the back-trace lands
      // outside an OPEN edge, this cell's contents at the new
      // timestep came from off-canvas — treat that as zero pigment
      // (paper background). Cells past CLOSED edges still clamp.
      // The "outside" threshold for openness is the actual grid
      // boundary (sx < 0 means we crossed the left edge, etc.).
      let offCanvas = false;
      if (sx < 0) {
        if (_edgeOpenLeft) offCanvas = true;
        else sx = 0;
      } else if (sx > GW - 1.001) {
        if (_edgeOpenRight) offCanvas = true;
        else sx = GW - 1.001;
      }
      if (sy < 0) {
        if (_edgeOpenTop) offCanvas = true;
        else sy = 0;
      } else if (sy > GH - 1.001) {
        if (_edgeOpenBottom) offCanvas = true;
        else sy = GH - 1.001;
      }
      if (offCanvas) {
        g0t[i] = 0; g1t[i] = 0; g2t[i] = 0;
        if (inkActive) ink_tmp[i] = 0;
        continue;
      }
      const sx0 = sx | 0;
      const sy0_ = sy | 0;
      const fx = sx - sx0;
      const fy = sy - sy0_;
      const w00 = (1 - fx) * (1 - fy);
      const w10 = fx * (1 - fy);
      const w01 = (1 - fx) * fy;
      const w11 = fx * fy;
      const j = sy0_ * GW + sx0;
      g0t[i] = (w00 * g0[j] + w10 * g0[j + 1] + w01 * g0[j + GW] + w11 * g0[j + GW + 1]) * areaRatio;
      g1t[i] = (w00 * g1[j] + w10 * g1[j + 1] + w01 * g1[j + GW] + w11 * g1[j + GW + 1]) * areaRatio;
      g2t[i] = (w00 * g2[j] + w10 * g2[j + 1] + w01 * g2[j + GW] + w11 * g2[j + GW + 1]) * areaRatio;
      // v0.97 — ink advection in semilag mode. Same bilinear back-
      // trace + mass-conserving area ratio as the pigment above.
      if (inkActive) {
        ink_tmp[i] = (w00 * ink[j] + w10 * ink[j + 1] +
                      w01 * ink[j + GW] + w11 * ink[j + GW + 1]) * areaRatio;
      }
    }
  }
}

// Helper for substep mode — copies g_tmp back into g, clamping high
// at MAX_PIGMENT. The 0..N iteration (over the whole grid, not just
// the active rect) matches v0.56's behavior; cells outside the
// active rect are 0 in both buffers so the loop is just memory cost.
function _commitAdvectionCopyback() {
  for (let k = 0; k < 3; k++) {
    const arr = g[k];
    const src = g_tmp[k];
    for (let i = 0; i < N; i++) {
      const vv = src[i];
      arr[i] = vv > MAX_PIGMENT ? MAX_PIGMENT : vv;
    }
  }
  // v0.97 — ink copyback, clamped at 1.0
  if (inkActive) {
    for (let i = 0; i < N; i++) {
      const vv = ink_tmp[i];
      ink[i] = vv > 1 ? 1 : vv;
    }
  }
}

// v0.81 — Drain pigment, water, and pressure at open edges. Semi-
// Lagrangian's back-trace doesn't naturally model mass leaving the
// grid (cells pull from upstream, not push to downstream), so for
// outflow boundaries we run an explicit donor-cell drainage pass
// on the cells adjacent to each open edge. For each such edge cell,
// the OUTGOING flux to off-canvas is `vel_normal · adt · pigment`,
// and that amount is subtracted from the cell.
//
// Velocity normal to an edge: for the bottom edge it's +v (positive
// y is down); for top it's -v; right is +u; left is -u. We only
// drain when the velocity is OUTWARD (positive normal) — inward-
// pointing velocity at an open edge means flow is entering the
// canvas, which is also a valid open-boundary behavior but means no
// drainage occurs on this step. For now we treat inflow as "no
// change" — pigment can't enter from off-canvas because off-canvas
// has zero pigment.
//
// Called from simStep after movePigment, only when at least one
// edge is open. Drains g[], d[], wet[], pressure[] uniformly. The
// CFL-style cap (flux <= cell value) prevents negative values.
function drainBoundaries(adt) {
  if (!(_edgeOpenLeft || _edgeOpenRight || _edgeOpenTop || _edgeOpenBottom)) return;
  const g0 = g[0], g1 = g[1], g2 = g[2];
  const d0 = d[0], d1 = d[1], d2 = d[2];

  // Bottom edge: cells at y = GH-2 (the last interior row), drain
  // proportional to +v.
  if (_edgeOpenBottom) {
    const y = GH - 2;
    for (let x = 1; x < GW - 1; x++) {
      const i = y * GW + x;
      const vy = v[i];
      if (vy <= 0) continue;  // not outflow
      let flux = vy * adt;
      if (flux > 1) flux = 1;
      g0[i] *= (1 - flux); g1[i] *= (1 - flux); g2[i] *= (1 - flux);
      d0[i] *= (1 - flux); d1[i] *= (1 - flux); d2[i] *= (1 - flux);
      wet[i] *= (1 - flux);
      pressure[i] *= (1 - flux);
    }
  }
  // Top edge: cells at y = 1, drain proportional to -v.
  if (_edgeOpenTop) {
    const y = 1;
    for (let x = 1; x < GW - 1; x++) {
      const i = y * GW + x;
      const vy = -v[i];
      if (vy <= 0) continue;
      let flux = vy * adt;
      if (flux > 1) flux = 1;
      g0[i] *= (1 - flux); g1[i] *= (1 - flux); g2[i] *= (1 - flux);
      d0[i] *= (1 - flux); d1[i] *= (1 - flux); d2[i] *= (1 - flux);
      wet[i] *= (1 - flux);
      pressure[i] *= (1 - flux);
    }
  }
  // Right edge: cells at x = GW-2, drain proportional to +u.
  if (_edgeOpenRight) {
    const x = GW - 2;
    for (let y = 1; y < GH - 1; y++) {
      const i = y * GW + x;
      const ux = u[i];
      if (ux <= 0) continue;
      let flux = ux * adt;
      if (flux > 1) flux = 1;
      g0[i] *= (1 - flux); g1[i] *= (1 - flux); g2[i] *= (1 - flux);
      d0[i] *= (1 - flux); d1[i] *= (1 - flux); d2[i] *= (1 - flux);
      wet[i] *= (1 - flux);
      pressure[i] *= (1 - flux);
    }
  }
  // Left edge: cells at x = 1, drain proportional to -u.
  if (_edgeOpenLeft) {
    const x = 1;
    for (let y = 1; y < GH - 1; y++) {
      const i = y * GW + x;
      const ux = -u[i];
      if (ux <= 0) continue;
      let flux = ux * adt;
      if (flux > 1) flux = 1;
      g0[i] *= (1 - flux); g1[i] *= (1 - flux); g2[i] *= (1 - flux);
      d0[i] *= (1 - flux); d1[i] *= (1 - flux); d2[i] *= (1 - flux);
      wet[i] *= (1 - flux);
      pressure[i] *= (1 - flux);
    }
  }
}

// Track the most recently used substep count so the wiring can show
// it ("substep × N") in the UI when the user wants to see how hard
// the sim is working post-deluge. Sampled per movePigment call.
let _lastAdvectionSubsteps = 1;

function movePigment() {
  if (activeRectIsEmpty()) return;
  const baseAdt = DT * 0.7;
  const mode = _advectionMode;

  if (mode === 'substep') {
    // Compute global max L1 cell speed in the active rect so we know
    // how many substeps the worst cell needs. One pass over the
    // active rect; ~N memory reads but no writes.
    let maxL1 = 0;
    const sy0 = Math.max(1, activeMinY);
    const sy1 = Math.min(GH - 2, activeMaxY);
    const sx0 = Math.max(1, activeMinX);
    const sx1 = Math.min(GW - 2, activeMaxX);
    for (let y = sy0; y <= sy1; y++) {
      const yo = y * GW;
      for (let x = sx0; x <= sx1; x++) {
        const i = yo + x;
        const s = Math.abs(u[i]) + Math.abs(v[i]);
        if (s > maxL1) maxL1 = s;
      }
    }
    const cflProduct = maxL1 * baseAdt;
    // v0.66 — Cap raised from 16 to 64. At v0.61 defaults
    // (velocity 40, peak L1 ≈ 56.6), cflProduct ≈ 16.6 which needed
    // 17 substeps but capped at 16, so per-substep CFL stayed at
    // 1.04 — the cardinal cross artifact persisted because each
    // substep was still over the CFL ceiling. At cap 64 the same
    // case uses 17 substeps and per-substep CFL drops to 0.97
    // (under 1, safe). Caps the absolute worst case at ~64 substeps
    // for velocity ~217. Beyond that, an additional within-substep
    // flux clamp kicks in as a safety net (cells can't donate more
    // than they hold). Each substep is ~5ms on a 1080×900 canvas;
    // 64 substeps = ~320ms for one degenerate frame, recovers to 1x
    // within a few frames as velocity damps.
    const numSubsteps = cflProduct <= 1
      ? 1
      : Math.min(64, Math.ceil(cflProduct));
    _lastAdvectionSubsteps = numSubsteps;
    const subDt = baseAdt / numSubsteps;
    // If we're at the cap AND still over CFL=1 per substep, engage
    // flux clamp as a safety net so cells can't go negative. Costs
    // ~5% extra per substep but eliminates the worst over-pumping.
    const perSubstepCfl = maxL1 * subDt;
    const useClampSafety = perSubstepCfl > 1;
    for (let s = 0; s < numSubsteps; s++) {
      for (let k = 0; k < 3; k++) g_tmp[k].set(g[k]);
      if (inkActive) ink_tmp.set(ink);
      _advectStep(subDt, useClampSafety);
      _commitAdvectionCopyback();
    }
  } else if (mode === 'semilag') {
    // v0.67 — Semi-Lagrangian: isotropic backward-trace + bilinear
    // interp. No CFL limit, no substep needed, no cardinal bias.
    // Slightly diffusive (bilinear smoothing) which reads as natural
    // soft watercolor blending — typically a feature.
    _lastAdvectionSubsteps = 1;
    for (let k = 0; k < 3; k++) g_tmp[k].set(g[k]);
    if (inkActive) ink_tmp.set(ink);
    _advectStepSemiLagrangian(baseAdt);
    _commitAdvectionCopyback();
  } else {
    // 'standard' or 'clamp' — single pass at baseAdt.
    _lastAdvectionSubsteps = 1;
    for (let k = 0; k < 3; k++) g_tmp[k].set(g[k]);
    if (inkActive) ink_tmp.set(ink);
    _advectStep(baseAdt, mode === 'clamp');
    _commitAdvectionCopyback();
  }

  // Isotropic diffusion (smooths sharp pixel artifacts, gives soft
  // wet-in-wet feel). Unchanged from v0.56 — runs once regardless of
  // advection mode because the Laplacian doesn't have a CFL issue
  // at PIGMENT_DIFFUSION's small coefficient.
  const y0 = Math.max(1, activeMinY);
  const y1 = Math.min(GH - 2, activeMaxY);
  const x0 = Math.max(1, activeMinX);
  const x1 = Math.min(GW - 2, activeMaxX);
  const tmp0 = g_tmp[0], tmp1 = g_tmp[1], tmp2 = g_tmp[2];
  const arr0 = g[0], arr1 = g[1], arr2 = g[2];
  tmp0.set(arr0); tmp1.set(arr1); tmp2.set(arr2);
  const PD = PIGMENT_DIFFUSION;
  for (let y = y0; y <= y1; y++) {
    const yo = y * GW;
    const rowMaybeMasked = maskActive &&
                           y >= maskRectMinY && y <= maskRectMaxY;
    for (let x = x0; x <= x1; x++) {
      const i = yo + x;
      if (rowMaybeMasked && x >= maskRectMinX && x <= maskRectMaxX &&
          mask[i] > MASK_THRESHOLD) continue;
      if (wet[i] < 0.04) continue;
      const im1 = i - 1, ip1 = i + 1, im_g = i - GW, ip_g = i + GW;
      const c0 = tmp0[i], c1 = tmp1[i], c2 = tmp2[i];
      arr0[i] = c0 + PD * (tmp0[im1] + tmp0[ip1] + tmp0[im_g] + tmp0[ip_g] - 4 * c0);
      arr1[i] = c1 + PD * (tmp1[im1] + tmp1[ip1] + tmp1[im_g] + tmp1[ip_g] - 4 * c1);
      arr2[i] = c2 + PD * (tmp2[im1] + tmp2[ip1] + tmp2[im_g] + tmp2[ip_g] - 4 * c2);
    }
  }
}

// ============================================================
// TRANSFER PIGMENT (§4.5) — adsorption / desorption with granulation γ
// ============================================================
function transferPigment() {
  if (activeRectIsEmpty()) return;
  // Fused single pass: 3 pigments handled inline per cell.
  // The pigment-specific constants are hoisted to locals so V8 can keep
  // them in registers across the inner loop instead of refetching from
  // the PIGMENTS array on every iteration.
  const p0 = PIGMENTS[0], p1 = PIGMENTS[1], p2 = PIGMENTS[2];
  const den0 = p0.density, sta0 = p0.staining, gra0 = p0.granulation;
  const den1 = p1.density, sta1 = p1.staining, gra1 = p1.granulation;
  const den2 = p2.density, sta2 = p2.staining, gra2 = p2.granulation;
  const g0 = g[0], g1 = g[1], g2 = g[2];
  const d0 = d[0], d1 = d[1], d2 = d[2];
  const y0 = Math.max(0, activeMinY);
  const y1 = Math.min(GH - 1, activeMaxY);
  const x0 = Math.max(0, activeMinX);
  const x1 = Math.min(GW - 1, activeMaxX);
  for (let y = y0; y <= y1; y++) {
    const yo = y * GW;
    const rowMaybeMasked = maskActive &&
                           y >= maskRectMinY && y <= maskRectMaxY;
    for (let x = x0; x <= x1; x++) {
      const i = yo + x;
      // Masked cells: no g↔d transfer. Frozen.
      if (rowMaybeMasked && x >= maskRectMinX && x <= maskRectMaxX &&
          mask[i] > MASK_THRESHOLD) continue;
      if (wet[i] < 0.04) continue;
      const h = paperH[i];
      const hg0 = 1 - h * gra0, hg1 = 1 - h * gra1, hg2 = 1 - h * gra2;
      const hu0 = 1 + (h - 1) * gra0, hu1 = 1 + (h - 1) * gra1, hu2 = 1 + (h - 1) * gra2;

      // pigment 0
      let gi = g0[i], di = d0[i];
      let down = gi * hg0 * den0;
      let up   = di * hu0 * den0 / sta0;
      if (down < 0) down = 0;
      if (up   < 0) up   = 0;
      if (di + down > 1) down = 1 - di > 0 ? 1 - di : 0;
      if (gi + up   > 1) up   = 1 - gi > 0 ? 1 - gi : 0;
      d0[i] = di + down - up;
      g0[i] = gi + up   - down;

      // pigment 1
      gi = g1[i]; di = d1[i];
      down = gi * hg1 * den1;
      up   = di * hu1 * den1 / sta1;
      if (down < 0) down = 0;
      if (up   < 0) up   = 0;
      if (di + down > 1) down = 1 - di > 0 ? 1 - di : 0;
      if (gi + up   > 1) up   = 1 - gi > 0 ? 1 - gi : 0;
      d1[i] = di + down - up;
      g1[i] = gi + up   - down;

      // pigment 2
      gi = g2[i]; di = d2[i];
      down = gi * hg2 * den2;
      up   = di * hu2 * den2 / sta2;
      if (down < 0) down = 0;
      if (up   < 0) up   = 0;
      if (di + down > 1) down = 1 - di > 0 ? 1 - di : 0;
      if (gi + up   > 1) up   = 1 - gi > 0 ? 1 - gi : 0;
      d2[i] = di + down - up;
      g2[i] = gi + up   - down;
    }
  }
}

// ============================================================
// EVAPORATION — water slowly leaves the paper
// When a cell goes dry, any suspended pigment locks in as deposited.
// ============================================================
// v0.19 — tunable evaporation rate. Each sim step multiplies wet[i] by
// evaporationRate. The default 0.9988 is the original Curtis-style
// value (water half-life ~578 sim steps ≈ ~9.5 seconds at 60fps).
// The Evaporation slider scales this toward 1.0 (slower) or away from
// it (faster). Faster evaporation cuts the active rect sooner, which
// reclaims sim cost — useful for heavy animations/visualizations at
// the cost of less wet-on-wet bleed and softer edges.
//
// Slider value `mult` (1×..50×) maps to: rate = pow(0.9988, mult).
// At mult=1 we get the original 0.9988; at mult=10 we get ~0.988
// (half-life ~58 steps); at mult=50 we get ~0.94 (half-life ~11 steps).
let evaporationRate = 0.9988;

function evaporate() {
  // v0.19 — mask-rect optimization. Branch ONCE on whether any mask
  // exists at all, then either run a fast path with no mask logic, or
  // a path that checks each cell against the (typically tiny) mask
  // rect. The old code did `maskActive && mask[i] > MASK_THRESHOLD`
  // on every one of N cells (whole grid, not active rect), even when
  // a mask only covered a small region.
  if (!maskActive) {
    for (let i = 0; i < N; i++) {
      let w = wet[i] * evaporationRate;
      if (w < 0.025) {
        for (let k = 0; k < 3; k++) {
          let nd = d[k][i] + g[k][i];
          if (nd > MAX_PIGMENT) nd = MAX_PIGMENT;
          d[k][i] = nd;
          g[k][i] = 0;
        }
        // v0.50 — Fresh paint just settled to the deposited layer.
        // Reset the spring's velocity for this cell so the fade
        // starts from rest, not mid-trajectory from any previous
        // fading state. Cheap branch — only checks the toggle.
        if (fadeEnabled && dVel !== null) {
          dVel[0][i] = 0; dVel[1][i] = 0; dVel[2][i] = 0;
        }
        w = 0;
        u[i] = 0; v[i] = 0;
      }
      wet[i] = w;
    }
  } else {
    // Mask exists. Two-region pass: cells inside the mask rect get the
    // per-cell check; cells outside skip directly to the fast path.
    // This is the v0.19 win — mask checks are restricted to a small
    // sub-area instead of running across the whole grid.
    for (let y = 0; y < GH; y++) {
      const rowMaybeMasked = (y >= maskRectMinY && y <= maskRectMaxY);
      const yo = y * GW;
      for (let x = 0; x < GW; x++) {
        const i = yo + x;
        if (rowMaybeMasked && x >= maskRectMinX && x <= maskRectMaxX &&
            mask[i] > MASK_THRESHOLD) continue;
        let w = wet[i] * evaporationRate;
        if (w < 0.025) {
          for (let k = 0; k < 3; k++) {
            let nd = d[k][i] + g[k][i];
            if (nd > MAX_PIGMENT) nd = MAX_PIGMENT;
            d[k][i] = nd;
            g[k][i] = 0;
          }
          // v0.50 — Fresh paint settled into d[]; reset spring velocity
          // so fade starts from rest. See twin block above.
          if (fadeEnabled && dVel !== null) {
            dVel[0][i] = 0; dVel[1][i] = 0; dVel[2][i] = 0;
          }
          w = 0;
          u[i] = 0; v[i] = 0;
        }
        wet[i] = w;
      }
    }
  }
}

// ============================================================
// SIM STEP
// Two toggles (see UI wiring below) gate the relevant sub-steps:
//   edgeDarkeningEnabled — when off, the §4.3.3 outward-flow pressure
//     reduction is skipped entirely. Useful for isolating which marks
//     come from edge darkening vs. natural diffusion/advection.
//   dryingPaused         — when on, evaporation is skipped, so the
//     canvas holds its current wetness indefinitely (whatever that
//     happens to be — fully wet, partially dry, or anywhere between).
// ============================================================
let edgeDarkeningEnabled = true;
let dryingPaused = false;

// ============================================================
// WET DIFFUSION (added v0.8) — water spreads to adjacent cells
// over time, modeling capillary action through paper fibers.
// ============================================================
// Without this, paintAt's wet bump stays confined to the brush
// footprint, so on dry paper each brush stamp creates an island
// of wet trapped inside dry surroundings. Pigment can move within
// the island but can't cross the wet→dry boundary, so brush stamps
// show as hard-edged stamps. With wet diffusion, the wet itself
// expands outward, creating a soft halo ahead of the pigment so
// dry-paper strokes get the same soft falloff as wet-on-wet strokes.
//
// Standard Laplacian diffusion: each cell exchanges with its 4
// neighbors based on the local gradient. Conserves total wet
// (in the interior); boundary cells are skipped. Coefficient 0.10
// is tuned so that a 0.45-wet brush center transfers 0.045 to each
// neighbor per step, just clearing the wet >= 0.04 threshold so
// the rest of the sim picks up those cells as active. Stability
// bound for an explicit 4-neighbor scheme is 0.25; we're well under.
// SCALE-derived: same scaling as PIGMENT_DIFFUSION. At SCALE_REF (s=1)
// gives 0.10, the v0.8 baseline tuned so a 0.45 wet brush stamp
// transfers ~0.045 to neighbors per step — just clearing the wet >= 0.04
// threshold needed for the rest of the sim to flow pigment into them.
let WET_DIFFUSION = Math.min(0.20, 0.10 * inv_s2);

function diffuseWet() {
  if (activeRectIsEmpty()) return;
  wet_tmp.set(wet);
  const k = WET_DIFFUSION;
  const y0 = Math.max(1, activeMinY);
  const y1 = Math.min(GH - 2, activeMaxY);
  const x0 = Math.max(1, activeMinX);
  const x1 = Math.min(GW - 2, activeMaxX);
  for (let y = y0; y <= y1; y++) {
    const yo = y * GW;
    const rowMaybeMasked = maskActive &&
                           y >= maskRectMinY && y <= maskRectMaxY;
    for (let x = x0; x <= x1; x++) {
      const i = yo + x;
      // Masked cells are frozen — wet can't diffuse into or out of them.
      if (rowMaybeMasked && x >= maskRectMinX && x <= maskRectMaxX &&
          mask[i] > MASK_THRESHOLD) continue;
      // Skip cells with no wet anywhere in the 5-cell stencil — the
      // Laplacian is zero, no change would result. This is the common
      // case in unpainted areas.
      const c  = wet_tmp[i];
      const wa = wet_tmp[i - 1],  wb = wet_tmp[i + 1];
      const wc = wet_tmp[i - GW], wd = wet_tmp[i + GW];
      if (c < 1e-6 && wa < 1e-6 && wb < 1e-6 && wc < 1e-6 && wd < 1e-6) continue;
      wet[i] = c + k * (wa + wb + wc + wd - 4 * c);
    }
  }
}

function simStep() {
  // v0.10 — top-level early return when nothing is active. Each sub-step
  // already early-returns on empty rect, but the function-call overhead
  // for 5 dispatched calls × 2 simSteps × 60 fps adds up at idle. This
  // one check skips them all. evaporate is intentionally NOT gated:
  // global drying continues even with no active region so the "wet
  // canvas" surface dries down over time as expected.
  if (activeRectIsEmpty()) {
    if (!dryingPaused) evaporate();
    return;
  }
  diffuseWet();
  if (edgeDarkeningEnabled) applyEdgeDarkening();
  updateVelocity();
  movePigment();
  // v0.81 — open-boundary outflow drainage. No-op when all edges
  // closed. Runs after movePigment so the drained values include the
  // result of this frame's advection. adt matches movePigment's
  // baseAdt (DT * 0.7).
  drainBoundaries(DT * 0.7);
  transferPigment();
  if (!dryingPaused) evaporate();
}

// ============================================================
// KUBELKA–MUNK COMPOSITING (§5)
// Returns reflectance R of a layer of given thickness x with
// weighted K and S, composited over a paper background of
// reflectance Rbg, for a single wavelength channel.
// ============================================================
function kmReflect(K, S, x, Rbg) {
  if (S < 1e-5) S = 1e-5;
  const a = 1 + K / S;
  const b = Math.sqrt(Math.max(0, a * a - 1));
  let bSx = b * S * x;
  if (bSx > 12) bSx = 12; // prevents sinh/cosh overflow; visually equivalent
  const sh = Math.sinh(bSx);
  const ch = Math.cosh(bSx);
  const denom = a * sh + b * ch;
  if (denom < 1e-9) return 0;
  const Rlayer = sh / denom;
  const Tlayer = b  / denom;
  let R = Rlayer + (Tlayer * Tlayer * Rbg) / (1 - Rlayer * Rbg);
  if (R < 0) R = 0; else if (R > 1) R = 1;
  return R;
}

// ============================================================
// RENDER — KM compositing per cell, then upscale to display canvas
// ============================================================
const renderCanvas = document.createElement('canvas');
renderCanvas.width  = GW;
renderCanvas.height = GH;
const renderCtx = renderCanvas.getContext('2d');
let imgData = renderCtx.createImageData(GW, GH);

// canvas is declared at the top of the factory (per-instance,
// mounted inside targetEl). Size it here and create the 2D context
// the render path uses.
canvas.width  = DISPLAY_W;
canvas.height = DISPLAY_H;
const ctx = canvas.getContext('2d');
ctx.imageSmoothingEnabled = true;
ctx.imageSmoothingQuality = 'high';

// Paper base colors per channel (warm cream). Mutable so the paper
// picker UI can change them at runtime — every site that uses them
// (the render loop's KM substrate, the swatch canvases, the cursor
// color computation) re-reads on demand, so a reassignment plus a
// swatch rebuild is all that's needed to recolor the paper.
let PAPER_R_BASE = 0.985;
let PAPER_G_BASE = 0.965;
let PAPER_B_BASE = 0.918;

// render(forceFull=false) — write RGBA pixels to imgData, then push to
// renderCanvas and scale to the display canvas.
//
// v0.10 localization: when the active rect is non-empty and forceFull
// is false, the per-cell KM/alpha loop iterates only over the active
// rect. Cells outside the rect have frozen state (active rect tracks
// all dynamics by definition), so the imgData bytes left over from
// when they WERE rendered still match their current sim state.
//
// putImageData transfers the full imgData buffer each call regardless
// — its cost is a memcpy, dwarfed by the per-cell KM math we just
// avoided. The scale to the display canvas is GPU work, also fixed.
//
// forceFull is set by callers that change something which affects
// v0.86 — Wetness heatmap renderer. Creates (lazily) an overlay
// canvas matching the main canvas dimensions, then maps wet[] through
// a two-color gradient and writes the result to that overlay.
// Compositing is via the browser (overlay sits above main canvas at
// z-index 10), not via the lib's own pixel pipeline, so toggling on
// and off is cheap and the heatmap doesn't affect the simulation.
function _renderWetnessHeatmap() {
  if (!_wetnessHeatmapEnabled) {
    if (_wetnessOverlayCanvas) _wetnessOverlayCanvas.style.opacity = '0';
    return;
  }
  // Lazy-create the overlay canvas the first time the heatmap is
  // shown. Sized in display pixels, same as the main canvas.
  if (!_wetnessOverlayCanvas) {
    _wetnessOverlayCanvas = document.createElement('canvas');
    _wetnessOverlayCanvas.width  = canvas.width;
    _wetnessOverlayCanvas.height = canvas.height;
    _wetnessOverlayCanvas.style.cssText =
      'display:block;position:absolute;inset:0;width:100%;height:100%;' +
      'pointer-events:none;z-index:10;opacity:0;' +
      'transition:opacity 0.18s ease-out;';
    targetEl.appendChild(_wetnessOverlayCanvas);
    _wetnessOverlayCtx = _wetnessOverlayCanvas.getContext('2d');
  }
  // Resize overlay if canvas was resized.
  if (_wetnessOverlayCanvas.width !== canvas.width ||
      _wetnessOverlayCanvas.height !== canvas.height) {
    _wetnessOverlayCanvas.width  = canvas.width;
    _wetnessOverlayCanvas.height = canvas.height;
    _wetnessOverlayImageData = null;
  }
  // The simulation grid is smaller than the display canvas. Render
  // the heatmap at grid resolution into a small ImageData, then let
  // the browser's drawImage upsample. This is much faster than
  // touching every display pixel.
  if (!_wetnessOverlayImageData || _wetnessOverlayImageData.width !== GW) {
    _wetnessOverlayImageData = _wetnessOverlayCtx.createImageData(GW, GH);
  }
  const dst = _wetnessOverlayImageData.data;
  const r0 = _wetnessLowColor[0],  g0 = _wetnessLowColor[1],  b0 = _wetnessLowColor[2];
  const r1 = _wetnessHighColor[0], g1 = _wetnessHighColor[1], b1 = _wetnessHighColor[2];
  // wet[] is 0..~1.5. Normalize against MAX_WET so saturated cells
  // hit the full high-color. Below MASK_THRESHOLD render fully
  // transparent (no overlay over genuinely dry paper, so the user
  // can see the painting underneath the gradient).
  const MAX_WET = 1.0;
  for (let i = 0; i < N; i++) {
    const w = wet[i];
    const di = i * 4;
    if (w < MASK_THRESHOLD) {
      dst[di + 3] = 0;
      continue;
    }
    let t = w / MAX_WET;
    if (t > 1) t = 1;
    dst[di    ] = (r0 + (r1 - r0) * t) | 0;
    dst[di + 1] = (g0 + (g1 - g0) * t) | 0;
    dst[di + 2] = (b0 + (b1 - b0) * t) | 0;
    dst[di + 3] = 160;  // ~63% alpha so painting stays visible underneath
  }
  // Upload the grid-resolution ImageData to a tiny offscreen canvas
  // so we can use drawImage's bilinear upsampling to fill the
  // full-size overlay. Putting ImageData directly is 1:1 pixel
  // (would render the overlay at grid resolution scaled by CSS,
  // which looks blocky on retina).
  if (!_wetnessOverlayCanvas._tinyCanvas) {
    _wetnessOverlayCanvas._tinyCanvas = document.createElement('canvas');
    _wetnessOverlayCanvas._tinyCanvas.width = GW;
    _wetnessOverlayCanvas._tinyCanvas.height = GH;
    _wetnessOverlayCanvas._tinyCtx = _wetnessOverlayCanvas._tinyCanvas.getContext('2d');
  }
  if (_wetnessOverlayCanvas._tinyCanvas.width !== GW) {
    _wetnessOverlayCanvas._tinyCanvas.width = GW;
    _wetnessOverlayCanvas._tinyCanvas.height = GH;
  }
  _wetnessOverlayCanvas._tinyCtx.putImageData(_wetnessOverlayImageData, 0, 0);
  _wetnessOverlayCtx.clearRect(0, 0, canvas.width, canvas.height);
  _wetnessOverlayCtx.imageSmoothingEnabled = true;
  _wetnessOverlayCtx.drawImage(
    _wetnessOverlayCanvas._tinyCanvas,
    0, 0, GW, GH,
    0, 0, canvas.width, canvas.height
  );
  _wetnessOverlayCanvas.style.opacity = '1';
}

// pixels outside the active rect — currently just paper color change.
// The "Transparent" toggle only changes body CSS, not canvas pixels.
function render(forceFull) {
  const data = imgData.data;
  const P0 = PIGMENTS[0], P1 = PIGMENTS[1], P2 = PIGMENTS[2];

  // Alpha fade-in for the lowest pigment amounts. Cells with xt above
  // this threshold render fully opaque (so painted regions look exactly
  // the way they would over an opaque cream canvas — KM math unchanged);
  // cells with xt = 0 go fully transparent (body color shows through);
  // a thin transition band gives anti-aliased edges instead of a hard cut.
  const ALPHA_FULL_AT = 0.012;
  const ALPHA_SCALE = 255 / ALPHA_FULL_AT;

  // Determine iteration bounds. Empty rect + !forceFull = skip the per-cell
  // loop entirely; imgData is already correct for the frozen state, so
  // pushing it again would just waste a memcpy + draw.
  let yStart, yEnd, xStart, xEnd, isFull;
  if (forceFull) {
    yStart = 0; yEnd = GH - 1;
    xStart = 0; xEnd = GW - 1;
    isFull = true;
  } else if (activeRectIsEmpty()) {
    return;
  } else {
    yStart = Math.max(0, activeMinY);
    yEnd   = Math.min(GH - 1, activeMaxY);
    xStart = Math.max(0, activeMinX);
    xEnd   = Math.min(GW - 1, activeMaxX);
    isFull = (yStart === 0 && yEnd === GH - 1 && xStart === 0 && xEnd === GW - 1);
  }

  // Hoist the array refs once. The original loop accessed g[k][i] via
  // two-level lookup; localized or not, the cached refs help.
  const g0 = g[0], g1 = g[1], g2 = g[2];
  const d0 = d[0], d1 = d[1], d2 = d[2];

  // v0.88 — precompute edge fade constants. Active only when
  // _edgeFadePixels > 0. We compute the alpha multiplier as
  // smoothstep(0, fade, dist_to_nearest_edge) — cells far from any
  // edge get 1.0, cells right at the edge get 0.0.
  const _fadePx = _edgeFadePixels;
  const _fadeActive = _fadePx > 0;
  const _GWm1 = GW - 1;
  const _GHm1 = GH - 1;
  const _invFade = _fadeActive ? (1 / _fadePx) : 0;

  for (let y = yStart; y <= yEnd; y++) {
    const yo = y * GW;
    // v0.19 — mask rect optimization. Outside the mask rect's row
    // range, the mask tint branch can be skipped entirely without
    // even loading mask[i] for cells in this row.
    const rowMaybeMasked = maskActive &&
                           y >= maskRectMinY && y <= maskRectMaxY;
    // v0.88 — y-distance to nearest horizontal edge. Hoisted out
    // of the inner loop since it depends only on y.
    const _distY = _fadeActive ? Math.min(y, _GHm1 - y) : 0;
    for (let x = xStart; x <= xEnd; x++) {
      const i = yo + x;

      const x0 = g0[i] + d0[i];
      const x1 = g1[i] + d1[i];
      const x2 = g2[i] + d2[i];
      const xt = x0 + x1 + x2;
      const ph = paperH[i];

      // Paper texture: subtle warm variation
      const tex = (ph - 0.5) * 0.06;
      const PR = PAPER_R_BASE + tex;
      const PG = PAPER_G_BASE + tex;
      const PB = PAPER_B_BASE + tex;

      let R, G, B;

      if (xt < 0.004) {
        // Just paper (with possible dampness sheen)
        const dampSheen = wet[i] * 0.018;
        R = PR + dampSheen;
        G = PG + dampSheen;
        B = PB + dampSheen * 1.2;
      } else {
        const inv = 1 / xt;
        const w0 = x0 * inv, w1 = x1 * inv, w2 = x2 * inv;
        // Weighted K and S
        const Kr = P0.K[0]*w0 + P1.K[0]*w1 + P2.K[0]*w2;
        const Kg = P0.K[1]*w0 + P1.K[1]*w1 + P2.K[1]*w2;
        const Kb = P0.K[2]*w0 + P1.K[2]*w1 + P2.K[2]*w2;
        const Sr = P0.S[0]*w0 + P1.S[0]*w1 + P2.S[0]*w2;
        const Sg = P0.S[1]*w0 + P1.S[1]*w1 + P2.S[1]*w2;
        const Sb = P0.S[2]*w0 + P1.S[2]*w1 + P2.S[2]*w2;

        const thickness = xt < 4 ? xt : 4;

        R = kmReflect(Kr, Sr, thickness, PR);
        G = kmReflect(Kg, Sg, thickness, PG);
        B = kmReflect(Kb, Sb, thickness, PB);
      }

      // Alpha: pigment thickness determines opacity in the body-bg-shows-
      // through scheme. Saturated cells are fully opaque, sparse cells
      // anti-alias against the page background.
      let alpha = xt >= ALPHA_FULL_AT ? 255 : (xt * ALPHA_SCALE);

      // v0.13.1 — translucent diffused masking-fluid tint. Computed AFTER
      // the normal KM/paper render so the user sees through the mask to
      // whatever pigment + paper is underneath, with a warm yellow shift.
      //
      // The blend amount ramps continuously with mask[i]: very lightly
      // masked cells (just over threshold) get a faint hint; fully masked
      // cells get the strongest tint, capped at MASK_TINT_PEAK so even
      // dense mask never fully obscures the pigment beneath. Soft edges
      // fall out of the brush stamp's natural falloff — neighboring cells
      // have smoothly varying mask values, and the visual scales with them.
      // v0.80 — _maskTintVisible gates the amber tint; when false,
      // freeze is unchanged but the tint is skipped so masked cells
      // render as ordinary paper/pigment.
      if (_maskTintVisible &&
          rowMaybeMasked && x >= maskRectMinX && x <= maskRectMaxX &&
          mask[i] > MASK_THRESHOLD) {
        const maskVis = Math.min(1,
          (mask[i] - MASK_THRESHOLD) / (MASK_VISUAL_FULL - MASK_THRESHOLD));
        const tb = maskVis * MASK_TINT_PEAK;
        // Pale warm yellow (masking-fluid amber). Same hue as the swatch.
        R = R * (1 - tb) + 0.96 * tb;
        G = G * (1 - tb) + 0.86 * tb;
        B = B * (1 - tb) + 0.42 * tb;
        // Boost alpha so masked-but-unpainted cells stay visible — but
        // cap below 255 so the mask itself reads as slightly translucent
        // (body bg shows through faintly when in transparent-canvas mode).
        const maskAlpha = maskVis * 215;
        if (maskAlpha > alpha) alpha = maskAlpha;
      }

      // v0.97 — Ink darkening. Applied AFTER mask tint so ink shows
      // through the mask amber-tint at full strength rather than
      // getting blended away. Multiplies the rendered R/G/B by
      // (1 - ink * INK_ALPHA), so ink at concentration 1.0 reduces
      // each channel by 95% (near-black; not exactly zero, which
      // would render as a hole rather than a mark).
      if (inkActive) {
        const inkAmt = ink[i];
        if (inkAmt > INK_THRESHOLD) {
          const darken = 1 - inkAmt * INK_ALPHA;
          R *= darken;
          G *= darken;
          B *= darken;
          // Ink also forces full opacity at the inked cell — even
          // if pigment is sparse, the ink mark should be visible.
          // This is what makes printed-text-on-paper look right.
          if (alpha < 255) alpha = 255;
        }
      }

      const j = i * 4;
      data[j]     = R * 255;
      data[j + 1] = G * 255;
      data[j + 2] = B * 255;
      // v0.88 — edge fade: smoothstep alpha multiplier from 0 at
      // boundary to 1 at fade-depth from boundary. Hides pigment
      // buildup near edges in closed-gravity mode (or anywhere else
      // it's desired). No-op when _edgeFadePixels is 0.
      if (_fadeActive) {
        const distX = x < _GWm1 - x ? x : _GWm1 - x;
        const dist = distX < _distY ? distX : _distY;
        if (dist < _fadePx) {
          let t = dist * _invFade;
          if (t < 0) t = 0; else if (t > 1) t = 1;
          alpha *= t * t * (3 - 2 * t);
        }
      }
      data[j + 3] = alpha;
    }
  }

  // Push to renderCanvas. dirtyRect form of putImageData transfers only
  // the active sub-region — useful when localized, no-op when full.
  if (isFull) {
    renderCtx.putImageData(imgData, 0, 0);
  } else {
    const dw = xEnd - xStart + 1;
    const dh = yEnd - yStart + 1;
    renderCtx.putImageData(imgData, 0, 0, xStart, yStart, dw, dh);
  }
  // Clear the display canvas so transparent regions of the new frame
  // don't blend over stale pixels from the previous frame.
  ctx.clearRect(0, 0, DISPLAY_W, DISPLAY_H);
  ctx.drawImage(renderCanvas, 0, 0, DISPLAY_W, DISPLAY_H);
  // v0.86 — wetness heatmap overlay (no-op when disabled).
  _renderWetnessHeatmap();
}

// ============================================================
// PAINT BRUSH
// ============================================================
function paintAt(gx, gy, gridRadius, pigmentIdx, strength) {
  // v2 — Scale gridRadius by the canvas-size factor so brushes from
  // animations/visualizations stay visually proportional on small
  // canvases. _canvasScale is 1.0 for canvases ≥ REFERENCE_DISPLAY_W.
  gridRadius *= _canvasScale;
  markCanvasActive();  // wake the sim if it was idle
  expandActiveRect(gx, gy, gridRadius);  // grow active region to cover this stamp
  const r = gridRadius;
  const r2 = r * r;
  const minX = Math.max(0, Math.floor(gx - r));
  const maxX = Math.min(GW - 1, Math.ceil(gx + r));
  const minY = Math.max(0, Math.floor(gy - r));
  const maxY = Math.min(GH - 1, Math.ceil(gy + r));

  // Masking fluid (v0.13). Deposits mask into the mask[] array.
  // Doesn't add wet, doesn't add pressure — masking fluid is a passive
  // resist applied on top of the paper. Once any cell crosses
  // MASK_THRESHOLD, maskActive is set so sim functions know to test.
  if (pigmentIdx === MASK_INDEX) {
    let anyAboveThreshold = false;
    // v0.19 — track bounds of cells that cross the threshold for the
    // mask-rect optimization. minX/maxX etc. local to this branch are
    // the brush footprint (paintAt arg); we accumulate which of those
    // actually became masked into the global maskRect.
    let rMinX = GW, rMaxX = -1, rMinY = GH, rMaxY = -1;
    for (let py = minY; py <= maxY; py++) {
      for (let px = minX; px <= maxX; px++) {
        const dx = px - gx, dy = py - gy;
        const d2 = dx * dx + dy * dy;
        if (d2 > r2) continue;
        const i = py * GW + px;
        const falloff = 1 - Math.sqrt(d2) / r;
        // Accumulate mask deposit, capped at 1. Strength scales how
        // quickly a single stamp builds — at strength=0.5, two dabs at
        // the brush center push above threshold.
        const m = mask[i] + falloff * strength;
        mask[i] = m > 1 ? 1 : m;
        if (mask[i] > MASK_THRESHOLD) {
          anyAboveThreshold = true;
          if (px < rMinX) rMinX = px;
          if (px > rMaxX) rMaxX = px;
          if (py < rMinY) rMinY = py;
          if (py > rMaxY) rMaxY = py;
        }
      }
    }
    if (anyAboveThreshold) {
      maskActive = true;
      // Expand the global mask rect to include the freshly-masked cells.
      if (rMinX < maskRectMinX) maskRectMinX = rMinX;
      if (rMaxX > maskRectMaxX) maskRectMaxX = rMaxX;
      if (rMinY < maskRectMinY) maskRectMinY = rMinY;
      if (rMaxY > maskRectMaxY) maskRectMaxY = rMaxY;
    }
    return;
  }

  // v0.97 — Ink branch. Deposits into the single-channel ink[] array
  // outside the K-M pigment system. Caller's `strength` is the per-cell
  // paint amount; the high `inkPaintLoadDefault` (1.0 by default) means
  // a single stamp at default strength saturates the cell. The water
  // load is intentionally low so default ink stamps don't bleed
  // themselves — only when external wet (from pigment splashes) reaches
  // the inked cells do they bloom via the shared velocity field.
  //
  // Per-stamp paint/water load can be overridden by setting the
  // module-level defaults via wc.inkPaintLoad() / wc.inkWaterLoad().
  if (pigmentIdx === INK_INDEX) {
    const inkGain = inkPaintLoadDefault;
    const wetGain = inkWaterLoadDefault * 0.55; // mirror the water-brush
                                                 // baseline (which uses
                                                 // 0.55 * waterLoadMult)
    for (let py = minY; py <= maxY; py++) {
      for (let px = minX; px <= maxX; px++) {
        const dx = px - gx, dy = py - gy;
        const d2 = dx * dx + dy * dy;
        if (d2 > r2) continue;
        const i = py * GW + px;
        // Masked cells reject ink, same as pigment.
        if (maskActive && mask[i] > MASK_THRESHOLD) continue;
        const falloff = 1 - Math.sqrt(d2) / r;
        // Quadratic falloff for ink — gives a slightly more solid
        // center than linear, helping crisp letter centers stay
        // saturated when stamps overlap on a glyph stroke.
        const f2 = falloff * falloff;
        const add = strength * f2 * inkGain;
        const newInk = ink[i] + add;
        ink[i] = newInk > 1 ? 1 : newInk;
        // Light wet deposit to keep advection coupling alive. Default
        // load is low (0.05) so this is well below the pigment brush's
        // 0.55 — letters stay crisp by default. User can raise the
        // water load if they want self-blooming ink.
        if (wetGain > 0) {
          const ww = wet[i] + wetGain * falloff;
          wet[i] = ww > 1 ? 1 : ww;
        }
      }
    }
    inkActive = true;
    return;
  }

  // Water brush: no pigment added. Adds water + pressure (drives bleed)
  // and lifts a fraction of deposited pigment back into suspension at
  // each touched cell — same desorption shortcut the global re-wet
  // button uses, but localized. This lets a clean wet brush re-mobilize
  // dry pigment for blending, softening edges, or washing out.
  if (pigmentIdx === WATER_INDEX) {
    // v0.22 — water-load multiplier. Scales all three water-brush
    // deposits together (wet, pressure, lift) so the user can dial
    // "wetter" or "drier" water with a single control. The lift
    // amount has to be clamped to 1.0 because it's a fraction (you
    // can't lift more than 100% of what's there); the wet+pressure
    // values clamp via the existing per-cell maxima.
    const wetGain  = 0.55 * waterLoadMult;
    const presGain = 0.18 * waterLoadMult;
    const liftGain = Math.min(1.0, 0.18 * waterLoadMult);
    for (let py = minY; py <= maxY; py++) {
      for (let px = minX; px <= maxX; px++) {
        const dx = px - gx, dy = py - gy;
        const d2 = dx * dx + dy * dy;
        if (d2 > r2) continue;
        const i = py * GW + px;
        // Masked cells resist water — masking fluid is hydrophobic.
        if (maskActive && mask[i] > MASK_THRESHOLD) continue;
        const falloff = 1 - Math.sqrt(d2) / r;
        const f2 = falloff * falloff;
        const ww = wet[i] + wetGain * falloff;
        wet[i] = ww > 1 ? 1 : ww;
        pressure[i] += presGain * f2;
        // Localized lift of deposited pigment. Per-frame fraction is
        // gentler than the global re-wet (which is one-shot at 0.30);
        // here the user can hold/drag to escalate.
        const liftFrac = liftGain * f2;
        if (liftFrac > 0) {
          for (let k = 0; k < 3; k++) {
            const dval = d[k][i];
            if (dval < 0.001) continue;
            const lift = dval * liftFrac;
            d[k][i] = dval - lift;
            const nv = g[k][i] + lift;
            g[k][i] = nv > MAX_PIGMENT ? MAX_PIGMENT : nv;
          }
        }
      }
    }
    return;
  }

  // Lift brush: removes pigment (both suspended g and deposited d) from
  // each touched cell. Leaves wet and pressure alone — that way a drag
  // doesn't create dry islands or drive flow; the cell's surroundings
  // stay intact and only the pigment in the touched area fades. Drag
  // and the subtraction compounds: at the brush center (f²=1) a single
  // dab keeps 1 − 0.22 = 78%, five dabs keep 28%, ten dabs keep 8%.
  if (pigmentIdx === LIFT_INDEX) {
    for (let py = minY; py <= maxY; py++) {
      for (let px = minX; px <= maxX; px++) {
        const dx = px - gx, dy = py - gy;
        const d2 = dx * dx + dy * dy;
        if (d2 > r2) continue;
        const i = py * GW + px;
        // Masked cells keep their pigment frozen — lift can't reach it.
        if (maskActive && mask[i] > MASK_THRESHOLD) continue;
        const falloff = 1 - Math.sqrt(d2) / r;
        const f2 = falloff * falloff;
        const subFrac = 0.22 * f2;
        if (subFrac <= 0) continue;
        const keep = 1 - subFrac;
        for (let k = 0; k < 3; k++) {
          g[k][i] *= keep;
          d[k][i] *= keep;
        }
      }
    }
    return;
  }

  // v0.32 — Paper brush. Clears deposited + suspended pigment in the
  // footprint and adds wetness. Visually equivalent to painting opaque
  // paper-color paint over the area — except it dynamically follows
  // whatever paperColor() returns (no separate "white" pigment to
  // re-tune if you change paper color). Masked cells are frozen as
  // usual — paper brush can't reach them.
  if (pigmentIdx === PAPER_INDEX) {
    const wetGain = 0.35 * waterLoadMult;  // mild wetness for visual feedback
    for (let py = minY; py <= maxY; py++) {
      for (let px = minX; px <= maxX; px++) {
        const dx = px - gx, dy = py - gy;
        const d2 = dx * dx + dy * dy;
        if (d2 > r2) continue;
        const i = py * GW + px;
        if (maskActive && mask[i] > MASK_THRESHOLD) continue;
        const falloff = 1 - Math.sqrt(d2) / r;
        const f2 = falloff * falloff;
        // Scale clearance by stamp strength + falloff. At full strength
        // and stamp center, deposited pigment is wiped entirely; toward
        // the edges of the brush footprint it tapers smoothly so brush
        // strokes have soft edges rather than hard discs.
        const clearAmount = strength * f2;
        const keep = Math.max(0, 1 - clearAmount);
        d[0][i] *= keep; d[1][i] *= keep; d[2][i] *= keep;
        g[0][i] *= keep; g[1][i] *= keep; g[2][i] *= keep;
        // Add a touch of wetness so the brush stroke "carries" — the
        // wash bleeds outward through the simulation, blending into
        // surrounding cells the way an opaque-paint stroke softens at
        // its border on real wet paper.
        const wetAdd = f2 * strength * wetGain;
        const nw = wet[i] + wetAdd;
        wet[i] = nw > 1 ? 1 : nw;
      }
    }
    return;
  }

  // Rainbow brush — same dynamics as a regular pigment brush, but the
  // strength is split across all three g[] arrays weighted by the
  // current cycle position. Weights are computed once per paintAt call
  // (not per cell), so every cell in this stamp gets the same color
  // mix; the color cycles between stamps over time.
  if (pigmentIdx === RAINBOW_INDEX) {
    updateRainbowWeights(performance.now());
    const w0 = rainbowW[0], w1 = rainbowW[1], w2 = rainbowW[2];
    const g0 = g[0], g1 = g[1], g2 = g[2];    // v0.22.2 — hoist water-load-scaled gains outside the inner loop.
    // Previously these multiplications ran per-cell; now they're
    // computed once per paintAt call. Equivalent math, fewer ops in
    // the stamp's hot path.
    const wetGain  = 0.45 * waterLoadMult;
    const presGain = 0.18 * waterLoadMult;
    // v0.59 — paintLoadMult was declared back in v0.22 but never
    // actually applied to deposits, so changing the Paint Load slider
    // had no visible effect on dab density (latent bug; spotted while
    // testing the v0.58 splash opts). Scale the per-cell deposit term
    // by paintLoadMult here so the slider does what its label says.
    // Wet + pressure stay water-side: that's why waterLoadMult exists
    // as a separate axis.
    const depositMult = paintLoadMult;
    for (let py = minY; py <= maxY; py++) {
      for (let px = minX; px <= maxX; px++) {
        const dx = px - gx, dy = py - gy;
        const d2 = dx * dx + dy * dy;
        if (d2 > r2) continue;
        const i = py * GW + px;
        // Masked cells reject pigment.
        if (maskActive && mask[i] > MASK_THRESHOLD) continue;
        const falloff = 1 - Math.sqrt(d2) / r;
        const f2 = falloff * falloff;
        const add = strength * f2 * depositMult;
        // Per-pigment deposit, weighted. Each pigment is independently
        // clamped to MAX_PIGMENT — a saturated cell of one pigment
        // doesn't block deposits of the other two.
        let na = g0[i] + add * w0; if (na > MAX_PIGMENT) na = MAX_PIGMENT; g0[i] = na;
            na = g1[i] + add * w1; if (na > MAX_PIGMENT) na = MAX_PIGMENT; g1[i] = na;
            na = g2[i] + add * w2; if (na > MAX_PIGMENT) na = MAX_PIGMENT; g2[i] = na;
        // wet + pressure scale with waterLoadMult — see hoisted gains
        // above. The per-cell wet cap at 1.0 still applies; pressure
        // has no cap so it directly drives stronger flow.
        const ww = wet[i] + wetGain * falloff;
        wet[i] = ww > 1 ? 1 : ww;
        pressure[i] += presGain * f2;
      }
    }
    return;
  }

  const arr = g[pigmentIdx];
  // v0.22.2 — hoist water-load-scaled gains outside the inner loop,
  // matching the rainbow + water branches above.
  const pigWetGain  = 0.45 * waterLoadMult;
  const pigPresGain = 0.18 * waterLoadMult;
  // v0.59 — paintLoadMult applied to deposit; see rainbow branch
  // above for the rationale. Hoist outside the loop so V8 keeps it
  // in a register.
  const pigDepositMult = paintLoadMult;

  // v0.98 — Texture mode: dispatch per-mode parameters before
  // entering the deposit loop. Each texture has its own:
  //   - noise field (which sample drives rejection)
  //   - threshold formula (sharp/soft, low/high)
  //   - anisotropy weight (motion-direction contribution)
  //   - water-reduction multiplier (some textures keep more
  //     water, e.g. salt blooms shouldn't be totally dry)
  //
  // All these are hoisted outside the inner loop so the per-cell
  // dispatch is a constant array read + a couple of multiplies.
  // When _brushMode === 'wet', textureActive is false and the
  // deposit math collapses back to the original smooth quadratic.
  let textureActive = false;
  let textureField = null;       // which noise field to sample
  let textureBaseThresh = 0;     // base threshold value at full dryness
  let textureBandHalf = 0.05;    // width of the smoothstep band
  let textureAnisoK = 0;         // anisotropy contribution coefficient
  let textureWaterMult = 1;      // water deposit multiplier
  let texturePaperWeight = 0.55; // how much paperH blends with the field
  if (_brushMode !== 'wet') {
    _ensureTextureNoise(_brushMode);
    textureActive = true;
    if (_brushMode === 'crayon' || _brushMode === 'dry') {
      textureField        = crayonNoise;
      textureBaseThresh   = 0.4 + 0.25 * _dryPaperReject;
      textureBandHalf     = 0.05;
      textureAnisoK       = _drynessAmount * _dryAnisotropy * 6;
      textureWaterMult    = 1 - _drynessAmount * 0.85;
      texturePaperWeight  = 0.55;  // crayon: paper contributes strongly
    } else if (_brushMode === 'dryBrush') {
      // Dry brush: directional. Use the anisotropic noise field
      // (already streaky horizontally), plus a stronger motion-
      // direction anisotropy contribution. Narrower threshold band
      // gives crisper binary in/out — bristles either deposit or
      // skip, less in-between.
      textureField        = dryBrushNoise;
      textureBaseThresh   = 0.4 + 0.25 * _dryPaperReject;
      textureBandHalf     = 0.03;
      textureAnisoK       = _drynessAmount * _dryAnisotropy * 12;
      textureWaterMult    = 1 - _drynessAmount * 0.85;
      texturePaperWeight  = 0.25;  // dry brush: noise field dominates
    } else if (_brushMode === 'salt') {
      // Salt: big round blooms. Low-frequency noise + soft threshold
      // band so spots have halos. No anisotropy — salt crystals
      // don't care about brush direction. Water multiplier is
      // higher than dry brush (real salt is wet technique).
      // baseThresh of 0.75 means at amount=0.5 the threshold is
      // 1 - 0.375 = 0.625, which catches the upper third of saltNoise
      // values and produces visible big blooms. At amount=1.0 the
      // threshold drops to 0.25 — most cells reject (heavy salt).
      textureField        = saltNoise;
      textureBaseThresh   = 0.75;
      textureBandHalf     = 0.12;  // wide soft halo
      textureAnisoK       = 0;
      textureWaterMult    = 1 - _drynessAmount * 0.3;  // keep more water
      texturePaperWeight  = 0;     // pure salt noise, no paper blend
    } else if (_brushMode === 'splatter') {
      // Splatter: discrete spots. High-frequency noise + very narrow
      // threshold + hard cutoff = sparse single-cell or small-cluster
      // dots. No anisotropy. Keep some water — splatter dots are
      // wet droplets, they should still bleed slightly.
      // baseThresh of 0.70 gives visible spots from amount=0.4 upward.
      textureField        = splatterNoise;
      textureBaseThresh   = 0.70;
      textureBandHalf     = 0.02;  // very crisp dot edges
      textureAnisoK       = 0;
      textureWaterMult    = 1 - _drynessAmount * 0.5;
      texturePaperWeight  = 0;     // pure splatter noise
    }
  }

  // Motion vector for anisotropic textures (dryBrush mainly).
  // Direction comes from the previous stamp position; if this is
  // the first stamp of a stroke, motion is undefined and we fall
  // back to isotropic rejection. The 250ms freshness check prevents
  // stale stamps from a previous stroke leaking direction into
  // a new stroke.
  let textureMotionX = 0, textureMotionY = 0;
  if (textureActive && _lastStampX >= 0 && (performance.now() - _lastStampT) < 250) {
    const mdx = gx - _lastStampX;
    const mdy = gy - _lastStampY;
    const mag = Math.sqrt(mdx * mdx + mdy * mdy);
    if (mag > 0.5) {
      textureMotionX = mdx / mag;
      textureMotionY = mdy / mag;
    }
  }
  // Effective amount: clamped slider × mode-active.
  const textureAmount = textureActive ? _drynessAmount : 0;
  const textureBristleK = textureAmount * _dryBrushSkip;
  // Reduce water + pressure deposit by mode-specific multiplier.
  const effPigWetGain  = pigWetGain  * (textureActive ? textureWaterMult : 1);
  const effPigPresGain = pigPresGain * (textureActive ? textureWaterMult : 1);

  for (let py = minY; py <= maxY; py++) {
    for (let px = minX; px <= maxX; px++) {
      const dx = px - gx, dy = py - gy;
      const d2 = dx * dx + dy * dy;
      if (d2 > r2) continue;
      const i = py * GW + px;
      // Masked cells reject pigment — that's the whole point of mask.
      if (maskActive && mask[i] > MASK_THRESHOLD) continue;
      const falloff = 1 - Math.sqrt(d2) / r;
      const f2 = falloff * falloff;

      // v0.98 — texture deposit modulation. When a texture mode is
      // active, compute a per-cell rejection factor in [0, 1] from:
      //   1. The mode's noise field, optionally blended with paperH
      //      (crayon resist blends; salt/splatter use pure noise).
      //   2. A smooth-band threshold determined by dryness and the
      //      mode's band half-width.
      //   3. Motion-direction anisotropy (dryBrush mainly): paperH
      //      gradient projected onto stroke direction, added if
      //      positive (bristles skip over rising paper).
      //
      // We want SPECKLED output for crayon/dry-brush, BLOTCHY for
      // salt, DOTTED for splatter — the per-mode parameters set
      // above shape each accordingly. A smooth attenuation would
      // just dim every cell uniformly; we want some cells fully
      // painted and others fully rejected.
      let depositFactor = 1;
      if (textureAmount > 0) {
        const fn = textureField[i];
        const ph = paperH[i];
        // Combined sample: noise field blended with paper height by
        // mode-specific weight. Crayon weights paper at 0.55 so paper
        // tooth dominates; salt/splatter use 0 (pure noise).
        const combined = fn * (1 - texturePaperWeight) + ph * texturePaperWeight;
        // Threshold: rises with dryness. At amount=0 the threshold
        // is 1 (nothing rejects); at amount=1 it's (1 - baseThresh).
        const thresh = 1 - textureAmount * textureBaseThresh;
        let skipMask;
        const lo = thresh - textureBandHalf;
        const hi = thresh + textureBandHalf;
        if (combined < lo) {
          skipMask = 0;
        } else if (combined > hi) {
          skipMask = 1;
        } else {
          const t = (combined - lo) / (textureBandHalf * 2);
          skipMask = t * t * (3 - 2 * t);
        }
        let totalReject = skipMask * (0.85 + 0.15 * textureBristleK);
        // Anisotropy contribution: paperH gradient projected onto
        // motion direction. Only meaningful when motion vector exists
        // AND the texture's anisotropy coefficient is non-zero (dry
        // brush mainly). Skipped at grid edges where the gradient
        // kernel would read out of bounds.
        if (textureAnisoK > 0 && (textureMotionX !== 0 || textureMotionY !== 0) &&
            px > 0 && px < GW - 1 && py > 0 && py < GH - 1) {
          const dhdx = paperH[i + 1] - paperH[i - 1];
          const dhdy = paperH[i + GW] - paperH[i - GW];
          const proj = dhdx * textureMotionX + dhdy * textureMotionY;
          if (proj > 0) totalReject = Math.min(1, totalReject + proj * textureAnisoK);
        }
        if (totalReject > 1) totalReject = 1;
        depositFactor = 1 - totalReject;
      }

      let na = arr[i] + strength * f2 * pigDepositMult * depositFactor;
      if (na > MAX_PIGMENT) na = MAX_PIGMENT;
      arr[i] = na;
      // Wet + pressure also scale by depositFactor when textured —
      // cells skipped during deposit shouldn't accumulate wet either,
      // otherwise wet bleed would fill in the gaps over time.
      const ww = wet[i] + effPigWetGain * falloff * (textureAmount > 0 ? depositFactor : 1);
      wet[i] = ww > 1 ? 1 : ww;
      pressure[i] += effPigPresGain * f2 * (textureAmount > 0 ? depositFactor : 1);
    }
  }

  // v0.98 — Update last stamp position for the next call's motion
  // vector. Only meaningful in textured modes but kept always-updated
  // so toggling mode mid-stroke uses current position. Stale-stroke
  // reset is handled by the 250ms timestamp check on the next call.
  _lastStampX = gx;
  _lastStampY = gy;
  _lastStampT = performance.now();
}

// ============================================================
// INITIAL STATE — wet canvas + two splotches close but separate
// ============================================================
function placeInitialSplotch(cx, cy, radius, pigmentIdx) {
  const r2 = radius * radius;
  for (let py = Math.max(0, cy - radius); py <= Math.min(GH - 1, cy + radius); py++) {
    for (let px = Math.max(0, cx - radius); px <= Math.min(GW - 1, cx + radius); px++) {
      const dx = px - cx, dy = py - cy;
      const dd = dx * dx + dy * dy;
      if (dd > r2) continue;
      const i = py * GW + px;
      const falloff = 1 - Math.sqrt(dd) / radius;
      const ff = falloff * falloff;
      g[pigmentIdx][i] += 0.62 * ff;
      wet[i] = Math.max(wet[i], 0.92);
      pressure[i] += 0.08 * ff;
    }
  }
}

function resetSim() {
  markCanvasActive();
  for (let i = 0; i < N; i++) {
    // The whole canvas is uniformly wet — this is the "wet" canvas
    wet[i] = 0.62;
    u[i] = 0; v[i] = 0; pressure[i] = 0;
    g[0][i] = g[1][i] = g[2][i] = 0;
    d[0][i] = d[1][i] = d[2][i] = 0;
    mask[i] = 0;
    // v0.97 — also clear ink (separate from K-M pigments)
    ink[i] = 0;
  }
  maskActive = false;
  inkActive = false;
  clearMaskRect();
  // v0.98 — clear dry-brush stroke tracking; the rejection itself
  // operates on paper height (unchanged) but stale stamp position
  // shouldn't leak across a reset.
  _lastStampX = -1;
  _lastStampY = -1;
  // Uniform wet + zero pigment + zero pressure = no dynamics anywhere.
  // Empty active rect → simStep functions early-return until paintAt grows it.
  setActiveRectEmpty();
  // v0.10 — clear cached imgData and display canvas. With localized render,
  // the imgData buffer retains pixels from cells that were last rendered
  // while inside the active rect. Without this clear, putImageData on the
  // next localized render would push those stale pixels back onto
  // renderCanvas, where they'd remain visible outside the new active rect.
  // The display canvas needs clearing too — drawImage doesn't repaint the
  // pixels we're not putting imgData into.
  imgData.data.fill(0);
  renderCtx.clearRect(0, 0, GW, GH);
  ctx.clearRect(0, 0, DISPLAY_W, DISPLAY_H);
  // Canvas starts blank. placeInitialSplotch() remains available for
  // library users who want to seed pigment programmatically at startup.
}

// rebuildScale — live resolution change. Reallocates every state array
// at the new grid size, re-derives the scale-dependent constants, and
// resizes the canvases. Called by the Resolution slider on `change`.
// The rAF loop is single-threaded with the event handler, so this runs
// safely between frames; the next loop tick picks up the new state.
function rebuildScale(newScale) {
  SCALE = newScale;
  s_scale = SCALE / SCALE_REF;
  inv_s = 1 / s_scale;
  inv_s2 = inv_s * inv_s;

  GW = Math.max(120, Math.floor(_innerWidth()  * CANVAS_OVERSCAN / SCALE));
  GH = Math.max(80,  Math.floor(_innerHeight() * CANVAS_OVERSCAN / SCALE));
  N = GW * GH;
  DISPLAY_W = Math.round(GW * SCALE);
  DISPLAY_H = Math.round(GH * SCALE);
  // v2 — re-compute canvas-scale factor for the new display size.
  _canvasScale = Math.min(1.0, DISPLAY_W / REFERENCE_DISPLAY_W);
  if (typeof options.canvasScale === 'number' && options.canvasScale > 0) {
    _canvasScale = options.canvasScale;
  }

  // Re-derive the scale-dependent constants. These mirror the inline
  // initializations at the top of the script — keep the formulas in sync.
  PIGMENT_DIFFUSION = Math.min(0.20, 0.045 * inv_s2);
  WET_DIFFUSION     = Math.min(0.20, 0.10 * inv_s2);
  EDGE_KERNEL       = Math.max(1, Math.round(4 * inv_s));
  EDGE_KERNEL_LARGE = Math.max(1, Math.round(20 * inv_s));
  // v0.84 — only auto-recompute VEL_CLAMP if the user hasn't
  // manually overridden it. Preserves manual settings across
  // resolution changes.
  if (!_velocityClampManual) {
    VEL_CLAMP = Math.min(1.5, 1.0 * inv_s);
  }

  // Reallocate every state array at the new size. JS GC will collect
  // the old ones once nothing references them; closures inside functions
  // resolve identifiers at call time so they'll pick up the new arrays.
  wet      = new Float32Array(N);
  wet_tmp  = new Float32Array(N);
  wetBlur  = new Float32Array(N);
  wetBlurLarge = new Float32Array(N);
  wetBlurTmp = new Float32Array(N);
  wetBinary = new Float32Array(N);
  u        = new Float32Array(N);
  v        = new Float32Array(N);
  u_new    = new Float32Array(N);
  v_new    = new Float32Array(N);
  pressure = new Float32Array(N);
  paperH   = new Float32Array(N);
  g     = [new Float32Array(N), new Float32Array(N), new Float32Array(N)];
  d     = [new Float32Array(N), new Float32Array(N), new Float32Array(N)];
  g_tmp = [new Float32Array(N), new Float32Array(N), new Float32Array(N)];
  // v0.97 — ink arrays follow the same rescale path
  ink     = new Float32Array(N);
  ink_tmp = new Float32Array(N);
  inkActive = false;
  mask  = new Float32Array(N);
  maskActive = false;
  clearMaskRect();

  // Resize the render and display canvases, then reallocate imgData.
  renderCanvas.width  = GW;
  renderCanvas.height = GH;
  imgData = renderCtx.createImageData(GW, GH);
  canvas.width  = DISPLAY_W;
  canvas.height = DISPLAY_H;

  // v0.20 — also resize the GPU canvas and textures if WebGL is active.
  // gpuOnResize is a no-op when WebGL hasn't been initialized.
  if (typeof gpuOnResize === 'function') gpuOnResize();

  // Any paint event queued at the old grid coordinates is stale; clear
  // it. _lastGX/Y referenced the old grid too — reset to 0.
  if (typeof _pendingPaintX !== 'undefined') {
    _pendingPaintX = null; _pendingPaintY = null;
    _lastGX = 0; _lastGY = 0;
  }

  // Regenerate paper texture at the new resolution and reset state.
  generatePaper();
  resetSim();
  // Force a render so the new canvas is visible immediately, even if
  // the sim is currently idle.
  render();
  // v2 — dispatch a 'rescaled' event so the host UI can react
  // (e.g. rebuild pigment swatches that depend on the new paper).
  targetEl.dispatchEvent(new CustomEvent('rescaled', {
    detail: { scale: SCALE, gridWidth: GW, gridHeight: GH }
  }));
}

// Re-wet: raise water saturation back to a high baseline everywhere, and
// lift a fraction of deposited pigment back into suspension so dried
// strokes become mobile again. The §4.5 desorption rate is too slow to
// feel responsive on its own, so we shortcut by moving 30% of d → g.
const REWET_LEVEL = 0.85;
const REWET_LIFT  = 0.30;
function rewet() {
  markCanvasActive();
  // d→g transfer happens wherever d>0 — could be anywhere on the canvas.
  // Set rect full and let the next periodic shrink scan tighten it back
  // to the actual bounding box of newly-suspended pigment.
  setActiveRectFull();
  for (let i = 0; i < N; i++) {
    // Masked cells: stay frozen. Mask is waterproof; re-wet washes
    // around them.
    if (maskActive && mask[i] > MASK_THRESHOLD) continue;
    if (wet[i] < REWET_LEVEL) wet[i] = REWET_LEVEL;
    for (let k = 0; k < 3; k++) {
      const dval = d[k][i];
      if (dval < 0.001) continue;
      const lift = dval * REWET_LIFT;
      d[k][i] = dval - lift;
      const nv = g[k][i] + lift;
      g[k][i] = nv > MAX_PIGMENT ? MAX_PIGMENT : nv;
    }
  }
}

// v0.24 — Splash: a dramatic re-wet that creates real pigment dispersal.
// v0.25 — extended with presets ('bigSplash' / 'fineSpritz' / 'default')
//         and explicit-coordinate support for choreographed splashes.
//
// Where re-wet quietly soaks the canvas and gently lifts pigment, splash
// is an *event*: it picks several epicenters (biased toward where the
// densest pigment lives — unless explicit coords are passed), saturates
// the wet field, lifts most of the deposited pigment back into suspension,
// and injects outward-radial velocity + a pressure spike from each
// epicenter. The sim's existing advection + diffusion takes over from
// there and runs the dispersal forward over ~2 seconds.
//
// Why this works visually: re-wet doesn't make pigment *move* — it just
// makes pigment *mobile*. Splash adds the missing ingredient: a real
// flow field. Pigment that was sitting still now has somewhere to go,
// pushed outward from each epicenter, mixing with neighboring colors,
// pooling at edges, behaving like real watercolor under a splash.

// Preset definitions. Each preset bundles the parameter space into one
// name so callers don't have to think about radius/velocity/pressure
// independently. The "default" preset is the v0.24 baseline; "bigSplash"
// pumps everything up for whole-canvas chaos; "fineSpritz" goes the
// other way — many small concentrated bursts, like flicking water onto
// the painting from a brush.
const SPLASH_PRESETS = {
  default: {
    lift:        0.80,   // fraction of deposited → suspended
    wetLevel:    1.0,    // saturate the wet field
    velocity:    0.85,   // peak radial velocity at epicenter
    pressure:    0.45,   // peak pressure bump at epicenter
    radiusPx:    180,    // splash zone radius in display pixels
    epiMin:      3,
    epiMax:      7,
  },
  bigSplash: {
    lift:        0.85,
    wetLevel:    1.0,
    velocity:    1.10,
    pressure:    0.55,
    radiusPx:    280,
    epiMin:      4,
    epiMax:      8,
  },
  fineSpritz: {
    lift:        0.50,   // less violent — pigment stays largely in place
    wetLevel:    0.85,   // doesn't fully saturate; "spritz" not "soak"
    velocity:    0.50,
    pressure:    0.25,
    radiusPx:    80,     // small concentrated bursts
    epiMin:      8,
    epiMax:      15,
  },
  // v0.52 → v0.60 — "deluge": a single overwhelming splash. Where
  // bigSplash distributes the chaos across 4-8 epicenters, deluge
  // concentrates it into ONE giant event with extreme parameters —
  // flooded paper, strong directional flow radiating outward at high
  // velocity, and a hard pressure spike that drives flow well beyond
  // the splash ring. Imagine a cup of water spilled violently across
  // the page, or a pressure washer hitting the surface: a single
  // point of impact with enough water+velocity+pressure to push
  // pigment anywhere on the canvas.
  //
  // v0.60 — Defaults scaled ~10× over v0.52 (velocity 2.5 → 25,
  // pressure 1.2 → 12). The original numbers came from "what feels
  // like one wave"; user feedback was that clearing a flooded
  // container reliably required ~16 successive clicks. The new
  // defaults bake that cumulative wash effect into a single trigger,
  // which is what users expect "Deluge now" to mean. Lift+wetLevel
  // were already at their useful ceilings; the scaling is on the
  // momentum side (velocity + pressure). The post-splash sim still
  // damps these over ~30-60 frames so the canvas settles cleanly.
  //
  // The radius is intentionally close to the canvas span so the
  // velocity ring covers most of the painting. The wetLevel + lift
  // pass already affects all cells (regardless of radius), so they
  // stay at the saturated/almost-fully-lifted values.
  deluge: {
    lift:        0.98,   // lift effectively all deposited pigment back into suspension
    wetLevel:    1.0,    // flooded — full wet field everywhere
    velocity:    40,     // v0.61 — 16× v0.52 baseline, sized so a single click fully evacuates the 400×400 container
    pressure:    20,     // v0.61 — 16× v0.52 baseline
    radiusPx:    2000,   // v0.61 — wider than container so outflow continues past 200px container edge
    epiMin:      1,
    epiMax:      1,      // single overwhelming event, not a swarm
  },
};

// splash(opts?) — three calling forms:
//
//   splash()                          → default preset, random epicenters
//   splash('bigSplash')               → named preset, random epicenters
//   splash([{x, y}, ...])             → explicit coords, default preset
//   splash([{x, y}, ...], 'fineSpritz')  → explicit coords + preset
//   splash({coords: [...], preset: 'big...'})  → object form
//
// Per-point overrides: an epicenter may include `radius`, `velocity`,
// `pressure`, `lift` to override the preset values for just that point.
// Useful for choreographed splashes where one epicenter should be
// dramatic and another subtle.
function splash(arg1, arg2, opts) {
  // -- Resolve calling form into a normalized {coords, preset} object.
  let coords = null;       // null = use random epicenters
  let presetName = 'default';

  if (typeof arg1 === 'string') {
    presetName = arg1;
  } else if (Array.isArray(arg1)) {
    coords = arg1;
    if (typeof arg2 === 'string') presetName = arg2;
  } else if (arg1 && typeof arg1 === 'object') {
    if (Array.isArray(arg1.coords)) coords = arg1.coords;
    if (typeof arg1.preset === 'string') presetName = arg1.preset;
  }

  const preset = SPLASH_PRESETS[presetName];
  if (!preset) {
    throw new Error('Watercolor.splash: unknown preset "' + presetName +
      '". Valid: ' + Object.keys(SPLASH_PRESETS).join(', '));
  }

  // v0.58 — opts (optional, third positional arg):
  //   angleOffset:  radians to rotate each radial velocity vector
  //                 around its epicenter. Default 0. The donor-cell
  //                 advection scheme has a built-in cardinal-axis
  //                 preference (cells on the cardinal axes donate
  //                 100% of their pigment to one neighbor while
  //                 diagonal cells split 50/50 between two), which
  //                 manifests as a cross-shaped artifact at high
  //                 velocities even with the v0.57 flux clamp /
  //                 substep modes (those fix negative cells but not
  //                 the asymmetric evacuation pattern). Rotating
  //                 the field shifts which axes get the cardinal
  //                 preference. Calling splash() multiple times with
  //                 varying angleOffset over consecutive frames
  //                 smears the artifact across all orientations,
  //                 producing a visibly symmetric splash.
  //   strengthMult: multiplier on velocity + pressure injection.
  //                 Default 1. Use 1/N when distributing an N-frame
  //                 splash so total momentum is preserved.
  //   skipLift:     when true, skip the deposited→suspended lift
  //                 and the wet-field saturation. Use true for the
  //                 follow-up frames of a distributed splash; do
  //                 the lift on frame 0 only so deposited pigment
  //                 isn't depleted N times in quick succession.
  //   jitterAmount: 0..1, per-cell random angular jitter applied to
  //                 each cell's outward-radial vector. 0 = no jitter
  //                 (pure radial, donor-cell cross visible at
  //                 extremes). 1 = each cell's velocity rotated by
  //                 a uniformly-random angle in [-π/4, +π/4] — wide
  //                 enough to fully smear the cardinal preference
  //                 within a single splash, but narrow enough that
  //                 the field stays predominantly outward. Single-
  //                 frame alternative to angleOffset across many
  //                 frames; visually noisier but doesn't require
  //                 rAF chaining. (v0.59+)
  //   rayCount:     integer ≥ 1. Replaces each epicenter with N copies
  //                 arranged in a ring around the original at evenly-
  //                 spaced compass angles. With rayCount = 8 and a
  //                 single click position, the splash becomes 8
  //                 simultaneous radial sources at N/NE/E/SE/S/SW/W/NW
  //                 around that point, each at 1/N strength. SPATIAL
  //                 distribution (one frame) rather than TEMPORAL
  //                 (across frames like angleOffset rotation), so no
  //                 inter-frame "bounce" — the composite field is
  //                 uniform from the first sim step. Default 1 (single
  //                 epicenter, v0.60 behavior). (v0.61+)
  //   rayOffsetFraction: 0..1. Ring radius for ray placement, as a
  //                 fraction of the splash's own radiusPx. With
  //                 fraction = 0.05 (default) on a 2000 px splash,
  //                 rays sit 100 px from the click position. Small
  //                 enough that rays' splash zones overlap heavily
  //                 (composite reads as one big splash, not a
  //                 rosette), large enough that the donor-cell
  //                 cardinal preference of each individual ray
  //                 cancels against the others. (v0.61+)
  const angleOffset  = (opts && +opts.angleOffset)  || 0;
  const strengthMult = (opts && opts.strengthMult != null) ? +opts.strengthMult : 1;
  const skipLift     = !!(opts && opts.skipLift);
  const jitterAmount = (opts && opts.jitterAmount != null) ? +opts.jitterAmount : 0;
  const rayCount     = (opts && +opts.rayCount > 1) ? Math.floor(+opts.rayCount) : 1;
  const rayOffsetFraction = (opts && opts.rayOffsetFraction != null) ? +opts.rayOffsetFraction : 0.05;
  // Pre-compute the jitter angular range — π/4 = 45° to each side
  // gives ~50% chance any individual cell rotates onto a diagonal,
  // which is enough to homogenize the donor-cell cardinal bias
  // statistically across the splash region.
  const _jitterRange = jitterAmount * (Math.PI / 4);
  const _hasJitter = _jitterRange > 0;

  markCanvasActive();
  setActiveRectFull();

  // -- 1. Lift deposited → suspended, saturate wet.
  if (!skipLift) {
    for (let i = 0; i < N; i++) {
      if (maskActive && mask[i] > MASK_THRESHOLD) continue;
      if (wet[i] < preset.wetLevel) wet[i] = preset.wetLevel;
      for (let k = 0; k < 3; k++) {
        const dval = d[k][i];
        if (dval < 0.001) continue;
        const lift = dval * preset.lift;
        d[k][i] = dval - lift;
        const nv = g[k][i] + lift;
        g[k][i] = nv > MAX_PIGMENT ? MAX_PIGMENT : nv;
      }
    }
  }

  // -- 2. Pick epicenters. If caller passed coords, use those; otherwise
  //       rejection-sample from current pigment density.
  let epicenters;
  if (coords) {
    // Use exactly the points the caller specified, preserving any
    // per-point radius/velocity/pressure/lift overrides.
    epicenters = coords.map((pt) => ({
      x:        pt.x,
      y:        pt.y,
      radius:   pt.radius   ?? null,
      velocity: pt.velocity ?? null,
      pressure: pt.pressure ?? null,
      lift:     pt.lift     ?? null,
    }));
  } else {
    // Auto-pick. Same rejection-sampling logic as v0.24.
    const g0 = g[0], g1 = g[1], g2 = g[2];
    let maxPigment = 0;
    for (let i = 0; i < N; i++) {
      const p = g0[i] + g1[i] + g2[i];
      if (p > maxPigment) maxPigment = p;
    }
    const hasPigment = maxPigment > 0.05;

    const range = preset.epiMax - preset.epiMin;
    const numEpicenters = preset.epiMin + Math.floor(Math.random() * (range + 1));
    epicenters = [];
    for (let ec = 0; ec < numEpicenters; ec++) {
      let cx, cy;
      if (hasPigment) {
        let found = false;
        for (let tries = 0; tries < 200; tries++) {
          const i = Math.floor(Math.random() * N);
          const p = (g0[i] + g1[i] + g2[i]) / maxPigment;
          if (Math.random() < p) {
            cx = i % GW;
            cy = Math.floor(i / GW);
            found = true;
            break;
          }
        }
        if (!found) {
          cx = Math.floor(Math.random() * GW);
          cy = Math.floor(Math.random() * GH);
        }
      } else {
        cx = Math.floor(Math.random() * GW);
        cy = Math.floor(Math.random() * GH);
      }
      epicenters.push({ x: cx, y: cy, radius: null, velocity: null,
                        pressure: null, lift: null });
    }
  }

  // v0.61 — Spatial ray expansion. When rayCount > 1, replace each
  // epicenter with N copies arranged in a ring around the original.
  // Compass ordering: ray 0 at 0° (E, right of center on canvas with
  // y growing downward, but the visual symmetry is what matters);
  // subsequent rays at evenly-spaced angles. Each ray inherits the
  // original's radius/velocity/pressure/lift overrides; strength is
  // divided across rays via the rayCount divisor applied later in
  // the injection loop (NOT here — we leave per-point velocity/
  // pressure alone so explicit per-point overrides still work).
  // Ring radius is rayOffsetFraction × the epicenter's resolved
  // splash radiusPx, converted to grid coords. With default 0.05 on
  // a 2000 px deluge that's a 100 px ring → ~50 grid cells offset.
  // Far enough that the rays' donor-cell cardinal preferences are at
  // different orientations (each ray points outward from a slightly
  // different center), close enough that the composite reads as one
  // splash rather than N small splashes.
  if (rayCount > 1) {
    const rect_e = canvas.getBoundingClientRect();
    const pxToGrid_e = GW / rect_e.width;
    const expanded = [];
    for (const ec of epicenters) {
      const radPx_e = (ec.radius != null ? ec.radius : preset.radiusPx) * _canvasScale;
      const ringRadiusGrid = radPx_e * pxToGrid_e * rayOffsetFraction;
      for (let r = 0; r < rayCount; r++) {
        const ang = (2 * Math.PI * r) / rayCount;
        expanded.push({
          x: ec.x + ringRadiusGrid * Math.cos(ang),
          y: ec.y + ringRadiusGrid * Math.sin(ang),
          radius:   ec.radius,
          velocity: ec.velocity,
          pressure: ec.pressure,
          lift:     ec.lift,
        });
      }
    }
    epicenters = expanded;
  }

  // -- 3. Inject outward-radial velocity + pressure from each epicenter.
  //       Each epicenter resolves its own radius/velocity/pressure: per-
  //       point overrides win, otherwise fall back to the preset.
  //       v0.58 — Apply opts.angleOffset (rotates the radial vectors
  //       around each epicenter) and opts.strengthMult (scales
  //       velocity + pressure injection). Default (1, 0, 1) reproduces
  //       v0.57 behavior bit-for-bit.
  const rect = canvas.getBoundingClientRect();
  const pxToGrid = GW / rect.width;
  const cosA = Math.cos(angleOffset);
  const sinA = Math.sin(angleOffset);
  const _hasRotation = angleOffset !== 0;

  for (const ec of epicenters) {
    const ecx = ec.x, ecy = ec.y;
    // Per-point overrides; if not set, use the preset's values.
    // v2 — scale radiusPx by canvas-size factor so splash zones stay
    // visually proportional on small canvases (matches paintAt scaling).
    // v0.62 — REMOVED the 1/rayCount divisor (was in v0.61). The
    // divisor preserved total injected momentum across rays at
    // mathematical parity with single-ray, but it made the rays
    // slider feel inert: bumping rays from 1 to 8 produced an
    // 8-ray splash where each ray had 1/8 strength, so the total
    // momentum was unchanged. Users perceived "the slider doesn't
    // do anything". Now each ray fires at full strength — rays
    // scales momentum linearly with N, matching the user's mental
    // model (more rays = stronger splash). If you want preserved
    // momentum across rays, pass strengthMult: 1/N explicitly.
    const radiusPx = (ec.radius   != null ? ec.radius   : preset.radiusPx) * _canvasScale;
    const velMag   = (ec.velocity != null ? ec.velocity : preset.velocity) * strengthMult;
    const presMag  = (ec.pressure != null ? ec.pressure : preset.pressure) * strengthMult;
    const radiusGrid = radiusPx * pxToGrid;
    const r2 = radiusGrid * radiusGrid;
    const minX = Math.max(0, Math.floor(ecx - radiusGrid));
    const maxX = Math.min(GW - 1, Math.ceil(ecx + radiusGrid));
    const minY = Math.max(0, Math.floor(ecy - radiusGrid));
    const maxY = Math.min(GH - 1, Math.ceil(ecy + radiusGrid));
    for (let py = minY; py <= maxY; py++) {
      for (let px = minX; px <= maxX; px++) {
        const dx = px - ecx, dy = py - ecy;
        const d2 = dx * dx + dy * dy;
        // v0.72 — Threshold lowered from 0.5 to 1e-10. The original
        // 0.5 was a paranoid safety margin against divide-by-zero in
        // the unit-radial calc, but 1/0 only happens at d² = 0 (the
        // exact epicenter — possible only with integer-valued ec).
        // Cells with small but nonzero d² (e.g. 0.25) have perfectly
        // well-defined radial directions and should receive normal
        // injection. Skipping them was the actual root cause of the
        // pinpoint artifact: they ended up at u=v=0 in a
        // surrounding field of high outward velocity, which after
        // ~10 frames damped into a convergent pressure sink that
        // pulled pigment INTO the skipped cells from all sides.
        // Tightening the threshold to ~zero (still rejecting only
        // genuine divide-by-zero with a comfortable float-precision
        // margin) lets these cells participate normally.
        if (d2 > r2 || d2 < 1e-10) continue;
        const i = py * GW + px;
        if (maskActive && mask[i] > MASK_THRESHOLD) continue;
        const dist = Math.sqrt(d2);
        const falloff = 1 - dist / radiusGrid;
        const f2 = falloff * falloff;
        const inv = 1 / dist;
        const radialX = dx * inv;
        const radialY = dy * inv;
        // Apply rotation matrix when angleOffset is nonzero. Skip
        // the branch + 4 multiplies in the common no-rotation case.
        let ux, uy;
        if (_hasRotation) {
          ux = radialX * cosA - radialY * sinA;
          uy = radialX * sinA + radialY * cosA;
        } else {
          ux = radialX;
          uy = radialY;
        }
        // v0.59 — per-cell angular jitter. Applied AFTER the global
        // rotation so the two compose: jitter perturbs every cell
        // individually around whatever direction the global rotation
        // (if any) has settled on. Each cell gets a fresh Math.random
        // call, which is cheap on V8 (xorshift internally). On a 900-
        // radius splash that's ~2.5M random calls — measured at <2ms
        // in V8 on commodity hardware, negligible vs. the post-splash
        // sim work.
        if (_hasJitter) {
          const ja = (Math.random() * 2 - 1) * _jitterRange;
          const cj = Math.cos(ja), sj = Math.sin(ja);
          const nx = ux * cj - uy * sj;
          const ny = ux * sj + uy * cj;
          ux = nx; uy = ny;
        }
        u[i] += ux * velMag * f2;
        v[i] += uy * velMag * f2;
        pressure[i] += presMag * f2;
      }
    }
  }

  // v0.70 — Pinpoint fix at the epicenter (each ec).
  // v0.71 — Generalized to handle multi-cell skip regions.
  // v0.72 — With the injection threshold tightened from 0.5 to
  //         1e-10, this smoothing is now usually a no-op: at most one
  //         cell is skipped (only when ec has integer-valued
  //         coordinates, i.e. d²=0 exactly at one cell). Kept in
  //         place for that case and as defensive cover for any
  //         floating-point near-zero situations where the radial
  //         direction would have been numerically unstable.
  for (const ec of epicenters) {
    const ecx = ec.x, ecy = ec.y;
    const fx = Math.floor(ecx), cx2 = Math.ceil(ecx);
    const fy = Math.floor(ecy), cy2 = Math.ceil(ecy);
    const candidates = [[fx, fy], [cx2, fy], [fx, cy2], [cx2, cy2]];
    for (const [ix, iy] of candidates) {
      const dxc = ix - ecx, dyc = iy - ecy;
      // Match the injection's skip threshold exactly. With 1e-10 this
      // catches only the integer-coordinate case (one cell); for any
      // fractional ec it's a no-op.
      if (dxc * dxc + dyc * dyc >= 1e-10) continue;
      if (ix < 1 || ix >= GW - 1 || iy < 1 || iy >= GH - 1) continue;
      const idx = iy * GW + ix;
      if (maskActive && mask[idx] > MASK_THRESHOLD) continue;
      const e = idx + 1, w = idx - 1, n = idx - GW, s = idx + GW;
      for (let k = 0; k < 3; k++) {
        g[k][idx] = (g[k][e] + g[k][w] + g[k][n] + g[k][s]) * 0.25;
        d[k][idx] = (d[k][e] + d[k][w] + d[k][n] + d[k][s]) * 0.25;
      }
      wet[idx]      = (wet[e]      + wet[w]      + wet[n]      + wet[s])      * 0.25;
      pressure[idx] = (pressure[e] + pressure[w] + pressure[n] + pressure[s]) * 0.25;
    }
  }
}

function splashPresets() { return Object.keys(SPLASH_PRESETS); }

// Instant-dry: the inverse of rewet. Applies evaporate's dry-out rule
// unconditionally to every cell — all suspended pigment settles to
// deposited, water and flow zero out. After this, all cells are below
// the simulation's wet-threshold so the sim will idle out within a
// frame. We render explicitly so the damp-sheen disappears from
// unpainted cells immediately, without needing to wake the sim for 60
// grace frames just to flush a visual that won't change again.
//
// v2 lib note: in v0.26.2 this also called updateBars() to refresh the
// dryness/pigment indicator at the bottom of the panel. That UI is now
// a host concern — the wiring polls state() every 250ms. We dispatch a
// 'driedinstantly' event so a host that wants an immediate update
// (without waiting for the next poll) can listen.
function dryPaper() {
  for (let i = 0; i < N; i++) {
    // Masked cells: frozen. Dry button can't reach them.
    if (maskActive && mask[i] > MASK_THRESHOLD) continue;
    // Settle suspended → deposited (same rule evaporate uses)
    for (let k = 0; k < 3; k++) {
      let nd = d[k][i] + g[k][i];
      if (nd > MAX_PIGMENT) nd = MAX_PIGMENT;
      d[k][i] = nd;
      g[k][i] = 0;
    }
    // v0.50 — Force-dry just deposited pigment; reset fade spring
    // velocity so any subsequent fade ticks start from rest.
    if (fadeEnabled && dVel !== null) {
      dVel[0][i] = 0; dVel[1][i] = 0; dVel[2][i] = 0;
    }
    wet[i] = 0;
    u[i] = 0; v[i] = 0;
    pressure[i] = 0;
  }
  // No wet, no suspended pigment, no pressure → no dynamics anywhere.
  setActiveRectEmpty();
  render();
  targetEl.dispatchEvent(new CustomEvent('driedinstantly'));
}

// Clear all masking-fluid in one pass. Real-world masking fluid is
// rubbed off when the painting dries — this is the digital equivalent.
// The frozen state under the mask is revealed (paper if mask was the
// first thing painted, or pigment if mask was painted over wet paint).
// Forces a full re-render because previously-masked cells need their
// pixels rewritten from the underlying state, and they may sit outside
// the current active rect.
function removeMask() {
  if (!maskActive) return;
  for (let i = 0; i < N; i++) mask[i] = 0;
  maskActive = false;
  clearMaskRect();
  // Force-full re-render: ex-masked cells reveal whatever was frozen
  // underneath, which the active-rect-localized render wouldn't catch
  // if those cells sit outside the rect.
  render(true);
}

function maskRectDisplay(displayX, displayY, displayW, displayH, radii) {
  if (!isFinite(displayX) || !isFinite(displayY) ||
      !isFinite(displayW) || !isFinite(displayH) ||
      displayW <= 0 || displayH <= 0) {
    console.warn('maskRect: invalid bounds', { displayX, displayY, displayW, displayH });
    return;
  }

  // Normalize radii to [topLeft, topRight, bottomRight, bottomLeft].
  // Matches the CSS / roundRect() convention.
  let r0, r1, r2, r3;
  if (radii === undefined || radii === null) {
    r0 = r1 = r2 = r3 = 0;
  } else if (typeof radii === 'number') {
    r0 = r1 = r2 = r3 = +radii;
  } else if (Array.isArray(radii)) {
    if (radii.length === 1)      { r0 = r1 = r2 = r3 = +radii[0]; }
    else if (radii.length === 2) { r0 = r2 = +radii[0]; r1 = r3 = +radii[1]; }
    else if (radii.length === 3) { r0 = +radii[0]; r1 = r3 = +radii[1]; r2 = +radii[2]; }
    else                          { r0 = +radii[0]; r1 = +radii[1]; r2 = +radii[2]; r3 = +radii[3]; }
  } else {
    console.warn('maskRect: unrecognized radii shape, treating as 0', radii);
    r0 = r1 = r2 = r3 = 0;
  }
  // Sanitize: NaN → 0, negative → 0
  if (!isFinite(r0) || r0 < 0) r0 = 0;
  if (!isFinite(r1) || r1 < 0) r1 = 0;
  if (!isFinite(r2) || r2 < 0) r2 = 0;
  if (!isFinite(r3) || r3 < 0) r3 = 0;
  // Clamp each radius to half the smaller side (CSS does this too)
  const maxR = Math.min(displayW, displayH) / 2;
  if (r0 > maxR) r0 = maxR;
  if (r1 > maxR) r1 = maxR;
  if (r2 > maxR) r2 = maxR;
  if (r3 > maxR) r3 = maxR;

  // Convert display→grid via the same math as toGrid().
  const rect = canvas.getBoundingClientRect();
  const gxScale = GW / rect.width;
  const gyScale = GH / rect.height;
  const gxOf = (dx) => (dx - rect.left) * gxScale;
  const gyOf = (dy) => (dy - rect.top)  * gyScale;
  const gScaleAvg = (gxScale + gyScale) * 0.5;  // radii are uniform pixels

  // Grid-coordinate rectangle bounds + radii. Grid radii are display
  // radii × average grid-per-display ratio (close enough to isotropic
  // for typical aspect ratios; canvas display is square-pixel).
  const gx0 = gxOf(displayX);
  const gy0 = gyOf(displayY);
  const gx1 = gxOf(displayX + displayW);
  const gy1 = gyOf(displayY + displayH);
  const gr0 = r0 * gScaleAvg;
  const gr1 = r1 * gScaleAvg;
  const gr2 = r2 * gScaleAvg;
  const gr3 = r3 * gScaleAvg;

  // Pixel-bounds of the iteration. Clip to grid range.
  const iMinX = Math.max(0, Math.floor(gx0));
  const iMaxX = Math.min(GW - 1, Math.ceil(gx1));
  const iMinY = Math.max(0, Math.floor(gy0));
  const iMaxY = Math.min(GH - 1, Math.ceil(gy1));
  if (iMaxX < iMinX || iMaxY < iMinY) return;

  // Corner-center coords (where the corner-arc origin sits)
  // tl: (gx0 + r0,  gy0 + r0)
  // tr: (gx1 - r1,  gy0 + r1)
  // br: (gx1 - r2,  gy1 - r2)
  // bl: (gx0 + r3,  gy1 - r3)
  const tlcx = gx0 + gr0, tlcy = gy0 + gr0, tlr2 = gr0 * gr0;
  const trcx = gx1 - gr1, trcy = gy0 + gr1, trr2 = gr1 * gr1;
  const brcx = gx1 - gr2, brcy = gy1 - gr2, brr2 = gr2 * gr2;
  const blcx = gx0 + gr3, blcy = gy1 - gr3, blr2 = gr3 * gr3;

  // Track which cells crossed the threshold for maskRect bookkeeping
  let anyAbove = false;
  let rMinX = GW, rMaxX = -1, rMinY = GH, rMaxY = -1;

  for (let py = iMinY; py <= iMaxY; py++) {
    for (let px = iMinX; px <= iMaxX; px++) {
      // Inside-or-not test: check which "zone" the cell sits in.
      // The non-rounded interior of the rect is anything past each
      // corner's arc center, on the interior side. We test each
      // corner's arc only if the cell is in that corner's quadrant.
      let inside = false;
      if (px < tlcx && py < tlcy) {
        const dx = px - tlcx, dy = py - tlcy;
        if (dx*dx + dy*dy <= tlr2) inside = true;
      } else if (px > trcx && py < trcy) {
        const dx = px - trcx, dy = py - trcy;
        if (dx*dx + dy*dy <= trr2) inside = true;
      } else if (px > brcx && py > brcy) {
        const dx = px - brcx, dy = py - brcy;
        if (dx*dx + dy*dy <= brr2) inside = true;
      } else if (px < blcx && py > blcy) {
        const dx = px - blcx, dy = py - blcy;
        if (dx*dx + dy*dy <= blr2) inside = true;
      } else {
        // Cell is in one of the "straight" zones (between corners) —
        // straightforward rect-inside test against the outer bounds.
        if (px >= gx0 && px <= gx1 && py >= gy0 && py <= gy1) {
          inside = true;
        }
      }

      if (inside) {
        const i = py * GW + px;
        mask[i] = 1;
        anyAbove = true;
        if (px < rMinX) rMinX = px;
        if (px > rMaxX) rMaxX = px;
        if (py < rMinY) rMinY = py;
        if (py > rMaxY) rMaxY = py;
      }
    }
  }

  if (anyAbove) {
    maskActive = true;
    if (rMinX < maskRectMinX) maskRectMinX = rMinX;
    if (rMaxX > maskRectMaxX) maskRectMaxX = rMaxX;
    if (rMinY < maskRectMinY) maskRectMinY = rMinY;
    if (rMaxY > maskRectMaxY) maskRectMaxY = rMaxY;
  }
}

// v0.96 — Inverse of maskRect. Clears the mask field inside a
// rounded rectangle so subsequent paint operations can deposit
// pigment in that region. Useful for "open a window" effects:
// mask a card, then unmask a sub-region (a link, a button) so
// hover splashes can land on it while the rest of the card
// remains protected.
//
// Arguments are identical to maskRect — display-pixel coords +
// CanvasRenderingContext2D.roundRect-spec radii.
//
// Note: unmaskRect doesn't shrink the global maskRect bounding box
// (because doing so accurately would require re-scanning the
// entire mask field). The bounding box stays at whatever it was
// — a slight efficiency loss for sim functions, but no correctness
// issue. If you want a tight bbox after un-masking, call
// removeMask() and re-apply your masks freshly.
function unmaskRectDisplay(displayX, displayY, displayW, displayH, radii) {
  if (!isFinite(displayX) || !isFinite(displayY) ||
      !isFinite(displayW) || !isFinite(displayH) ||
      displayW <= 0 || displayH <= 0) {
    console.warn('unmaskRect: invalid bounds', { displayX, displayY, displayW, displayH });
    return;
  }

  let r0, r1, r2, r3;
  if (radii === undefined || radii === null) {
    r0 = r1 = r2 = r3 = 0;
  } else if (typeof radii === 'number') {
    r0 = r1 = r2 = r3 = +radii;
  } else if (Array.isArray(radii)) {
    if (radii.length === 1)      { r0 = r1 = r2 = r3 = +radii[0]; }
    else if (radii.length === 2) { r0 = r2 = +radii[0]; r1 = r3 = +radii[1]; }
    else if (radii.length === 3) { r0 = +radii[0]; r1 = r3 = +radii[1]; r2 = +radii[2]; }
    else                          { r0 = +radii[0]; r1 = +radii[1]; r2 = +radii[2]; r3 = +radii[3]; }
  } else {
    r0 = r1 = r2 = r3 = 0;
  }
  if (!isFinite(r0) || r0 < 0) r0 = 0;
  if (!isFinite(r1) || r1 < 0) r1 = 0;
  if (!isFinite(r2) || r2 < 0) r2 = 0;
  if (!isFinite(r3) || r3 < 0) r3 = 0;
  const maxR = Math.min(displayW, displayH) / 2;
  if (r0 > maxR) r0 = maxR;
  if (r1 > maxR) r1 = maxR;
  if (r2 > maxR) r2 = maxR;
  if (r3 > maxR) r3 = maxR;

  const rect = canvas.getBoundingClientRect();
  const gxScale = GW / rect.width;
  const gyScale = GH / rect.height;
  const gxOf = (dx) => (dx - rect.left) * gxScale;
  const gyOf = (dy) => (dy - rect.top)  * gyScale;
  const gScaleAvg = (gxScale + gyScale) * 0.5;

  const gx0 = gxOf(displayX);
  const gy0 = gyOf(displayY);
  const gx1 = gxOf(displayX + displayW);
  const gy1 = gyOf(displayY + displayH);
  const gr0 = r0 * gScaleAvg;
  const gr1 = r1 * gScaleAvg;
  const gr2 = r2 * gScaleAvg;
  const gr3 = r3 * gScaleAvg;

  const iMinX = Math.max(0, Math.floor(gx0));
  const iMaxX = Math.min(GW - 1, Math.ceil(gx1));
  const iMinY = Math.max(0, Math.floor(gy0));
  const iMaxY = Math.min(GH - 1, Math.ceil(gy1));
  if (iMaxX < iMinX || iMaxY < iMinY) return;

  const tlcx = gx0 + gr0, tlcy = gy0 + gr0, tlr2 = gr0 * gr0;
  const trcx = gx1 - gr1, trcy = gy0 + gr1, trr2 = gr1 * gr1;
  const brcx = gx1 - gr2, brcy = gy1 - gr2, brr2 = gr2 * gr2;
  const blcx = gx0 + gr3, blcy = gy1 - gr3, blr2 = gr3 * gr3;

  let anyCleared = false;
  for (let py = iMinY; py <= iMaxY; py++) {
    for (let px = iMinX; px <= iMaxX; px++) {
      let inside = false;
      if (px < tlcx && py < tlcy) {
        const dx = px - tlcx, dy = py - tlcy;
        if (dx*dx + dy*dy <= tlr2) inside = true;
      } else if (px > trcx && py < trcy) {
        const dx = px - trcx, dy = py - trcy;
        if (dx*dx + dy*dy <= trr2) inside = true;
      } else if (px > brcx && py > brcy) {
        const dx = px - brcx, dy = py - brcy;
        if (dx*dx + dy*dy <= brr2) inside = true;
      } else if (px < blcx && py > blcy) {
        const dx = px - blcx, dy = py - blcy;
        if (dx*dx + dy*dy <= blr2) inside = true;
      } else {
        if (px >= gx0 && px <= gx1 && py >= gy0 && py <= gy1) {
          inside = true;
        }
      }
      if (inside) {
        const i = py * GW + px;
        if (mask[i] > 0) {
          mask[i] = 0;
          anyCleared = true;
        }
      }
    }
  }

  // If we cleared some cells, we don't bother re-scanning to find
  // the new tight bounding box. The maskRect optimization is a
  // hint, not a requirement — the per-cell `mask[i] > MASK_THRESHOLD`
  // check inside sim functions still gives correct results.
  // If we cleared ALL masked cells, flip maskActive off so the
  // mask-tracking machinery returns to the fast no-mask path.
  if (anyCleared) {
    // Quick check: any mask still set anywhere? Scan once to find out.
    // This is O(N) but only runs on unmask, which is rare.
    let stillAny = false;
    for (let i = 0; i < N; i++) {
      if (mask[i] > MASK_THRESHOLD) { stillAny = true; break; }
    }
    if (!stillAny) {
      maskActive = false;
      clearMaskRect();
    }
  }
}


// ANIMATION PRESETS — autonomous painting loops (v0.11)
// ============================================================
// Selectable via the Animation dropdown. Each mode is a self-contained
// step function called from the rAF loop; all modes share the user-
// facing paintAt path, so they can't bypass or desync from the sim.
//
// Modes:
//   'off'   — no animation
//   'ai'    — original AI painter (weighted stroke strategies; one
//             stroke at a time on a PLAN → STROKE → REST loop)
//   'rainy' — pool of up to RAIN_MAX_DROPS concurrent drops falling
//             from above; cool palette with occasional water lifts
//
// Adding a new preset: define a state variable + a `*Step` function,
// add a dispatch arm to animationStep(), and add an <option> to the
// dropdown. The dispatcher routes by string so additions stay local.

let animationMode = 'off';

// ----- AI PAINTER preset ------------------------------------------------
// Simple state machine: PLAN → STROKE → REST → PLAN.
// Each stroke picks a weighted strategy that constrains brush size,
// stroke length in grid cells, frame duration, and tool/pigment. The
// path is a quadratic Bezier with a perpendicular control-point offset
// so strokes have some natural curve.

let aiState = null;
// Average pigment per cell — updated each frame by updateBars.
// Shared with the AI planner so it can switch behavior based on canvas
// saturation without re-computing the sum.
let currentAvgPigment = 0;
// Above this saturation, the AI stops adding pigment and exclusively
// uses the water brush ('soften' strategy) — pushing existing paint
// around rather than piling more on a saturated canvas.
const AI_WATER_THRESHOLD = 0.75;

const AI_STRATEGIES = [
  // brushPx is display pixels (clamped to MAX_BRUSH at plan time).
  // dist is a fraction of min(GW, GH) → stroke length in grid cells.
  // dur is frame count for the whole stroke. pigment: null = random pigment.
  { name: 'mark',   weight: 3.0, brushPx: [ 20,  60], dist: [0.10, 0.35], dur: [25, 55], strength: 0.34, pigment: null         },
  { name: 'wash',   weight: 2.0, brushPx: [ 80, 200], dist: [0.20, 0.50], dur: [40, 80], strength: 0.30, pigment: null         },
  { name: 'detail', weight: 1.6, brushPx: [  8,  22], dist: [0.00, 0.05], dur: [ 8, 20], strength: 0.40, pigment: null         },
  { name: 'soften', weight: 1.0, brushPx: [ 40, 100], dist: [0.05, 0.25], dur: [25, 45], strength: 0.30, pigment: WATER_INDEX  },
  { name: 'lift',   weight: 0.6, brushPx: [ 30,  70], dist: [0.00, 0.10], dur: [15, 30], strength: 0.30, pigment: LIFT_INDEX   },
];
// Pre-cached soften strategy so we don't .find() it on every stroke
// once the canvas is saturated.
const AI_SOFTEN_STRATEGY = AI_STRATEGIES.find(s => s.name === 'soften');

function aiPickWeighted(items) {
  let total = 0;
  for (const it of items) total += it.weight;
  let r = Math.random() * total;
  for (const it of items) {
    r -= it.weight;
    if (r <= 0) return it;
  }
  return items[items.length - 1];
}

function aiGridRadius(brushPx) {
  // Same conversion the user's pointer handlers use, so AI strokes
  // and user strokes use identical brush footprints.
  const rect = canvas.getBoundingClientRect();
  return (brushPx / 2) * (GW / rect.width);
}

function aiPlanStroke() {
  // Saturated canvas → exclusively water brush. Dynamic: if pigment
  // later drops below threshold (lift brush, reset), AI returns to
  // normal weighted strategy selection.
  const strat = currentAvgPigment >= AI_WATER_THRESHOLD
    ? AI_SOFTEN_STRATEGY
    : aiPickWeighted(AI_STRATEGIES);

  // Brush size in display px, clamped to the slider's viewport max
  const bpMin = Math.min(strat.brushPx[0], MAX_BRUSH);
  const bpMax = Math.min(strat.brushPx[1], MAX_BRUSH);
  const brushPx = bpMin + Math.random() * (bpMax - bpMin);

  // Stroke endpoints in grid coordinates
  const minDim = Math.min(GW, GH);
  const distF = strat.dist[0] + Math.random() * (strat.dist[1] - strat.dist[0]);
  const distGrid = distF * minDim;

  // Bias the start point toward the canvas interior so strokes don't
  // always sail out off the edge
  const margin = 0.12;
  const sx = margin * GW + Math.random() * (1 - 2 * margin) * GW;
  const sy = margin * GH + Math.random() * (1 - 2 * margin) * GH;

  // Random direction; clamp the end inside canvas
  const angle = Math.random() * Math.PI * 2;
  let ex = sx + Math.cos(angle) * distGrid;
  let ey = sy + Math.sin(angle) * distGrid;
  ex = Math.max(0, Math.min(GW - 1, ex));
  ey = Math.max(0, Math.min(GH - 1, ey));

  // Perpendicular control-point offset → curved Bezier path
  const dx = ex - sx, dy = ey - sy;
  const curve = (Math.random() - 0.5) * 0.35;
  const cx = (sx + ex) / 2 + (-dy) * curve;
  const cy = (sy + ey) / 2 + ( dx) * curve;

  const duration = Math.floor(
    strat.dur[0] + Math.random() * (strat.dur[1] - strat.dur[0])
  );

  const pigment = strat.pigment !== null
    ? strat.pigment
    : Math.floor(Math.random() * PIGMENTS.length);

  return {
    phase: 'stroke',
    progress: 0,
    duration,
    sx, sy, cx, cy, ex, ey,
    pigment, brushPx,
    strength: strat.strength,
  };
}

function aiStep() {
  if (animationMode !== 'ai') return;
  if (!aiState) { aiState = aiPlanStroke(); return; }

  if (aiState.phase === 'stroke') {
    aiState.progress++;
    if (aiState.progress > aiState.duration) {
      // ~18% of strokes are followed by a long pause so the canvas has
      // time to dry between bursts of activity; the rest are short rests.
      const longRest = Math.random() < 0.18;
      aiState = {
        phase: 'rest',
        framesLeft: longRest
          ? 120 + Math.floor(Math.random() * 240)
          : 8   + Math.floor(Math.random() *  60),
      };
      return;
    }
    const t = aiState.progress / aiState.duration;
    const u = 1 - t;
    const x = u*u*aiState.sx + 2*u*t*aiState.cx + t*t*aiState.ex;
    const y = u*u*aiState.sy + 2*u*t*aiState.cy + t*t*aiState.ey;
    paintAt(x, y, aiGridRadius(aiState.brushPx), aiState.pigment, aiState.strength);
  } else if (aiState.phase === 'rest') {
    aiState.framesLeft--;
    if (aiState.framesLeft <= 0) aiState = null;
  }
}

// ----- RAINY preset -----------------------------------------------------
// A pool of independent "drops" that spawn just above the canvas, fall
// downward with a slight horizontal drift, and paint along the way. The
// preset uses paintAt the same way the user's pointer does, so every
// drop participates in the watercolor sim — wet bleed, edge darkening,
// granulation all apply per drop.
//
// Tuning notes:
//   • RAIN_MAX_DROPS caps concurrency so the active rect stays bounded
//     and the canvas doesn't saturate instantly. 12 feels like steady
//     rain without obliterating the surface.
//   • Per-frame spawn probability is RAIN_SPAWN_PER_SEC / 60, capped by
//     the max. The math is loose — a Bernoulli trial per frame, not a
//     true Poisson — which is fine for visual density.
//   • Palette is cool: cerulean dominates, water-brush drops produce
//     lift highlights, occasional rose breaks the monotony. The cool
//     bias reads as a rainy mood whatever paper color is selected.
//   • Drops drift slightly horizontally (vx) and fall fast (vy), with
//     randomness so they don't all march in lockstep.

const RAIN_MAX_DROPS = 12;
const RAIN_SPAWN_PER_SEC = 30;   // average new drops per second (capped by MAX)

// Each entry: [pigmentConstant, weight, [strengthLo, strengthHi], [brushPxLo, brushPxHi]]
const RAIN_DROP_TYPES = [
  // pigmentConstant uses the same indexing paintAt accepts:
  // 0/1/2 are real pigments; WATER_INDEX is the water brush.
  // The cerulean index (2) and rose index (0) are hard-coded — they map to the
  // PIGMENTS array defined at the top of the script.
  [2,            0.60, [0.18, 0.30], [10, 22]],   // cerulean — dominant
  [WATER_INDEX,  0.30, [0.15, 0.28], [10, 20]],   // water — lifts existing paint
  [0,            0.10, [0.10, 0.20], [ 8, 14]],   // rose — occasional warmth
];

let rainDrops = [];

function rainSpawnDrop() {
  // Weighted pick. Sum once and walk; cheap enough at 3 entries.
  let total = 0;
  for (const t of RAIN_DROP_TYPES) total += t[1];
  let r = Math.random() * total;
  let chosen = RAIN_DROP_TYPES[0];
  for (const t of RAIN_DROP_TYPES) {
    r -= t[1];
    if (r <= 0) { chosen = t; break; }
  }
  const [pigment, , [sLo, sHi], [bLo, bHi]] = chosen;
  return {
    // Start above the top edge so the drop fades in via the falling
    // motion rather than popping into existence at y=0.
    x: Math.random() * GW,
    y: -10 - Math.random() * 20,
    vx: (Math.random() - 0.5) * 0.6,            // slight horizontal drift
    vy: 4.0 + Math.random() * 5.0,              // grid cells per frame
    brushPx: bLo + Math.random() * (bHi - bLo),
    pigment,
    strength: sLo + Math.random() * (sHi - sLo),
  };
}

function rainStep() {
  // Spawn up to MAX with per-frame Bernoulli probability. The while-loop
  // can spawn multiple per frame if probability is high; with
  // RAIN_SPAWN_PER_SEC=30 at 60fps it averages 0.5 spawn-attempts/frame.
  const spawnProb = RAIN_SPAWN_PER_SEC / 60;
  while (rainDrops.length < RAIN_MAX_DROPS && Math.random() < spawnProb) {
    rainDrops.push(rainSpawnDrop());
  }

  // Cache the px→grid conversion once per frame. paintAt uses grid
  // coordinates; the slider/UI works in display pixels.
  const rect = canvas.getBoundingClientRect();
  const pxToGridRadius = (GW / rect.width) * 0.5;

  // Step each drop. Walk backward so splice doesn't disturb indices.
  for (let i = rainDrops.length - 1; i >= 0; i--) {
    const d = rainDrops[i];
    d.x += d.vx;
    d.y += d.vy;

    // Cull drops that have run off the canvas (mostly through the
    // bottom; sideways too, in case the drift carried them off).
    if (d.y > GH + 10 || d.x < -10 || d.x > GW + 10) {
      rainDrops.splice(i, 1);
      continue;
    }

    // Paint only when the drop is actually on-canvas. The above-canvas
    // segment is a "spawn delay" so drops appear to fall in from off-screen.
    if (d.y >= 0 && d.y < GH) {
      paintAt(d.x, d.y, d.brushPx * pxToGridRadius, d.pigment, d.strength);
    }
  }
}

// ----- SUNNY preset -----------------------------------------------------
// Calm, slow horizontal sweeps in the upper portion of the canvas. Reads
// as soft sunlight rather than literal sunbeams — large brush, warm
// palette (yellow primary, rose accent), low strength so accumulated
// strokes wash rather than stack into a solid mark. Spawn interval is
// deliberately long; sunny is the quietest preset.
const SUNNY_MAX = 2;
const SUNNY_SPAWN_INTERVAL_MIN = 150;
const SUNNY_SPAWN_INTERVAL_RAND = 120;

let sunnyStrokes = [];
let sunnySpawnTimer = 30;  // small initial delay so the first stroke isn't instant

function sunnySpawn() {
  // Bezier sweep across canvas, biased toward the top third. Direction
  // alternates randomly so strokes don't all go the same way.
  const direction = Math.random() < 0.5 ? 1 : -1;
  const sx = direction > 0 ? -GW * 0.1 : GW * 1.1;
  const ex = direction > 0 ? GW * 1.1 : -GW * 0.1;
  const sy = GH * (0.05 + Math.random() * 0.35);
  const ey = sy + (Math.random() - 0.5) * GH * 0.15;
  const cx = (sx + ex) / 2;
  const cy = (sy + ey) / 2 + (Math.random() - 0.5) * GH * 0.25;
  return {
    progress: 0,
    duration: 80 + Math.floor(Math.random() * 80),
    sx, sy, cx, cy, ex, ey,
    pigment: Math.random() < 0.75 ? 1 : 0,        // 75% yellow, 25% rose
    strength: 0.16 + Math.random() * 0.10,
    brushPx: 80 + Math.random() * 100,
  };
}

function sunnyStep() {
  sunnySpawnTimer--;
  if (sunnySpawnTimer <= 0 && sunnyStrokes.length < SUNNY_MAX) {
    sunnyStrokes.push(sunnySpawn());
    sunnySpawnTimer = SUNNY_SPAWN_INTERVAL_MIN + Math.floor(Math.random() * SUNNY_SPAWN_INTERVAL_RAND);
  }
  const rect = canvas.getBoundingClientRect();
  const pxToGridRadius = (GW / rect.width) * 0.5;
  for (let i = sunnyStrokes.length - 1; i >= 0; i--) {
    const s = sunnyStrokes[i];
    s.progress++;
    if (s.progress > s.duration) { sunnyStrokes.splice(i, 1); continue; }
    const t = s.progress / s.duration;
    const u = 1 - t;
    const x = u*u*s.sx + 2*u*t*s.cx + t*t*s.ex;
    const y = u*u*s.sy + 2*u*t*s.cy + t*t*s.ey;
    paintAt(x, y, s.brushPx * pxToGridRadius, s.pigment, s.strength);
  }
}

// ----- WINDY preset -----------------------------------------------------
// Many fast horizontal streaks. The wind has a dominant direction that
// occasionally gusts the other way — a small probability per frame of
// flipping windDirection produces irregular shifts rather than the
// strict left/right alternation you'd get with a sine wave.
const WINDY_MAX = 8;
const WINDY_GUST_PROB = 0.0008;

let windyStreaks = [];
let windDirection = 1;

function windySpawn() {
  // Spawn just off the upwind edge so streaks "blow in"
  return {
    x: windDirection > 0 ? -10 - Math.random() * 30 : GW + 10 + Math.random() * 30,
    y: Math.random() * GH,
    vx: windDirection * (5 + Math.random() * 6),
    vy: (Math.random() - 0.5) * 0.3,
    brushPx: 6 + Math.random() * 14,
    // Cool-air cerulean dominates, occasional warm yellow streak. Water
    // adds variation by lifting deposited paint (visible only where the
    // canvas already has pigment, but that's the point — wind erodes).
    pigment: (() => {
      const r = Math.random();
      if (r < 0.70) return 2;            // cerulean
      if (r < 0.85) return WATER_INDEX;  // water lift
      return 1;                          // yellow
    })(),
    strength: 0.10 + Math.random() * 0.10,
    life: 200,
  };
}

function windyStep() {
  if (Math.random() < WINDY_GUST_PROB) windDirection *= -1;
  while (windyStreaks.length < WINDY_MAX && Math.random() < 0.35) {
    windyStreaks.push(windySpawn());
  }
  const rect = canvas.getBoundingClientRect();
  const pxToGridRadius = (GW / rect.width) * 0.5;
  for (let i = windyStreaks.length - 1; i >= 0; i--) {
    const s = windyStreaks[i];
    s.x += s.vx;
    s.y += s.vy;
    s.life--;
    if (s.life <= 0 || s.x < -20 || s.x > GW + 20) { windyStreaks.splice(i, 1); continue; }
    if (s.y >= 0 && s.y < GH) {
      paintAt(s.x, s.y, s.brushPx * pxToGridRadius, s.pigment, s.strength);
    }
  }
}

// ----- THUNDERSTORM preset ---------------------------------------------
// Heavy rain (faster, more drops than the rainy preset) plus periodic
// lightning. Lightning is a single-frame burst of small paintAt calls
// along a jagged vertical path — not a separate visual primitive,
// just dense small strokes in bright yellow that read as a bolt
// against the dark/wet canvas.
const STORM_MAX_DROPS = 18;
const STORM_SPAWN_PER_SEC = 60;
const STORM_LIGHTNING_MIN_COOLDOWN = 90;     // frames; ~1.5 sec min between flashes
const STORM_LIGHTNING_RAND_COOLDOWN = 360;   // additional random delay

let stormDrops = [];
let stormLightningCooldown = 120;            // initial delay before first flash

function stormSpawnDrop() {
  const r = Math.random();
  let pigment;
  if (r < 0.65) pigment = 2;              // cerulean — dominant
  else if (r < 0.85) pigment = WATER_INDEX; // water lift
  else pigment = 0;                       // rose
  return {
    x: Math.random() * GW,
    y: -10 - Math.random() * 30,
    vx: (Math.random() - 0.5) * 1.0,    // more turbulent than rainy
    vy: 6 + Math.random() * 6,          // harder rain
    brushPx: 10 + Math.random() * 18,
    pigment,
    strength: 0.20 + Math.random() * 0.20,
  };
}

function stormFlashLightning() {
  // Build a jagged vertical path top → bottom; paint many small dabs
  // along each segment so the bolt reads as a continuous stroke. Yellow
  // at high strength against the wet, cool canvas pops cleanly.
  const segments = 6 + Math.floor(Math.random() * 5);
  const startX = GW * 0.15 + Math.random() * GW * 0.7;
  const jitter = GW * 0.04;
  let cx = startX;
  let cy = -2;
  const segDY = GH / segments;
  for (let s = 0; s < segments; s++) {
    const nx = cx + (Math.random() - 0.5) * jitter * 2;
    const ny = cy + segDY * (0.8 + Math.random() * 0.4);
    // Walk the segment with small steps — denser steps for a more
    // solid-looking bolt.
    const stepsPer = 8;
    for (let i = 0; i < stepsPer; i++) {
      const t = i / stepsPer;
      const px = cx + (nx - cx) * t;
      const py = cy + (ny - cy) * t;
      if (py >= 0 && py < GH) {
        // Small brush, very high strength so the bolt stays bright
        // even after the rain washes over it.
        paintAt(px, py, 1.5, 1, 0.65);
      }
    }
    cx = nx;
    cy = ny;
  }
}

function thunderstormStep() {
  // Rain phase
  const spawnProb = STORM_SPAWN_PER_SEC / 60;
  while (stormDrops.length < STORM_MAX_DROPS && Math.random() < spawnProb) {
    stormDrops.push(stormSpawnDrop());
  }
  const rect = canvas.getBoundingClientRect();
  const pxToGridRadius = (GW / rect.width) * 0.5;
  for (let i = stormDrops.length - 1; i >= 0; i--) {
    const d = stormDrops[i];
    d.x += d.vx;
    d.y += d.vy;
    if (d.y > GH + 10 || d.x < -10 || d.x > GW + 10) { stormDrops.splice(i, 1); continue; }
    if (d.y >= 0 && d.y < GH) {
      paintAt(d.x, d.y, d.brushPx * pxToGridRadius, d.pigment, d.strength);
    }
  }
  // Lightning phase — fires on cooldown, then resets timer to a randomized
  // delay. Random cooldown spread makes flashes feel natural rather than
  // metronomic.
  stormLightningCooldown--;
  if (stormLightningCooldown <= 0) {
    stormFlashLightning();
    stormLightningCooldown = STORM_LIGHTNING_MIN_COOLDOWN
                           + Math.floor(Math.random() * STORM_LIGHTNING_RAND_COOLDOWN);
  }
}

// ----- PARTLY CLOUDY preset --------------------------------------------
// A few large slow soft "clouds" drift horizontally across the upper
// half of the canvas. Each cloud paints multiple small dabs per frame
// spread around its center, giving an irregular puffy footprint.
// Water-brush dabs dominate so existing pigment gets lifted (reading as
// brighter highlights); a minority of cerulean dabs adds shadow.
const CLOUD_MAX = 3;

let clouds = [];
let cloudSpawnTimer = 60;

function cloudSpawn() {
  const direction = Math.random() < 0.5 ? 1 : -1;
  return {
    x: direction > 0 ? -GW * 0.15 : GW * 1.15,
    y: GH * (0.10 + Math.random() * 0.40),
    vx: direction * (0.4 + Math.random() * 0.5),
    halfWidth: GW * (0.10 + Math.random() * 0.10),    // half-extent for dab spread
    halfHeight: GH * (0.04 + Math.random() * 0.04),
    brushPx: 70 + Math.random() * 60,
    life: 600,
  };
}

function cloudsStep() {
  cloudSpawnTimer--;
  if (cloudSpawnTimer <= 0 && clouds.length < CLOUD_MAX) {
    clouds.push(cloudSpawn());
    cloudSpawnTimer = 180 + Math.floor(Math.random() * 240);
  }
  const rect = canvas.getBoundingClientRect();
  const pxToGridRadius = (GW / rect.width) * 0.5;
  for (let i = clouds.length - 1; i >= 0; i--) {
    const c = clouds[i];
    c.x += c.vx;
    c.life--;
    if (c.life <= 0 || c.x < -GW * 0.25 || c.x > GW * 1.25) { clouds.splice(i, 1); continue; }
    // 2-3 dabs per frame, scattered within the cloud's footprint, so
    // each cloud lays down a wide soft band rather than a thin trail.
    const dabs = 2 + Math.floor(Math.random() * 2);
    for (let j = 0; j < dabs; j++) {
      const ox = (Math.random() - 0.5) * 2 * c.halfWidth;
      const oy = (Math.random() - 0.5) * 2 * c.halfHeight;
      // Mostly water (lifts to highlight), occasional cerulean for shadow.
      const pig = Math.random() < 0.75 ? WATER_INDEX : 2;
      paintAt(c.x + ox, c.y + oy, c.brushPx * pxToGridRadius, pig, 0.07);
    }
  }
}

// ----- SNOWING preset (v0.12.3 — wash + lift) -------------------------
// Two-phase preset:
//   Phase 1 (first ~0.5 sec): cerulean wash painted across the canvas,
//     same dab pattern as the time-of-day washes. Builds a blue sky
//     for the snow to fall against.
//   Phase 2 (after wash, ongoing): water-brush drops fall and flutter,
//     each one LIFTING the deposited cerulean back into suspension.
//     The cells where flakes land become less dense in pigment — paper
//     color shows through more, reading as white-ish snow trails.
//
// The water brush also adds wet + pressure, which keeps the canvas
// saturated and lets the lifted pigment bleed/spread naturally. The
// granulation coefficient of cerulean (γ=0.75) makes the residual
// pigment settle into paper crevices, giving the white trails a soft
// textured edge instead of a hard line.
//
// 90% of drops are pure water (lift), 10% are small cerulean dabs at
// low strength — these refresh the sky as flakes deplete it, keeping
// the contrast alive over long sessions.

const SNOW_WASH_FRAMES = 30;            // ~0.5 sec wash before flakes start
const SNOW_WASH_DABS_PER_FRAME = 8;
const SNOW_WASH_STRENGTH = 0.20;        // moderate blue, dense enough to lift visibly
const SNOW_MAX_DROPS = 16;
const SNOW_SPAWN_PER_SEC = 30;

// State held in a single object so a mode switch can clear it via
// snowState = null. lazy-init on the first step after mode start.
let snowState = null;

function snowingInit() {
  snowState = { washFrame: 0, drops: [] };
}

function snowSpawnFlake() {
  return {
    x: Math.random() * GW,
    y: -10 - Math.random() * 30,
    vy: 0.9 + Math.random() * 1.3,
    flutterPhase: Math.random() * Math.PI * 2,
    flutterAmp: 0.3 + Math.random() * 0.5,
    flutterFreq: 0.04 + Math.random() * 0.04,
    brushPx: 6 + Math.random() * 10,
    // 90% water (lifts cerulean → reveals paper-cream "white"),
    // 10% tiny cerulean replenish dabs so the sky doesn't deplete.
    pigment: Math.random() < 0.90 ? WATER_INDEX : 2,
    strength: 0.10 + Math.random() * 0.10,    // only used by cerulean dabs
  };
}

function snowingStep() {
  if (!snowState) snowingInit();
  const rect = canvas.getBoundingClientRect();
  const pxToGridRadius = (GW / rect.width) * 0.5;

  // Phase 1: blue wash. Pure-cerulean dabs scattered across the canvas
  // at uniform strength — a flat blue sky. Reuses the same dab pattern
  // and tuning as the time-of-day day preset.
  if (snowState.washFrame < SNOW_WASH_FRAMES) {
    for (let i = 0; i < SNOW_WASH_DABS_PER_FRAME; i++) {
      const x = Math.random() * GW;
      const y = Math.random() * GH;
      const brushPx = 70 + Math.random() * 80;
      paintAt(x, y, brushPx * pxToGridRadius, 2, SNOW_WASH_STRENGTH);
    }
    snowState.washFrame++;
    return;  // hold off spawning flakes until wash is laid down
  }

  // Phase 2: flakes spawn and fall. Same spawn/step/cull shape as the
  // other drop-based presets, but the per-drop pigment is mostly the
  // water brush — the visible effect on the canvas is paper showing
  // through where flakes pass, not pigment being added.
  const spawnProb = SNOW_SPAWN_PER_SEC / 60;
  while (snowState.drops.length < SNOW_MAX_DROPS && Math.random() < spawnProb) {
    snowState.drops.push(snowSpawnFlake());
  }
  for (let i = snowState.drops.length - 1; i >= 0; i--) {
    const d = snowState.drops[i];
    d.flutterPhase += d.flutterFreq;
    d.x += Math.sin(d.flutterPhase) * d.flutterAmp;
    d.y += d.vy;
    if (d.y > GH + 10 || d.x < -10 || d.x > GW + 10) { snowState.drops.splice(i, 1); continue; }
    if (d.y >= 0 && d.y < GH) {
      paintAt(d.x, d.y, d.brushPx * pxToGridRadius, d.pigment, d.strength);
    }
  }
}

// ----- SNOWING (ADDITIVE) preset --------------------------------------
// The original snowing behavior, preserved as an alternative to the
// wash-and-lift variant. Tiny cerulean dabs with occasional rose flecks
// flutter down on whatever the canvas currently contains — additive
// rather than subtractive. Reads as a faint blue speckle rather than
// the "white snow against a blue sky" of the lift version. Works well
// layered on top of a sunset or dawn wash where the rose flecks pick
// up the warm tones.

const SNOW_ADD_MAX_DROPS = 16;
const SNOW_ADD_SPAWN_PER_SEC = 24;

let snowAddDrops = [];

function snowAddSpawnDrop() {
  return {
    x: Math.random() * GW,
    y: -10 - Math.random() * 30,
    vy: 0.9 + Math.random() * 1.3,
    flutterPhase: Math.random() * Math.PI * 2,
    flutterAmp: 0.3 + Math.random() * 0.4,
    flutterFreq: 0.04 + Math.random() * 0.04,
    brushPx: 4 + Math.random() * 8,
    // Cerulean dominates with occasional rose for warm flecks; γ=0.75
    // granulation makes the dabs settle into a snowflake-like speckle.
    pigment: Math.random() < 0.88 ? 2 : 0,
    strength: 0.10 + Math.random() * 0.10,
  };
}

function snowingAdditiveStep() {
  const spawnProb = SNOW_ADD_SPAWN_PER_SEC / 60;
  while (snowAddDrops.length < SNOW_ADD_MAX_DROPS && Math.random() < spawnProb) {
    snowAddDrops.push(snowAddSpawnDrop());
  }
  const rect = canvas.getBoundingClientRect();
  const pxToGridRadius = (GW / rect.width) * 0.5;
  for (let i = snowAddDrops.length - 1; i >= 0; i--) {
    const d = snowAddDrops[i];
    d.flutterPhase += d.flutterFreq;
    d.x += Math.sin(d.flutterPhase) * d.flutterAmp;
    d.y += d.vy;
    if (d.y > GH + 10 || d.x < -10 || d.x > GW + 10) { snowAddDrops.splice(i, 1); continue; }
    if (d.y >= 0 && d.y < GH) {
      paintAt(d.x, d.y, d.brushPx * pxToGridRadius, d.pigment, d.strength);
    }
  }
}

// ----- TORNADO preset (v0.14.2 — wash extracted to Background) ---------
// Funnel-only animation. The green tornado sky now lives in the Background
// dropdown as the "Tornado" option, selectable independently — set it
// before starting the animation if you want the full picture.
//
// Funnel geometry (v0.14.2): a strict triangular taper.
//   • Top width    = N units (N = TORNADO_NUM_AGENTS)
//   • Bottom width = 1 unit
//   • 1 unit       = TORNADO_UNIT_PX display pixels (≥20)
// Width interpolates linearly with height (no quadratic falloff). Cursors
// cluster against the outer cone surface via radiusFrac 0.85-1.0 so the
// cone outline reads clearly rather than filling the whole interior —
// matches the spec to "bring the cursors closer together".
//
// Travel: the funnel meanders left→right via layered non-commensurate
// sines on both axes (see vx/vy below) — natural-feeling erratic motion
// rather than a fixed cycle.

const TORNADO_NUM_AGENTS = 14;
const TORNADO_UNIT_PX = 20;               // display pixels per "unit" (≥20)
const TORNADO_HORIZONTAL_SPEED = 2.2;
const TORNADO_RESPAWN_OFFSCREEN = 80;     // cells past right edge before respawn
const TORNADO_RESPAWN_DELAY_FRAMES = 300; // ~5 sec @ 60 fps between passes

let tornadoState = null;

function tornadoSpawnAgents() {
  // Funnel anchor lines — base near the bottom (touching ground),
  // top near the upper third where the funnel meets the storm cloud.
  tornadoState.baseY = GH * 0.85;
  tornadoState.topY  = GH * 0.05;
  tornadoState.centerX = -30;             // start just off the left edge
  tornadoState.centerY = 0;               // vertical offset from baseline
  tornadoState.t = 0;                     // frame counter for meander sines
  tornadoState.respawnCountdown = 0;      // 0 = active; >0 = paused between passes

  // v0.14.3 — per-tornado meander signature. Each pass gets fresh
  // frequencies, amplitudes, and phases for its three-sine sum on
  // each axis. Frequencies jitter ±30% around baselines (0.018,
  // 0.043, 0.097 for X; 0.022, 0.039, 0.071 for Y) — wide enough to
  // visibly differentiate passes, narrow enough that each one still
  // feels like a tornado. Phases are fully random (0 to 2π).
  // Amplitudes jitter ±25% so different passes have different
  // "agitation" levels.
  const jitter = (base, pct) => base * (1 - pct + Math.random() * 2 * pct);
  tornadoState.sinesX = [
    { freq: jitter(0.0180, 0.30), amp: jitter(1.50, 0.25), phase: Math.random() * Math.PI * 2 },
    { freq: jitter(0.0430, 0.30), amp: jitter(0.60, 0.25), phase: Math.random() * Math.PI * 2 },
    { freq: jitter(0.0970, 0.30), amp: jitter(0.25, 0.25), phase: Math.random() * Math.PI * 2 },
  ];
  tornadoState.sinesY = [
    { freq: jitter(0.0220, 0.30), amp: jitter(0.90, 0.25), phase: Math.random() * Math.PI * 2 },
    { freq: jitter(0.0390, 0.30), amp: jitter(0.40, 0.25), phase: Math.random() * Math.PI * 2 },
    { freq: jitter(0.0710, 0.30), amp: jitter(0.18, 0.25), phase: Math.random() * Math.PI * 2 },
  ];

  const agents = [];
  for (let a = 0; a < TORNADO_NUM_AGENTS; a++) {
    agents.push({
      // Even phase distribution so the orbital ring is uniformly populated
      // around the cone surface. Small random jitter prevents perfect
      // mirror symmetry (which would read as artificial).
      phase: (a / TORNADO_NUM_AGENTS) * Math.PI * 2 + Math.random() * 0.25,
      // Uniform heightFrac — each agent picks a random height along the
      // cone. With N=14 agents this gives reasonable coverage; the
      // cone surface area is larger at top so density visually fades
      // upward naturally.
      heightFrac: Math.random(),
      // Tight cluster against the outer cone surface (0.85-1.0). The
      // user-spec phrase "bring the cursors closer together" → tight
      // radial band rather than scattered across the funnel interior.
      radiusFrac: 0.85 + Math.random() * 0.15,
      // Independent rotation rates so the funnel doesn't look like a
      // rigid disk spinning — different agents at different heights
      // shear past each other.
      rotSpeed: 0.20 + Math.random() * 0.10,
      // Pigment mix biased toward cerulean for the dark column body;
      // occasional rose adds brownish debris tint, occasional yellow
      // brings the sky color back into the funnel.
      pigment: Math.random() < 0.65 ? 2
             : Math.random() < 0.5  ? 0
             : 1,
    });
  }
  tornadoState.agents = agents;
}

function tornadoInit() {
  tornadoState = {};
  tornadoSpawnAgents();
}

function tornadoStep() {
  if (!tornadoState) tornadoInit();

  // v0.14.3 — inter-pass delay. After a tornado exits the right edge,
  // the countdown ticks down for ~5 seconds before the next pass spawns.
  // During the pause we do nothing — no paint, no agents. The previously
  // painted tornado sits on the canvas drying and getting absorbed.
  if (tornadoState.respawnCountdown > 0) {
    tornadoState.respawnCountdown--;
    if (tornadoState.respawnCountdown === 0) tornadoSpawnAgents();
    return;
  }

  // Meander velocity. Sum the three sines per axis using this tornado's
  // unique signature (regenerated on every spawn — see tornadoSpawnAgents).
  // The constant rightward drift (TORNADO_HORIZONTAL_SPEED) ensures the
  // funnel always eventually exits the right edge. Y has soft restoring
  // force toward centerY=0 so vertical excursions stay bounded.
  tornadoState.t++;
  const t = tornadoState.t;
  let vx = TORNADO_HORIZONTAL_SPEED;
  for (let s = 0; s < tornadoState.sinesX.length; s++) {
    const sw = tornadoState.sinesX[s];
    vx += Math.sin(t * sw.freq + sw.phase) * sw.amp;
  }
  let vy = 0;
  for (let s = 0; s < tornadoState.sinesY.length; s++) {
    const sw = tornadoState.sinesY[s];
    vy += Math.sin(t * sw.freq + sw.phase) * sw.amp;
  }
  vy -= tornadoState.centerY * 0.015;
  tornadoState.centerX += vx;
  tornadoState.centerY += vy;

  // Off-canvas right → schedule the next pass after the delay. We DON'T
  // spawn immediately; the countdown handler at the top of this function
  // will pick it up once it hits zero.
  if (tornadoState.centerX > GW + TORNADO_RESPAWN_OFFSCREEN) {
    tornadoState.respawnCountdown = TORNADO_RESPAWN_DELAY_FRAMES;
    return;
  }

  // Convert TORNADO_UNIT_PX (display pixels) to grid cells. pxToGrid is
  // the inverse of the canvas display scaling — at the standard 1920px-
  // wide viewport and GW=1152 this gives 1 px ≈ 0.6 grid cells, so
  // 20 px ≈ 12 grid cells per unit.
  const rect = canvas.getBoundingClientRect();
  const pxToGrid = GW / rect.width;
  const pxToGridRadius = pxToGrid * 0.5;
  const unitGrid = TORNADO_UNIT_PX * pxToGrid;
  // Cone width spec (in grid cells):
  //   • Top half-width    = N/2 units → cone diameter = N units at top
  //   • Bottom half-width = 0.5 units → cone diameter = 1 unit at base
  const halfWidthTop = (TORNADO_NUM_AGENTS / 2) * unitGrid;
  const halfWidthBot = 0.5 * unitGrid;

  const baseY = tornadoState.baseY + tornadoState.centerY;
  const topY  = tornadoState.topY  + tornadoState.centerY;
  const funnelHeight = baseY - topY;

  for (let i = 0; i < tornadoState.agents.length; i++) {
    const agent = tornadoState.agents[i];
    agent.phase += agent.rotSpeed;

    // Y position along the funnel (top→bottom interpolation).
    const y = topY + agent.heightFrac * funnelHeight;
    // widthFrac: 1.0 at top (heightFrac=0), 0.0 at bottom (heightFrac=1).
    // LINEAR taper from halfWidthBot at base to halfWidthTop at apex —
    // the cone's actual outline. (v0.14 used a quadratic falloff that
    // bulged the funnel; the new spec is strict triangular.)
    const widthFrac = 1 - agent.heightFrac;
    const maxRadius = halfWidthBot + (halfWidthTop - halfWidthBot) * widthFrac;
    const radius = maxRadius * agent.radiusFrac;
    // Elliptical orbit (Y squashed to 0.25× X) so the funnel reads as
    // a 3D column projected onto 2D — horizontal sweep dominates the
    // viewer's perspective on rotation around a vertical axis.
    const offsetX = Math.cos(agent.phase) * radius;
    const offsetY = Math.sin(agent.phase) * radius * 0.25;
    const px = tornadoState.centerX + offsetX;
    const py = y + offsetY;
    if (px < -20 || px > GW + 20) continue;
    // Brush diameter: each cursor stamps a roughly one-unit-wide mark
    // (1.0× unit at base, 1.2× near the top for slight visual variety
    // — debris reads heavier in the wider cloud-top region).
    const brushPx = TORNADO_UNIT_PX * (1.0 + 0.2 * widthFrac);
    const strength = 0.22 + Math.random() * 0.10;
    paintAt(px, py, brushPx * pxToGridRadius, agent.pigment, strength);
  }
}

// ----- dispatcher -------------------------------------------------------
function animationStep() {
  switch (animationMode) {
    case 'ai':                aiStep();                break;
    case 'rainy':             rainStep();              break;
    case 'sunny':             sunnyStep();             break;
    case 'windy':             windyStep();             break;
    case 'thunderstorm':      thunderstormStep();      break;
    case 'partlyCloudy':      cloudsStep();            break;
    case 'snowing':           snowingStep();           break;
    case 'snowingAdditive':   snowingAdditiveStep();   break;
    case 'tornado':           tornadoStep();           break;
    // 'off' falls through to no-op
  }
}

function clearAllAnimationState() {
  aiState = null;
  rainDrops = [];
  sunnyStrokes = [];
  sunnySpawnTimer = 30;
  windyStreaks = [];
  windDirection = 1;
  stormDrops = [];
  stormLightningCooldown = 120;
  clouds = [];
  cloudSpawnTimer = 60;
  snowState = null;
  snowAddDrops = [];
  tornadoState = null;
}

// ----- UI: animation mode dropdown (stubbed in library mode) -----------
// Original used a <select> dropdown to drive animationMode. In library
// mode the parent calls inst.setAnimation() directly. Keep a null
// placeholder so any subsequent code that probes the variable still
// finds something.
const animationSelect = null;

// ============================================================
// VISUALIZATIONS (v0.15) — indefinitely-running generative loops
// ============================================================
// Visualizations are a peer to the Animation dropdown but distinct in
// purpose: while Animations model real-world atmospherics that have a
// natural finite duration (a tornado passes, a storm cell drifts on),
// Visualizations are self-contained showcase loops that run forever,
// emphasizing what the simulation itself can produce — KM color mixing,
// edge darkening, granulation, wet-on-wet bleed.
//
// Composition is intentional: visualizations stack with Background
// washes, Animations, and manual brushwork. A Kaleidoscope painted
// over a Tornado-sky Background while the user drops dots with the
// Lift brush all coexists. Each visualization picks its own pigments
// and brush sizes; mixing happens via the sim, not via overrides.

let visualizationMode = 'off';

// --- Kaleidoscope (v0.15) ------------------------------------------------
// A master cursor moves through a sequence of generative motion phases.
// Six cursors paint simultaneously at 60° rotations around canvas center,
// producing six-fold rotational symmetry — the classic kaleidoscope
// optical effect. Phases cycle indefinitely, switching every few seconds
// to deliver the mix the spec calls for: dots, sharp radial lines, and
// organic curves.

const KALEIDOSCOPE_N = 6;                 // # of cursors = order of rotational symmetry
const KALEIDOSCOPE_PHASES = [
  { name: 'arc-trace',   frames: 480 },   // ~8 sec — slow organic curves at varying r
  { name: 'dot-burst',   frames: 300 },   // ~5 sec — sharp dots scattered in an annulus
  { name: 'rose-petals', frames: 540 },   // ~9 sec — r = R·cos(k·θ) flower-petal curves
];

let kaleidoscopeState = null;

function kaleidoscopeInit() {
  kaleidoscopeState = {
    phaseIdx: 0,
    phaseFrame: 0,
    pigment: 0,                 // cycles 0→1→2→0… across phases
    centerX: GW * 0.5,
    centerY: GH * 0.5,
    // Per-phase fields — initialized by initKaleidoscopePhase below
    masterR: 0, masterTheta: 0,
  };
  initKaleidoscopePhase();
}

function initKaleidoscopePhase() {
  const s = kaleidoscopeState;
  const phase = KALEIDOSCOPE_PHASES[s.phaseIdx];
  s.phaseFrame = 0;
  // Advance pigment so successive phases never reuse the same color
  // (modulo 3 ensures full rose/yellow/cerulean rotation regardless of
  // how many phases the system has).
  s.pigment = (s.pigment + 1) % 3;

  switch (phase.name) {
    case 'arc-trace':
      // Master rotates slowly while r drifts outward, then bounces.
      // Result: organic curve trails that fill the annulus over the
      // phase duration. The 6-fold symmetry turns each curve into a
      // flower-like ring.
      s.masterTheta = Math.random() * Math.PI * 2;
      s.thetaVel = 0.014 + Math.random() * 0.006;
      s.masterR = GH * (0.10 + Math.random() * 0.15);
      s.rVel = 0.35 + Math.random() * 0.35;
      break;
    case 'dot-burst':
      // Discrete stamps at random positions within an annulus, painted
      // every TAP_EVERY frames. With 6-fold symmetry each "tap"
      // produces a hexagonal cluster of dots — sharp, scattered, no
      // connecting lines.
      s.tapEvery = 6;
      break;
    case 'rose-petals':
      // Rose curve: r(θ) = R·cos(k·θ) traces a flower with 2k petals
      // when k is even, k petals when k odd. Combined with the 6-fold
      // symmetry from the rotated cursors, this creates intricate
      // nested-flower patterns. k is randomized per phase for variety.
      s.masterTheta = 0;
      s.thetaVel = 0.018 + Math.random() * 0.008;
      s.petalK = 2 + Math.floor(Math.random() * 4);  // 2-5 petals
      s.petalR = GH * (0.28 + Math.random() * 0.10);
      break;
  }
}

function kaleidoscopeStep() {
  if (!kaleidoscopeState) kaleidoscopeInit();
  const s = kaleidoscopeState;
  s.phaseFrame++;

  // Phase transition — wrap around the array indefinitely.
  if (s.phaseFrame >= KALEIDOSCOPE_PHASES[s.phaseIdx].frames) {
    s.phaseIdx = (s.phaseIdx + 1) % KALEIDOSCOPE_PHASES.length;
    initKaleidoscopePhase();
  }

  const phase = KALEIDOSCOPE_PHASES[s.phaseIdx];
  const rect = canvas.getBoundingClientRect();
  const pxToGridRadius = (GW / rect.width) * 0.5;

  // Each phase determines:
  //   • whether to paint this frame (some phases skip frames for spacing)
  //   • the master cursor's (r, θ) in grid coordinates
  //   • brush size and deposit strength
  let shouldPaint = true;
  let brushPx = 16, strength = 0.30;

  switch (phase.name) {
    case 'arc-trace': {
      s.masterTheta += s.thetaVel;
      s.masterR += s.rVel;
      // Bounce r off bounds — keeps the pattern from drifting off-canvas
      // or collapsing to the center. The bounds give an annulus the
      // arcs trace through.
      if (s.masterR > GH * 0.42 || s.masterR < GH * 0.06) s.rVel *= -1;
      brushPx = 18;
      strength = 0.28;
      break;
    }
    case 'dot-burst': {
      // Re-roll position every tapEvery frames; paint only on tap frames.
      if (s.phaseFrame % s.tapEvery === 0) {
        s.masterR = GH * (0.08 + Math.random() * 0.32);
        s.masterTheta = Math.random() * Math.PI * 2;
        brushPx = 12 + Math.random() * 6;
        strength = 0.48;
      } else {
        shouldPaint = false;
      }
      break;
    }
    case 'rose-petals': {
      s.masterTheta += s.thetaVel;
      // Rose curve magnitude — abs() to keep r positive (negative values
      // would point through the origin, but the rotational symmetry
      // already covers the opposite-direction positions).
      s.masterR = Math.abs(s.petalR * Math.cos(s.petalK * s.masterTheta));
      brushPx = 14;
      strength = 0.26;
      break;
    }
  }

  if (!shouldPaint) return;

  // Place 6 cursors at evenly-spaced rotations around centerX/centerY.
  // All share the same (r, brushPx, strength, pigment); only θ differs.
  // This is the entire rotational-symmetry implementation: rotate the
  // master's polar angle by i × (2π/N) and paint at the resulting (x, y).
  const TAU = Math.PI * 2;
  for (let i = 0; i < KALEIDOSCOPE_N; i++) {
    const angle = s.masterTheta + (i / KALEIDOSCOPE_N) * TAU;
    const x = s.centerX + Math.cos(angle) * s.masterR;
    const y = s.centerY + Math.sin(angle) * s.masterR;
    paintAt(x, y, brushPx * pxToGridRadius, s.pigment, strength);
  }
}

// --- Lissajous (v0.16) ---------------------------------------------------
// A single master point traces  x(t) = sin(a·t + φx)·Rx,  y(t) = sin(b·t)·Ry
// where (a, b, φx, Rx, Ry) all morph slowly via low-frequency carrier sines.
// When the ratio a/b is rational, the figure is closed; irrational and it
// fills the rectangle densely. Slowly drifting (a, b) means the figure
// continuously morphs through different Lissajous topologies — nodes,
// figure-eights, ellipses, complex weaves — building dense overlapping
// curves on the canvas. Pigment cycles every ~600 frames so successive
// figure-eras paint in different colors and KM-mix at their crossings.

let lissajousState = null;

function lissajousStep() {
  if (!lissajousState) {
    lissajousState = { t: 0, pigment: 0, pigCycleAt: 0 };
  }
  const s = lissajousState;
  s.t++;

  // Carrier sines for slowly morphing (a, b). The ranges hold a and b
  // in [1.2, 5.5] — too small a ratio (a/b near 1) collapses the figure
  // to an ellipse; too large makes it scribble unrecognizably. Center
  // values 3.5 and 2.6 are non-commensurate, so the morph never returns
  // to the same configuration.
  const a   = 3.5 + Math.sin(s.t * 0.00040)         * 2.0;
  const b   = 2.6 + Math.sin(s.t * 0.00057 + 1.3)   * 1.8;
  const phi = Math.PI * 0.5 + Math.sin(s.t * 0.0011) * 1.2;

  // Position. Slightly larger horizontal radius matches typical
  // landscape-orientation canvas aspect.
  const cx = GW * 0.5;
  const cy = GH * 0.5;
  const Rx = GW * 0.40;
  const Ry = GH * 0.42;
  const x = cx + Math.sin(s.t * 0.026 * a / 3.5 + phi) * Rx;
  const y = cy + Math.sin(s.t * 0.026 * b / 2.6)       * Ry;

  // Pigment rotation. Switch to next pigment every 600 frames (~10s)
  // so each figure-era leaves a distinct color trace.
  if (s.t - s.pigCycleAt >= 600) {
    s.pigment = (s.pigment + 1) % 3;
    s.pigCycleAt = s.t;
  }

  const rect = canvas.getBoundingClientRect();
  const pxToGridRadius = (GW / rect.width) * 0.5;
  paintAt(x, y, 11 * pxToGridRadius, s.pigment, 0.26);
}

// --- Flow field (v0.16) --------------------------------------------------
// A bank of particles wanders through a vector field where each cell's
// angle is determined by the existing paperH noise array + a slow time
// shift. paperH is already a smooth noise field across the canvas
// (used for granulation), so re-using it gives spatially-coherent flow
// without needing a Perlin/simplex import.
//
// Particles spawn at random positions, follow the field for their
// lifespan (150-350 frames), paint a small dab at each step, and die
// off-canvas or on age-out. The pool refills continuously so the canvas
// stays alive. Visually: wind-blown / topographic line patterns that
// trace contour lines of the underlying noise field.

const FLOW_FIELD_PARTICLES = 22;
let flowFieldState = null;

function flowFieldStep() {
  if (!flowFieldState) flowFieldState = { particles: [], t: 0 };
  const s = flowFieldState;
  s.t++;

  const rect = canvas.getBoundingClientRect();
  const pxToGridRadius = (GW / rect.width) * 0.5;

  // Update existing particles
  for (let i = s.particles.length - 1; i >= 0; i--) {
    const p = s.particles[i];
    p.age++;
    if (p.age > p.maxAge || p.x < 0 || p.x >= GW || p.y < 0 || p.y >= GH) {
      s.particles.splice(i, 1);
      continue;
    }
    // Sample the paperH noise field at the particle's cell to get an
    // angle. paperH values are roughly [0, 1] so multiplying by 4π
    // gives the angle space two full turns of variation, which makes
    // the flow lines curve more interestingly than just one turn.
    // Time shift slowly rotates the whole field so the patterns
    // morph as the wash continues.
    const idx = Math.floor(p.y) * GW + Math.floor(p.x);
    const noise = paperH[idx] || 0.5;
    const angle = noise * Math.PI * 4 + s.t * 0.0006;
    p.x += Math.cos(angle) * 2.0;
    p.y += Math.sin(angle) * 2.0;
    paintAt(p.x, p.y, 7 * pxToGridRadius, p.pigment, 0.20);
  }

  // Refill the pool so the canvas stays animated indefinitely
  while (s.particles.length < FLOW_FIELD_PARTICLES) {
    s.particles.push({
      x: Math.random() * GW,
      y: Math.random() * GH,
      age: 0,
      maxAge: 150 + Math.random() * 200,
      pigment: Math.floor(Math.random() * 3),
    });
  }
}

// --- Pulse (v0.16) -------------------------------------------------------
// Concentric expanding rings spawn at random epicenters, each painting
// a circle of dabs at its growing radius. When a ring reaches max size,
// it dies. Multiple rings co-exist; their painted regions overlap and
// interfere via the watercolor sim, turning into organic blobs.
//
// Each pulse picks a random pigment so a session shows all three colors
// crossing — KM-mixing where they overlap. Spawn rate jitters so pulses
// don't pop on a fixed metronome.

let pulseState = null;

function pulseStep() {
  if (!pulseState) {
    pulseState = { pulses: [], t: 0, lastSpawn: -100, nextSpawnGap: 60 };
  }
  const s = pulseState;
  s.t++;

  const rect = canvas.getBoundingClientRect();
  const pxToGridRadius = (GW / rect.width) * 0.5;

  // Spawn new pulse on a jittered cadence (60-120 frames apart)
  if (s.t - s.lastSpawn >= s.nextSpawnGap) {
    s.pulses.push({
      x: GW * (0.15 + Math.random() * 0.70),
      y: GH * (0.15 + Math.random() * 0.70),
      r: 0,
      maxR: GH * (0.18 + Math.random() * 0.28),
      pigment: Math.floor(Math.random() * 3),
    });
    s.lastSpawn = s.t;
    s.nextSpawnGap = 60 + Math.floor(Math.random() * 60);
  }

  // Advance each pulse and paint its ring at the current radius
  const N_POINTS = 32;  // sample density along the ring perimeter
  for (let i = s.pulses.length - 1; i >= 0; i--) {
    const p = s.pulses[i];
    p.r += 1.6;
    if (p.r > p.maxR) { s.pulses.splice(i, 1); continue; }
    // Strength tapers as the ring grows — distant rings deposit less
    // pigment, giving the visual sense of a fading wave-front rather
    // than a constant-thickness expanding paint band.
    const tapered = 1 - (p.r / p.maxR);
    const strength = 0.18 + 0.20 * tapered;
    for (let j = 0; j < N_POINTS; j++) {
      const angle = (j / N_POINTS) * Math.PI * 2;
      const x = p.x + Math.cos(angle) * p.r;
      const y = p.y + Math.sin(angle) * p.r;
      if (x < 0 || x >= GW || y < 0 || y >= GH) continue;
      paintAt(x, y, 7 * pxToGridRadius, p.pigment, strength);
    }
  }
}

// ----- dispatcher -------------------------------------------------------
function visualizationStep() {
  switch (visualizationMode) {
    case 'kaleidoscope': kaleidoscopeStep(); break;
    case 'lissajous':    lissajousStep();    break;
    case 'flowField':    flowFieldStep();    break;
    case 'pulse':        pulseStep();        break;
    // 'off' falls through to no-op
  }
}

function clearAllVisualizationState() {
  kaleidoscopeState = null;
  lissajousState = null;
  flowFieldState = null;
  pulseState = null;
}

// ----- UI: visualization mode dropdown (stubbed in library mode) ------
const visualizationSelect = null;

// ============================================================
// TIME OF DAY — sky wash layer (v0.12.2)
// ============================================================
// Each time preset is a one-shot pigment wash painted across the
// canvas using actual pigments, layered on top of whatever was there.
// The wash mixes with subsequent painting via KM compositing — like
// applying a real watercolor sky wash before painting a foreground.
//
// Preset structure (v0.12.2): each preset is a list of independent
// pigment "layers". Each layer has a single pigment and a y→strength
// curve. A dab at fractional position yFrac evaluates EVERY layer's
// curve at yFrac and emits a paintAt for each non-zero contribution,
// all at the same (x, y) and brush size. This lets pigments stack
// on top of each other (e.g. cerulean + rose at the top of night for
// a deeper purple-blue) while still supporting vertical gradients
// (sunset's cerulean→rose→yellow falls out of three curves with
// non-overlapping non-zero regions in the middle, overlapping at the
// transition zones).
//
// The wash spreads dabs over ~0.75 sec so the user watches it apply,
// and so the bleed sim has frame-spacing to smooth between dabs
// instead of all dabs landing simultaneously. Many overlapping
// low-strength dabs accumulate into a soft continuous tone — natural
// wet-on-wet behavior since the canvas starts at wet=0.62.

const TIME_WASH_FRAMES = 45;          // ~0.75 sec at 60 fps
const TIME_WASH_DABS_PER_FRAME = 8;   // total ≈ 360 dab positions per wash
// v0.14.3 — per-preset dab-count override. Some washes need denser
// coverage to fill in the random-dab gaps where the cream paper would
// otherwise show through. Night uses 2× the default for ~720 total dabs
// across the canvas, which (combined with its denser curves) brings
// coverage close to "no white space" without further structural change.
const TIME_WASH_DABS_OVERRIDE = {
  night: 16,
};

// Each preset is an array of layers. Each layer is { pig, curve }
// where curve is an array of [yFrac, strength] control points. The
// curve is piecewise-linear; values of yFrac outside the curve's
// range return 0 strength (so the layer doesn't contribute outside
// its declared region).
const TIME_WASHES = {
  day: [
    // Light uniform cerulean — gentle sky tint.
    { pig: 2, curve: [[0.0, 0.08], [1.0, 0.08]] },
  ],
  night: [
    // v0.14.3 — denser night. Cerulean base bumped from 0.42→0.62 (top)
    // and 0.32→0.50 (bottom); rose zenith from 0.26→0.40. Combined with
    // the per-preset dab-count override below (16 dabs/frame instead of
    // the default 8), the cumulative coverage pushes nearly every cell
    // past the alpha-full-at threshold so the cream paper barely shows.
    // The two pigments still KM-mix into deep blue-purple — same hue,
    // just more saturated. Rose stays confined to the upper 67% so the
    // lower horizon reads as a cooler pure blue.
    { pig: 2, curve: [[0.0, 0.62], [1.0, 0.50]] },         // cerulean denser
    { pig: 0, curve: [[0.0, 0.40], [0.67, 0.0]] },         // rose, top 67% only
  ],
  sunset: [
    // Three-layer gradient: dusk-blue zenith → rose mid → yellow
    // horizon. Each layer's non-zero region overlaps its neighbor
    // at the transition zone so the bleed sim cross-fades cleanly.
    { pig: 2, curve: [[0.0, 0.13], [0.45, 0.0]] },              // cerulean fading out
    { pig: 0, curve: [[0.0, 0.0], [0.45, 0.16], [1.0, 0.0]] },  // rose peaks at 0.45
    { pig: 1, curve: [[0.45, 0.0], [1.0, 0.20]] },              // yellow rising to horizon
  ],
  dawn: [
    // Softer cousin of sunset — same shape, lower strengths, peak
    // pushed slightly toward the top (sky still cool, not yet warm).
    { pig: 2, curve: [[0.0, 0.09], [0.55, 0.0]] },
    { pig: 0, curve: [[0.0, 0.0], [0.55, 0.11], [1.0, 0.0]] },
    { pig: 1, curve: [[0.55, 0.0], [1.0, 0.11]] },
  ],
  tornado: [
    // The classic "tornado sky" — sickly green-yellow through the
    // middle and lower canvas (cerulean + yellow KM-mixing into a
    // pale poison-green), with rose tapering in at the top for the
    // storm-cloud weight overhead. Extracted from the v0.14 tornado
    // animation preset so it can be combined freely: pair with the
    // Tornado animation for the full picture, or with Thunderstorm /
    // Snowing for a stylized stormy palette.
    { pig: 2, curve: [[0.0, 0.18], [1.0, 0.14]] },              // cerulean steady
    { pig: 1, curve: [[0.0, 0.10], [1.0, 0.20]] },              // yellow rising toward horizon
    { pig: 0, curve: [[0.0, 0.10], [0.40, 0.0]] },              // rose top-only (storm clouds)
  ],
};

let timeWash = null;  // { preset, frame }

function startTimeWash(presetName) {
  // Cancel any in-flight wash and start a new one. Switching presets
  // (via Day → Night, etc.) interrupts mid-application — the partially-
  // applied first wash stays on the canvas, and the new wash layers
  // on top of it from a fresh start.
  const spec = TIME_WASHES[presetName];
  if (!spec) { timeWash = null; return; }
  timeWash = { preset: presetName, frame: 0 };
}

// Piecewise-linear interpolation along a single layer's curve. yFrac
// outside the curve's declared range returns 0 — the layer is absent
// from that region of the canvas.
function evalCurve(curve, yFrac) {
  if (yFrac < curve[0][0] || yFrac > curve[curve.length - 1][0]) return 0;
  for (let i = 0; i < curve.length - 1; i++) {
    const y0 = curve[i][0], s0 = curve[i][1];
    const y1 = curve[i + 1][0], s1 = curve[i + 1][1];
    if (yFrac >= y0 && yFrac <= y1) {
      const t = (yFrac - y0) / (y1 - y0);
      return s0 + (s1 - s0) * t;
    }
  }
  return 0;
}

// Called every frame from the main loop. Returns true if the wash
// painted this frame (informational — paintAt already wakes the sim).
function timeWashStep() {
  if (!timeWash) return false;
  const layers = TIME_WASHES[timeWash.preset];
  const dabsPerFrame = TIME_WASH_DABS_OVERRIDE[timeWash.preset] || TIME_WASH_DABS_PER_FRAME;
  const rect = canvas.getBoundingClientRect();
  const pxToGridRadius = (GW / rect.width) * 0.5;
  for (let i = 0; i < dabsPerFrame; i++) {
    const x = Math.random() * GW;
    const y = Math.random() * GH;
    const yFrac = y / GH;
    const brushPx = 70 + Math.random() * 80;
    const gridRadius = brushPx * pxToGridRadius;
    // Evaluate every layer's curve at this y. Each non-zero result
    // produces a paintAt at the same (x, y) — pigments stack into the
    // same cells, KM compositing handles the visual mix.
    for (let L = 0; L < layers.length; L++) {
      const layer = layers[L];
      const str = evalCurve(layer.curve, yFrac);
      if (str > 0.001) paintAt(x, y, gridRadius, layer.pig, str);
    }
  }
  timeWash.frame++;
  if (timeWash.frame >= TIME_WASH_FRAMES) {
    timeWash = null;
    // v0.15 — if Auto-dry background is on, settle the wash immediately.
    // dryPaper() converts all suspended pigment to deposited, zeroes
    // wet/pressure/velocity, and empties the active rect — the sim
    // becomes idle until the next paint event. Particularly valuable
    // before a Visualization starts: a dense Night wash + Kaleidoscope
    // would otherwise mean the whole canvas stays wet and every sim
    // step has to update GH×GW cells. Drying first reclaims those
    // cycles for the visualization.
    if (autoDryBackgroundOn) dryPaper();
  }
  return true;
}

// v2 — auto-dry-background flag, originally driven by a UI toggle.
// Defaults off. Library callers flip it via inst.autoDryBackground(true).
let autoDryBackgroundOn = false;

// v2 — transparent-canvas flag. Originally driven by a UI toggle that
// also changes body styles; in library mode we just hold the value so
// the API getter/setter has somewhere to put it. The actual rendering
// blend behavior is governed by ALPHA_FULL_AT in render() — a cell
// with no pigment renders as transparent regardless of this flag.
// In v2 this is mostly a placeholder; full transparent-background
// support is deferred.
let transparentBg = false;

// ----- UI: time-of-day select (stubbed in library mode) -----
const timeOfDaySelect = null;

// ============================================================
// IDLE SKIP — sim/render skipping when canvas is settled
// ============================================================
// Most of a typical session, nothing is happening: the canvas is dry,
// no pigment is moving, no input is arriving. Running simStep + render
// every frame in that state burns CPU for no visible change. This
// state machine detects when the sim has truly settled and skips the
// hot path until something changes.
//
// Wake conditions (anything that mutates state must call markCanvasActive):
//   • paintAt   — user or AI applies paint
//   • rewet     — global re-wet button
//   • resetSim  — Reset button
//
// Sleep conditions (all checked together once framesSincePaint > grace):
//   • Average wet per cell below a small threshold
//   • Average suspended pigment per cell below a small threshold
// Deposited pigment (d[]) is dry and won't change without water input,
// so we don't need it in the idle check.
//
// The totals lastTotalWet / lastTotalSuspended are maintained by
// updateBars (which runs every frame), so the idle check itself is O(1).
// State (framesSincePaint, simIsIdle, totals) is declared up near the
// state arrays so paintAt / resetSim / rewet can call markCanvasActive
// during init without TDZ errors.

const PAINT_GRACE_FRAMES = 60;        // 1 sec of forced sim after every paint
const IDLE_CHECK_INTERVAL = 30;
const IDLE_WET_PER_CELL = 0.025;      // matches evaporate's dry-out threshold
const IDLE_SUSPENDED_PER_CELL = 0.0005;
// v0.10 — bars run at ~10 Hz instead of 60 Hz. The O(N) fused sum was a
// noticeable chunk of per-frame cost at SCALE 1.75 (1.5 M cells), and
// human perception of bar fill changes saturates well below 60 Hz; the
// CSS transition on .dryness-fill / .pigment-indicator-fill smooths the
// gaps. The idle check (shouldRunSim) reads lastTotalWet/Suspended which
// are still refreshed every tick — 10 Hz is more than fast enough for
// idle detection (the check itself only runs every 30 frames anyway).
const BARS_TICK_INTERVAL = 6;

function shouldRunSim() {
  // Always run during the grace period after any paint event — gives
  // the simulation time to bleed, dry, edge-darken before we consider
  // shutting it off.
  if (framesSincePaint < PAINT_GRACE_FRAMES) return true;
  if (simIsIdle) return false;
  // Past the grace period and not currently idle: check periodically
  // whether the canvas has settled.
  if (framesSinceIdleCheck < IDLE_CHECK_INTERVAL) return true;
  framesSinceIdleCheck = 0;
  const avgWet = lastTotalWet / N;
  const avgSusp = lastTotalSuspended / N;
  if (avgWet < IDLE_WET_PER_CELL && avgSusp < IDLE_SUSPENDED_PER_CELL) {
    simIsIdle = true;
    return false;
  }
  return true;
}

// ============================================================
// PIGMENT FADE — gradual lifting of deposited pigment over time
// ============================================================
// v0.50 — Critically-damped spring decay toward zero (replaces
// pure exponential).
//
// What changed and why:
//   The previous implementation was pure multiplicative decay:
//     d[k][i] *= fadeFactor    (fadeFactor = 0.5^(dt/halflife))
//   Mathematically clean, but visually it asymptotes — the paint
//   *never* really lets go, just gets fainter forever. A hard floor
//   at FADE_SKIP_BELOW snapped the last sliver to 0, giving a small
//   visible jump as the very last bit popped off.
//
//   The spring is a critically-damped 2nd-order system pulling each
//   cell toward x=0 from its current pigment value. The impulse
//   response for a cell starting at rest (v=0, x=x₀) is:
//     x(t) = x₀ · (1 + ω·t) · e^(-ω·t)
//   which is monotonically decreasing, smoothly approaches 0, and
//   *reaches* 0 in finite practical time. Compared to exponential
//   with the same half-life: same midpoint behavior, but the spring
//   accelerates through the second half and lands cleanly instead
//   of asymptoting. Visually: paint lingers, then decisively fades
//   to clean paper.
//
//   Half-life semantics preserved. fadeHalfLifeMs still means "time
//   for a freshly-deposited cell to drop to 50% of its value." The
//   slider keeps working identically.
//
// Implementation:
//   - Per-cell velocity arrays dVel[0..2] (lazy-allocated on first
//     fade enable, ~6.5 MB on default grid)
//   - Closed-form one-step integration via precomputed coefficients
//     (exp() called once at slider-change, not per cell)
//   - Velocity is reset to 0 in the evaporation pass whenever
//     suspended pigment settles into d[] — fresh paint always
//     starts the spring from rest
//   - When x falls below FADE_SKIP_BELOW, snap x and v to 0
//
// Suspended pigment (g[]) is intentionally NOT faded — wet strokes
// stay vibrant until they settle into d[], then begin contributing
// to the spring decay.
const FADE_TICK_INTERVAL = 6;        // 10 Hz at 60 fps; trade CPU for smoothness
const FADE_DEFAULT_MS = 4000;        // 4 s default half-life
const FADE_MIN_MS = 500;             // slider min
const FADE_MAX_MS = 30000;           // slider max
// Don't run fade when there's essentially nothing left to fade —
// avoids waking render() forever to multiply already-zero values.
const FADE_SKIP_BELOW = 0.001;       // avg pigment per cell

// Critical-damping half-life constant: for x(t) = (1+ωt)·e^(-ωt),
// solving x(t)=0.5 gives ω·t ≈ 1.6783. So ω = 1.6783 / T_half.
const FADE_SPRING_HALFLIFE_K = 1.6783;

let fadeEnabled = false;             // toggled by "Fade painting" button
// v0.19 — when true (default), fade ticks trigger a full-canvas re-render
// so cells outside the active rect stay in sync with their faded d[]
// values. Without this, a rectangular outline appears around freshly-
// painted strokes after a fade tick (the active rect's boundary becomes
// visible because cells just inside the rect render at their current
// faded value while cells just outside still show pre-fade pixels).
// Exposed on the API as Watercolor.fadeFullRender(bool).
let fadeFullRender = true;
let fadeHalfLifeMs = FADE_DEFAULT_MS;

// Spring coefficients — recomputed by setFadeHalfLifeMs whenever the
// slider moves. All three are functions of half-life and the tick dt;
// computing them once and reusing across all N cells per tick is what
// makes the integration cheap.
let _fadeSpringDt        = FADE_TICK_INTERVAL / 60;                  // seconds per tick
let _fadeSpringOmega     = FADE_SPRING_HALFLIFE_K / (FADE_DEFAULT_MS / 1000);
let _fadeSpringOmegaDt   = _fadeSpringOmega * _fadeSpringDt;
let _fadeSpringExpOmDt   = Math.exp(-_fadeSpringOmegaDt);
let _fadeSpringOneMinOD  = 1 - _fadeSpringOmegaDt;

// Legacy exponential fadeFactor — kept around because a few perf
// utilities and the docs reference it. The spring is the actual
// behavior; this is just for backward compat / inspection.
let fadeFactor = Math.pow(0.5, _fadeSpringDt / (fadeHalfLifeMs / 1000));

let framesSinceFade = 0;

// Per-cell velocity arrays for the spring integrator. Lazy-allocated
// on first enable to keep the 6.5 MB cost off the table for sessions
// that never use fade. Once allocated, kept around — re-enabling fade
// after a disable just zeroes them so the spring starts at rest.
let dVel = null;
function ensureFadeVelocityArrays() {
  if (dVel !== null) return;
  dVel = [new Float32Array(N), new Float32Array(N), new Float32Array(N)];
}
function resetFadeVelocityArrays() {
  if (dVel === null) return;
  dVel[0].fill(0);
  dVel[1].fill(0);
  dVel[2].fill(0);
}

function setFadeHalfLifeMs(ms) {
  // Clamp defensively in case the slider sends something out of range
  if (ms < FADE_MIN_MS) ms = FADE_MIN_MS;
  else if (ms > FADE_MAX_MS) ms = FADE_MAX_MS;
  fadeHalfLifeMs = ms;
  const halfLifeSec = ms / 1000;
  _fadeSpringOmega    = FADE_SPRING_HALFLIFE_K / halfLifeSec;
  _fadeSpringOmegaDt  = _fadeSpringOmega * _fadeSpringDt;
  _fadeSpringExpOmDt  = Math.exp(-_fadeSpringOmegaDt);
  _fadeSpringOneMinOD = 1 - _fadeSpringOmegaDt;
  // Keep legacy fadeFactor updated for any consumer that reads it.
  fadeFactor = Math.pow(0.5, _fadeSpringDt / halfLifeSec);
}

function fadeStep() {
  // Spring integration constants (precomputed in setFadeHalfLifeMs)
  const omega    = _fadeSpringOmega;
  const dt       = _fadeSpringDt;
  const expOmDt  = _fadeSpringExpOmDt;
  const omegaDt  = _fadeSpringOmegaDt;
  const oneMinOD = _fadeSpringOneMinOD;
  const floor    = FADE_SKIP_BELOW;

  const d0 = d[0], d1 = d[1], d2 = d[2];
  const v0 = dVel[0], v1 = dVel[1], v2 = dVel[2];

  // Closed-form one-step integration of the critically-damped spring
  // ODE ẍ + 2ω·ẋ + ω²·x = 0 from current state (x, v):
  //   B  = v + ω·x
  //   x' = (x + B·dt) · e^(-ω·dt)
  //   v' = (B·(1 - ω·dt) - ω·x) · e^(-ω·dt)
  // Exact (no integrator drift), stable for any dt.
  function stepChannel(d_, v_, i) {
    const x = d_[i];
    if (x <= 0) {
      // Spring at rest at origin — nothing to do, and v should already
      // be 0 (paintAt resets it; floor clamp resets it; no other source
      // of velocity). Belt-and-suspenders zero it anyway.
      if (v_[i] !== 0) v_[i] = 0;
      return;
    }
    const v = v_[i];
    const B = v + omega * x;
    let newX = (x + B * dt) * expOmDt;
    let newV = (B * oneMinOD - omega * x) * expOmDt;
    // Clamp to floor: when the spring approaches the origin, snap to
    // exactly 0 so the cell stops contributing to compute and renders
    // as clean paper. The threshold matches the legacy hard-cut so
    // total fade completion time is comparable.
    if (newX < floor) { newX = 0; newV = 0; }
    d_[i] = newX;
    v_[i] = newV;
  }

  // Masked cells freeze pigment in place — fade can't reach them.
  // Branch on maskActive to keep the hot loop tight when no mask exists.
  if (maskActive) {
    for (let y = 0; y < GH; y++) {
      const rowMaybeMasked = (y >= maskRectMinY && y <= maskRectMaxY);
      const yo = y * GW;
      for (let x = 0; x < GW; x++) {
        const i = yo + x;
        if (rowMaybeMasked && x >= maskRectMinX && x <= maskRectMaxX &&
            mask[i] > MASK_THRESHOLD) continue;
        stepChannel(d0, v0, i);
        stepChannel(d1, v1, i);
        stepChannel(d2, v2, i);
      }
    }
  } else {
    for (let i = 0; i < N; i++) {
      stepChannel(d0, v0, i);
      stepChannel(d1, v1, i);
      stepChannel(d2, v2, i);
    }
  }
}

// ============================================================


// ============================================================
// WEBGL RENDER PATH (v2 lib addition — extracted from v0.20)
// ============================================================
// continues to work. The toggle's UI also disables itself.
//
// Toggle: useGPU. When true, the main loop's render() call routes to
// gpuRender(). When false, the CPU render() runs as before.

let glCanvas = null;             // hidden <canvas> hosting the WebGL2 context
let gl = null;                   // WebGL2 context, null if init failed
let gpuProgram = null;           // compiled+linked shader program
let gpuUniforms = null;          // uniform locations cache
let gpuPaintTex = null;          // RGBA32F: r=g0+d0, g=g1+d1, b=g2+d2, a=wet
let gpuExtraTex = null;          // RGBA32F: r=paperH, g=mask, b=ink, a=0  (v0.97)
let gpuVAO = null;               // fullscreen quad
let gpuAvailable = false;        // result of init; latched
let gpuInitTried = false;        // gate init to first attempt
let useGPU = false;              // user toggle; UI-bound

// Display the GPU canvas — separately from the CPU render path's
// scaled drawImage. We composite into the SAME visible #canvas via
// drawImage, so the two paths are interchangeable at the display layer.
// This keeps every existing piece of UI (cursor preview, dimensions,
// transparent toggle) unchanged.

function initWebGL() {
  if (gpuInitTried) return gpuAvailable;
  gpuInitTried = true;

  // Create the offscreen canvas at sim resolution (GW × GH). The CPU
  // render path uses an offscreen canvas of the same size, then scales
  // to display via drawImage — we'll do the same so behavior matches.
  glCanvas = document.createElement('canvas');
  glCanvas.width = GW;
  glCanvas.height = GH;
  try {
    gl = glCanvas.getContext('webgl2', {
      antialias: false,
      premultipliedAlpha: false,
      preserveDrawingBuffer: false,
    });
  } catch (e) {
    console.warn('WebGL2 context creation threw:', e);
    gl = null;
  }
  if (!gl) {
    console.warn('WebGL2 unavailable; toggle will fall back to CPU.');
    return false;
  }

  // EXT_color_buffer_float — needed to render INTO float textures in
  // future sim-on-GPU work. Not strictly required for the v0.20 render
  // shader (which reads floats but writes to the default framebuffer),
  // but we feature-detect now so v0.20.x can land easily.
  gl.getExtension('EXT_color_buffer_float');
  // OES_texture_float_linear — lets shaders sample float textures with
  // linear filtering. We use NEAREST in v0.20 (one-to-one pixel reads)
  // so it's not required, but harmless to request.
  gl.getExtension('OES_texture_float_linear');

  // Vertex shader: fullscreen quad. Standard 2-triangle covering [-1,1]².
  // Outputs vUv ∈ [0,1]² for the fragment shader to sample textures.
  const vsSrc = `#version 300 es
    in vec2 aPos;
    out vec2 vUv;
    void main() {
      vUv = aPos * 0.5 + 0.5;
      gl_Position = vec4(aPos, 0.0, 1.0);
    }
  `;

  // Fragment shader: mirrors the CPU render() per-cell loop.
  // Inputs:
  //   uPaint  — vec4 per cell: (g0+d0, g1+d1, g2+d2, wet)
  //   uExtra  — vec4 per cell: (paperH, mask, 0, 0)
  //   uPaper  — vec3: PAPER_R/G/B_BASE
  //   uMaskActive — bool
  //   uPigK0/1/2, uPigS0/1/2 — vec3 K, S per pigment (3 pigments)
  //
  // Math identical to the CPU path:
  //   1. xt = g0+d0 + g1+d1 + g2+d2
  //   2. paper texture = paperBase + (paperH - 0.5) * 0.06
  //   3. if xt < 0.004: paper + dampSheen
  //      else: weighted K and S, kmReflect per channel
  //   4. alpha based on xt
  //   5. if mask above threshold: blend warm yellow tint over the result
  //
  // kmReflect ported directly from the CPU JS function. GLSL sinh/cosh
  // expand to the standard exp() form to be cross-vendor portable.
  const fsSrc = `#version 300 es
    precision highp float;
    in vec2 vUv;
    out vec4 outColor;

    uniform sampler2D uPaint;
    uniform sampler2D uExtra;
    uniform vec3 uPaper;
    uniform bool uMaskActive;
    uniform bool uMaskTintVisible;   // v0.80 — false = mask still freezes, but no amber overlay
    uniform bool uInkActive;         // v0.97 — true when ink has been deposited

    uniform vec3 uPigK0;
    uniform vec3 uPigK1;
    uniform vec3 uPigK2;
    uniform vec3 uPigS0;
    uniform vec3 uPigS1;
    uniform vec3 uPigS2;

    uniform float uDebugTint;     // 0.0 = off; >0 tints visible green
    uniform vec2 uEdgeFadeFrac;   // v0.88 — (x_frac, y_frac); 0 = off

    const float MASK_THRESHOLD = 0.1;
    const float MASK_VISUAL_FULL = 0.6;
    const float MASK_TINT_PEAK = 0.30;
    const float ALPHA_FULL_AT = 0.012;
    const float INK_ALPHA = 0.95;      // v0.97 — matches the CPU INK_ALPHA constant
    const float INK_THRESHOLD = 0.005; // v0.97 — matches the CPU INK_THRESHOLD

    // Kubelka-Munk reflectance for a single channel. Mirrors kmReflect
    // in the CPU code, using exp() for sinh/cosh (more numerically
    // stable for large bSx than glsl sinh()/cosh() on some drivers).
    float kmReflect(float K, float S, float x, float Rbg) {
      S = max(S, 1e-5);
      float a = 1.0 + K / S;
      float b = sqrt(max(0.0, a * a - 1.0));
      float bSx = min(b * S * x, 12.0);
      // sinh(z) = (e^z - e^-z)/2; cosh(z) = (e^z + e^-z)/2
      float ez = exp(bSx);
      float emz = exp(-bSx);
      float sh = (ez - emz) * 0.5;
      float ch = (ez + emz) * 0.5;
      float denom = a * sh + b * ch;
      if (denom < 1e-9) return 0.0;
      float Rlayer = sh / denom;
      float Tlayer = b  / denom;
      float R = Rlayer + (Tlayer * Tlayer * Rbg) / (1.0 - Rlayer * Rbg);
      return clamp(R, 0.0, 1.0);
    }

    void main() {
      // v0.20 — Y-flip on texture sample. The CPU code lays out cells
      // with row 0 at the top of the canvas (matching the 2D canvas
      // convention). WebGL textures, by default, have texture Y=0 at
      // the bottom of the framebuffer. Without flipping, the rendered
      // image is upside-down. Flipping vUv.y at the sample call inverts
      // the read so cell row 0 in the upload buffer lands at the visible
      // top edge.
      vec2 uv = vec2(vUv.x, 1.0 - vUv.y);
      vec4 paint = texture(uPaint, uv);
      vec4 extra = texture(uExtra, uv);
      float xt = paint.r + paint.g + paint.b;     // total pigment
      float wet = paint.a;
      float paperH = extra.r;
      float mask = extra.g;
      float ink = extra.b;                         // v0.97 — ink in extra.b

      float tex = (paperH - 0.5) * 0.06;
      vec3 paperColor = uPaper + vec3(tex);

      vec3 rgb;
      if (xt < 0.004) {
        float dampSheen = wet * 0.018;
        rgb = paperColor + vec3(dampSheen, dampSheen, dampSheen * 1.2);
      } else {
        float inv = 1.0 / xt;
        float w0 = paint.r * inv;
        float w1 = paint.g * inv;
        float w2 = paint.b * inv;
        vec3 K = uPigK0 * w0 + uPigK1 * w1 + uPigK2 * w2;
        vec3 S = uPigS0 * w0 + uPigS1 * w1 + uPigS2 * w2;
        float thickness = min(xt, 4.0);
        rgb = vec3(
          kmReflect(K.r, S.r, thickness, paperColor.r),
          kmReflect(K.g, S.g, thickness, paperColor.g),
          kmReflect(K.b, S.b, thickness, paperColor.b)
        );
      }

      float alpha = xt >= ALPHA_FULL_AT ? 1.0 : (xt / ALPHA_FULL_AT);

      // Mask tint — same continuous ramp as CPU render
      if (uMaskActive && uMaskTintVisible && mask > MASK_THRESHOLD) {
        float maskVis = min(1.0,
          (mask - MASK_THRESHOLD) / (MASK_VISUAL_FULL - MASK_THRESHOLD));
        float tb = maskVis * MASK_TINT_PEAK;
        rgb = mix(rgb, vec3(0.96, 0.86, 0.42), tb);
        float maskAlpha = maskVis * (215.0 / 255.0);
        alpha = max(alpha, maskAlpha);
      }

      // v0.97 — Ink darkening. Mirrors CPU render: applied AFTER mask
      // tint so ink reads through the mask amber rather than being
      // blended away. Multiplies rgb by (1 - ink * INK_ALPHA) and
      // forces full opacity at inked cells.
      if (uInkActive && ink > INK_THRESHOLD) {
        float darken = 1.0 - ink * INK_ALPHA;
        rgb *= darken;
        alpha = max(alpha, 1.0);   // force full opacity at inked cells
      }

      // v0.20 — debug tint. When uDebugTint > 0, blend a faint green
      // wash over the entire output. Used to make the GPU render path
      // visually distinguishable from the CPU path for verification.
      // Default 0.0 (no tint). Toggle from console with
      // Watercolor.webglDebugTint(true).
      if (uDebugTint > 0.0) {
        rgb = mix(rgb, vec3(0.6, 1.0, 0.6), uDebugTint * 0.25);
      }

      // v0.88 — edge fade. Smoothstep from 0 alpha at boundary to
      // 1 alpha at fade-depth from boundary. Per-axis fractions
      // (uEdgeFadeFrac.x for left/right edges, .y for top/bottom)
      // since canvas may not be square. uv is already in 0..1 with
      // y flipped to match texture orientation. Sample distance
      // from nearest edge as min(uv.x, 1-uv.x, uv.y, 1-uv.y).
      if (uEdgeFadeFrac.x > 0.0 || uEdgeFadeFrac.y > 0.0) {
        float dxN = min(uv.x, 1.0 - uv.x);
        float dyN = min(uv.y, 1.0 - uv.y);
        float fadeX = uEdgeFadeFrac.x > 0.0 ? smoothstep(0.0, uEdgeFadeFrac.x, dxN) : 1.0;
        float fadeY = uEdgeFadeFrac.y > 0.0 ? smoothstep(0.0, uEdgeFadeFrac.y, dyN) : 1.0;
        alpha *= min(fadeX, fadeY);
      }

      outColor = vec4(rgb, alpha);
    }
  `;

  function compileShader(type, src) {
    const sh = gl.createShader(type);
    gl.shaderSource(sh, src);
    gl.compileShader(sh);
    if (!gl.getShaderParameter(sh, gl.COMPILE_STATUS)) {
      console.error('Shader compile error:', gl.getShaderInfoLog(sh));
      gl.deleteShader(sh);
      return null;
    }
    return sh;
  }

  const vs = compileShader(gl.VERTEX_SHADER, vsSrc);
  const fs = compileShader(gl.FRAGMENT_SHADER, fsSrc);
  if (!vs || !fs) return false;

  gpuProgram = gl.createProgram();
  gl.attachShader(gpuProgram, vs);
  gl.attachShader(gpuProgram, fs);
  gl.linkProgram(gpuProgram);
  if (!gl.getProgramParameter(gpuProgram, gl.LINK_STATUS)) {
    console.error('Program link error:', gl.getProgramInfoLog(gpuProgram));
    return false;
  }

  // Cache uniform locations. getUniformLocation is fast but doing it
  // per frame allocates strings; per-program caching is the standard
  // pattern.
  gpuUniforms = {
    uPaint:       gl.getUniformLocation(gpuProgram, 'uPaint'),
    uExtra:       gl.getUniformLocation(gpuProgram, 'uExtra'),
    uPaper:       gl.getUniformLocation(gpuProgram, 'uPaper'),
    uMaskActive:  gl.getUniformLocation(gpuProgram, 'uMaskActive'),
    uMaskTintVisible: gl.getUniformLocation(gpuProgram, 'uMaskTintVisible'),
    uInkActive:   gl.getUniformLocation(gpuProgram, 'uInkActive'),  // v0.97
    uPigK0:       gl.getUniformLocation(gpuProgram, 'uPigK0'),
    uPigK1:       gl.getUniformLocation(gpuProgram, 'uPigK1'),
    uPigK2:       gl.getUniformLocation(gpuProgram, 'uPigK2'),
    uPigS0:       gl.getUniformLocation(gpuProgram, 'uPigS0'),
    uPigS1:       gl.getUniformLocation(gpuProgram, 'uPigS1'),
    uPigS2:       gl.getUniformLocation(gpuProgram, 'uPigS2'),
    uDebugTint:    gl.getUniformLocation(gpuProgram, 'uDebugTint'),
    uEdgeFadeFrac: gl.getUniformLocation(gpuProgram, 'uEdgeFadeFrac'),
  };

  // Fullscreen quad VAO. Two triangles covering NDC [-1,1]².
  gpuVAO = gl.createVertexArray();
  gl.bindVertexArray(gpuVAO);
  const quadBuf = gl.createBuffer();
  gl.bindBuffer(gl.ARRAY_BUFFER, quadBuf);
  gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([
    -1, -1,   1, -1,   -1, 1,
     1, -1,   1,  1,   -1, 1
  ]), gl.STATIC_DRAW);
  const posLoc = gl.getAttribLocation(gpuProgram, 'aPos');
  gl.enableVertexAttribArray(posLoc);
  gl.vertexAttribPointer(posLoc, 2, gl.FLOAT, false, 0, 0);
  gl.bindVertexArray(null);

  // Allocate float textures sized at the sim grid. These get re-uploaded
  // each frame with the CPU state. v0.20.x will move state ownership to
  // these textures and stop the upload.
  function makeTex() {
    const t = gl.createTexture();
    gl.bindTexture(gl.TEXTURE_2D, t);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA32F, GW, GH, 0, gl.RGBA, gl.FLOAT, null);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
    return t;
  }
  gpuPaintTex = makeTex();
  gpuExtraTex = makeTex();

  gpuAvailable = true;
  return true;
}

// Scratch buffers for the per-frame state upload. Allocated lazily on
// first GPU render. Reallocated on resolution change (handled by
// rebuildScale, see the gpuOnResize hook below).
let gpuPaintBuf = null;
let gpuExtraBuf = null;
// v0.20 — debug tint. When true, the GPU shader blends a faint green
// over the entire output so users can verify the WebGL path is
// actually running. No effect on the CPU render path.
let gpuDebugTint = false;

function gpuEnsureBuffers() {
  if (!gpuPaintBuf || gpuPaintBuf.length !== N * 4) {
    gpuPaintBuf = new Float32Array(N * 4);
    gpuExtraBuf = new Float32Array(N * 4);
  }
}

function gpuOnResize() {
  if (!gpuAvailable) return;
  glCanvas.width = GW;
  glCanvas.height = GH;
  // Reallocate textures at the new size. The old ones get GC'd by the
  // driver once nothing references them.
  gl.bindTexture(gl.TEXTURE_2D, gpuPaintTex);
  gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA32F, GW, GH, 0, gl.RGBA, gl.FLOAT, null);
  gl.bindTexture(gl.TEXTURE_2D, gpuExtraTex);
  gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA32F, GW, GH, 0, gl.RGBA, gl.FLOAT, null);
  gpuPaintBuf = null;
  gpuExtraBuf = null;
}

function gpuRender() {
  if (!gpuAvailable) return;
  gpuEnsureBuffers();

  // Pack the CPU state arrays into the texture upload buffers.
  // paint: (g0+d0, g1+d1, g2+d2, wet)
  // extra: (paperH, mask, ink, 0)
  //         v0.97 ↑ uses the previously-unused blue channel
  const g0 = g[0], g1 = g[1], g2 = g[2];
  const d0 = d[0], d1 = d[1], d2 = d[2];
  for (let i = 0; i < N; i++) {
    const j = i * 4;
    gpuPaintBuf[j]     = g0[i] + d0[i];
    gpuPaintBuf[j + 1] = g1[i] + d1[i];
    gpuPaintBuf[j + 2] = g2[i] + d2[i];
    gpuPaintBuf[j + 3] = wet[i];
    gpuExtraBuf[j]     = paperH[i];
    gpuExtraBuf[j + 1] = mask[i];
    gpuExtraBuf[j + 2] = ink[i];     // v0.97 — ink in extra.b
    // byte 3 stays 0; was Float32Array-initialized to 0 and nothing
    // else writes it.
  }

  gl.bindTexture(gl.TEXTURE_2D, gpuPaintTex);
  gl.texSubImage2D(gl.TEXTURE_2D, 0, 0, 0, GW, GH, gl.RGBA, gl.FLOAT, gpuPaintBuf);
  gl.bindTexture(gl.TEXTURE_2D, gpuExtraTex);
  gl.texSubImage2D(gl.TEXTURE_2D, 0, 0, 0, GW, GH, gl.RGBA, gl.FLOAT, gpuExtraBuf);

  // Bind program + uniforms + draw the fullscreen quad
  gl.viewport(0, 0, GW, GH);
  gl.clearColor(0, 0, 0, 0);
  gl.clear(gl.COLOR_BUFFER_BIT);
  gl.useProgram(gpuProgram);
  gl.activeTexture(gl.TEXTURE0);
  gl.bindTexture(gl.TEXTURE_2D, gpuPaintTex);
  gl.uniform1i(gpuUniforms.uPaint, 0);
  gl.activeTexture(gl.TEXTURE1);
  gl.bindTexture(gl.TEXTURE_2D, gpuExtraTex);
  gl.uniform1i(gpuUniforms.uExtra, 1);
  gl.uniform3f(gpuUniforms.uPaper, PAPER_R_BASE, PAPER_G_BASE, PAPER_B_BASE);
  gl.uniform1i(gpuUniforms.uMaskActive, maskActive ? 1 : 0);
  gl.uniform1i(gpuUniforms.uMaskTintVisible, _maskTintVisible ? 1 : 0);
  gl.uniform1i(gpuUniforms.uInkActive, inkActive ? 1 : 0);   // v0.97
  gl.uniform3f(gpuUniforms.uPigK0, PIGMENTS[0].K[0], PIGMENTS[0].K[1], PIGMENTS[0].K[2]);
  gl.uniform3f(gpuUniforms.uPigK1, PIGMENTS[1].K[0], PIGMENTS[1].K[1], PIGMENTS[1].K[2]);
  gl.uniform3f(gpuUniforms.uPigK2, PIGMENTS[2].K[0], PIGMENTS[2].K[1], PIGMENTS[2].K[2]);
  gl.uniform3f(gpuUniforms.uPigS0, PIGMENTS[0].S[0], PIGMENTS[0].S[1], PIGMENTS[0].S[2]);
  gl.uniform3f(gpuUniforms.uPigS1, PIGMENTS[1].S[0], PIGMENTS[1].S[1], PIGMENTS[1].S[2]);
  gl.uniform3f(gpuUniforms.uPigS2, PIGMENTS[2].S[0], PIGMENTS[2].S[1], PIGMENTS[2].S[2]);
  gl.uniform1f(gpuUniforms.uDebugTint, gpuDebugTint ? 1.0 : 0.0);
  // v0.88 — edge fade. Per-axis fractions; 0 disables that axis.
  if (_edgeFadePixels > 0) {
    gl.uniform2f(gpuUniforms.uEdgeFadeFrac,
      _edgeFadePixels / GW,
      _edgeFadePixels / GH);
  } else {
    gl.uniform2f(gpuUniforms.uEdgeFadeFrac, 0, 0);
  }
  gl.bindVertexArray(gpuVAO);
  gl.drawArrays(gl.TRIANGLES, 0, 6);
  gl.bindVertexArray(null);

  // Composite the GL canvas to the display canvas. Same drawImage path
  // the CPU render uses — keeps the display layer interchangeable.
  ctx.clearRect(0, 0, DISPLAY_W, DISPLAY_H);
  ctx.drawImage(glCanvas, 0, 0, DISPLAY_W, DISPLAY_H);
  // v0.86 — wetness heatmap overlay (no-op when disabled).
  _renderWetnessHeatmap();
}


// ============================================================
// PIGMENT SWATCHES (v2 lib addition — extracted from v0.26.2)
// Generates a row of real KM-rendered swatches into a target
// element. Each swatch is a 56×56 <canvas> drawn through the
// same kmReflect compositor the main render uses, so paper
// texture, edge fade, and pigment color look the same as the
// painted canvas. Click handlers update currentPigment and
// dispatch a "pigmentchange" CustomEvent on the root element
// so the host UI can react (highlight active, update cursor,
// etc.) without the lib needing to know about its DOM.
// ============================================================
// PIGMENT SWATCHES — rendered with the actual KM compositor
// ============================================================
function buildPigmentSwatches(rootEl) {
  const root = rootEl;
  const pigmentsRoot = rootEl;
  // Idempotent — clear any existing children so calling this again
  // (e.g. after a paper-color change) replaces rather than appends.
  root.replaceChildren();
  PIGMENTS.forEach((p, idx) => {
    const wrap = document.createElement('div');
    wrap.className = 'pigment' + (idx === currentPigment ? ' active' : '');
    wrap.title = p.name;
    wrap.dataset.idx = idx;

    const swatchDiv = document.createElement('div');
    swatchDiv.className = 'pigment-swatch';

    const sc = document.createElement('canvas');
    sc.width = 56; sc.height = 56;
    const sctx = sc.getContext('2d');
    const sd = sctx.createImageData(56, 56);
    // Render swatch using KM with varying thickness for a natural look
    for (let y = 0; y < 56; y++) {
      for (let x = 0; x < 56; x++) {
        const dx = x - 28, dy = y - 28;
        const d2 = dx*dx + dy*dy;
        if (d2 > 28*28) {
          const j = (y * 56 + x) * 4;
          sd.data[j] = 0; sd.data[j+1] = 0; sd.data[j+2] = 0; sd.data[j+3] = 0;
          continue;
        }
        // Thickness varies a bit across the swatch — thicker bottom, thinner top
        const grad = 1 - (y / 56) * 0.4;
        const speckle = 0.85 + 0.3 * smoothNoise(x * 0.3, y * 0.3);
        const xk = 1.1 * grad * speckle;
        const R = kmReflect(p.K[0], p.S[0], xk, PAPER_R_BASE);
        const G = kmReflect(p.K[1], p.S[1], xk, PAPER_G_BASE);
        const B = kmReflect(p.K[2], p.S[2], xk, PAPER_B_BASE);
        const j = (y * 56 + x) * 4;
        sd.data[j]     = R * 255;
        sd.data[j + 1] = G * 255;
        sd.data[j + 2] = B * 255;
        sd.data[j + 3] = 255;
      }
    }
    sctx.putImageData(sd, 0, 0);
    swatchDiv.appendChild(sc);

    const lbl = document.createElement('div');
    lbl.className = 'pigment-label';
    // Two-line label: short name
    const parts = p.name.split(' ');
    lbl.innerHTML = parts.join('<br>');

    wrap.appendChild(swatchDiv);
    wrap.appendChild(lbl);

    wrap.addEventListener('click', () => {
      currentPigment = idx;
      document.querySelectorAll('.pigment').forEach(el => el.classList.remove('active'));
      wrap.classList.add('active');
      pigmentsRoot.dispatchEvent(new CustomEvent('pigmentchange', { detail: { pigment: currentPigment } }));
    });

    root.appendChild(wrap);
  });

  // Water swatch — not a pigment but a tool that adds wetness + pressure
  // and lifts a fraction of deposited pigment back into suspension.
  // Rendered as bare paper with a subtle cool tint (suggesting wet
  // paper) and the same speckle as the pigment swatches.
  {
    const wrap = document.createElement('div');
    wrap.className = 'pigment' + (currentPigment === WATER_INDEX ? ' active' : '');
    wrap.title = 'Water — wets the paper and lifts pigment, no color added';
    wrap.dataset.idx = WATER_INDEX;

    const swatchDiv = document.createElement('div');
    swatchDiv.className = 'pigment-swatch';

    const sc = document.createElement('canvas');
    sc.width = 56; sc.height = 56;
    const sctx = sc.getContext('2d');
    const sd = sctx.createImageData(56, 56);
    for (let y = 0; y < 56; y++) {
      for (let x = 0; x < 56; x++) {
        const dx = x - 28, dy = y - 28;
        const d2 = dx*dx + dy*dy;
        const j = (y * 56 + x) * 4;
        if (d2 > 28*28) {
          sd.data[j] = 0; sd.data[j+1] = 0; sd.data[j+2] = 0; sd.data[j+3] = 0;
          continue;
        }
        const speckle = 0.92 + 0.12 * smoothNoise(x * 0.3, y * 0.3);
        // Wet paper looks slightly darker and a touch cooler than dry paper.
        // Use the same paper base color so the swatch matches its surroundings,
        // then nudge it toward blue-gray.
        const grad = 0.94 - (y / 56) * 0.04;     // mild top-to-bottom shading
        const R = PAPER_R_BASE * speckle * grad * 0.94;
        const G = PAPER_G_BASE * speckle * grad * 0.96;
        const B = PAPER_B_BASE * speckle * grad * 1.02;
        sd.data[j]     = Math.min(255, R * 255);
        sd.data[j + 1] = Math.min(255, G * 255);
        sd.data[j + 2] = Math.min(255, B * 255);
        sd.data[j + 3] = 255;
      }
    }
    sctx.putImageData(sd, 0, 0);
    swatchDiv.appendChild(sc);

    const lbl = document.createElement('div');
    lbl.className = 'pigment-label';
    lbl.innerHTML = 'Water';

    wrap.appendChild(swatchDiv);
    wrap.appendChild(lbl);

    wrap.addEventListener('click', () => {
      currentPigment = WATER_INDEX;
      document.querySelectorAll('.pigment').forEach(el => el.classList.remove('active'));
      wrap.classList.add('active');
      pigmentsRoot.dispatchEvent(new CustomEvent('pigmentchange', { detail: { pigment: currentPigment } }));
    });

    root.appendChild(wrap);
  }

  // Lift swatch — subtractive brush. Rendered as paper with a slightly
  // brighter center (the "absorbed spot" left by a tissue blot) and a
  // gentle warm tint, so it visually contrasts the water swatch's cool
  // tint and reads as removal rather than addition.
  {
    const wrap = document.createElement('div');
    wrap.className = 'pigment' + (currentPigment === LIFT_INDEX ? ' active' : '');
    wrap.title = 'Lift — removes pigment from the paper, water level unchanged';
    wrap.dataset.idx = LIFT_INDEX;

    const swatchDiv = document.createElement('div');
    swatchDiv.className = 'pigment-swatch';

    const sc = document.createElement('canvas');
    sc.width = 56; sc.height = 56;
    const sctx = sc.getContext('2d');
    const sd = sctx.createImageData(56, 56);
    for (let y = 0; y < 56; y++) {
      for (let x = 0; x < 56; x++) {
        const dx = x - 28, dy = y - 28;
        const d2 = dx*dx + dy*dy;
        const j = (y * 56 + x) * 4;
        if (d2 > 28*28) {
          sd.data[j] = 0; sd.data[j+1] = 0; sd.data[j+2] = 0; sd.data[j+3] = 0;
          continue;
        }
        const speckle = 0.92 + 0.12 * smoothNoise(x * 0.3, y * 0.3);
        const dist = Math.sqrt(d2) / 28;
        // Brighter near center, gently dimmer near edge — like the
        // lighter spot a blotted tissue leaves on a wet wash.
        const liftBright = 1.04 - 0.06 * dist;
        const R = PAPER_R_BASE * speckle * liftBright;
        const G = PAPER_G_BASE * speckle * liftBright * 0.99;
        const B = PAPER_B_BASE * speckle * liftBright * 0.96;  // slight warm
        sd.data[j]     = Math.min(255, R * 255);
        sd.data[j + 1] = Math.min(255, G * 255);
        sd.data[j + 2] = Math.min(255, B * 255);
        sd.data[j + 3] = 255;
      }
    }
    sctx.putImageData(sd, 0, 0);
    swatchDiv.appendChild(sc);

    const lbl = document.createElement('div');
    lbl.className = 'pigment-label';
    lbl.innerHTML = 'Lift';

    wrap.appendChild(swatchDiv);
    wrap.appendChild(lbl);

    wrap.addEventListener('click', () => {
      currentPigment = LIFT_INDEX;
      document.querySelectorAll('.pigment').forEach(el => el.classList.remove('active'));
      wrap.classList.add('active');
      pigmentsRoot.dispatchEvent(new CustomEvent('pigmentchange', { detail: { pigment: currentPigment } }));
    });

    root.appendChild(wrap);
  }

  // Rainbow swatch — horizontal sweep through the three pigments
  // using the same KM math that paintAt's rainbow branch will deposit.
  // Shows rose at the left edge through yellow in the middle to blue
  // at the right edge; the blue→rose wrap part of the cycle is not
  // drawn here since the user can already see all three primaries.
  {
    const wrap = document.createElement('div');
    wrap.className = 'pigment' + (currentPigment === RAINBOW_INDEX ? ' active' : '');
    wrap.title = 'Rainbow — cycles rose → yellow → blue → rose over 2.25s';
    wrap.dataset.idx = RAINBOW_INDEX;

    const swatchDiv = document.createElement('div');
    swatchDiv.className = 'pigment-swatch';

    const sc = document.createElement('canvas');
    sc.width = 56; sc.height = 56;
    const sctx = sc.getContext('2d');
    const sd = sctx.createImageData(56, 56);
    const P0 = PIGMENTS[0], P1 = PIGMENTS[1], P2 = PIGMENTS[2];
    for (let y = 0; y < 56; y++) {
      for (let x = 0; x < 56; x++) {
        const dx = x - 28, dy = y - 28;
        const d2 = dx*dx + dy*dy;
        const j = (y * 56 + x) * 4;
        if (d2 > 28*28) {
          sd.data[j] = 0; sd.data[j+1] = 0; sd.data[j+2] = 0; sd.data[j+3] = 0;
          continue;
        }
        // Map x position to first 2/3 of the rainbow cycle so we get
        // rose → yellow → blue across the swatch width. Three weights
        // computed inline with the same shape as updateRainbowWeights
        // but parameterized by x instead of time.
        const frac = x / 55; // 0..1 across width
        let w0, w1, w2;
        if (frac < 0.5) {
          const f = frac / 0.5;
          w0 = 1 - f; w1 = f; w2 = 0;
        } else {
          const f = (frac - 0.5) / 0.5;
          w0 = 0; w1 = 1 - f; w2 = f;
        }
        const Kr = P0.K[0]*w0 + P1.K[0]*w1 + P2.K[0]*w2;
        const Kg = P0.K[1]*w0 + P1.K[1]*w1 + P2.K[1]*w2;
        const Kb = P0.K[2]*w0 + P1.K[2]*w1 + P2.K[2]*w2;
        const Sr = P0.S[0]*w0 + P1.S[0]*w1 + P2.S[0]*w2;
        const Sg = P0.S[1]*w0 + P1.S[1]*w1 + P2.S[1]*w2;
        const Sb = P0.S[2]*w0 + P1.S[2]*w1 + P2.S[2]*w2;
        // Slight thickness variation by y for an organic swatch feel,
        // matching the speckle treatment of the pigment swatches.
        const thickness = 0.55 + 0.4 * smoothNoise(x * 0.3, y * 0.3);
        const R = kmReflect(Kr, Sr, thickness, PAPER_R_BASE);
        const G = kmReflect(Kg, Sg, thickness, PAPER_G_BASE);
        const B = kmReflect(Kb, Sb, thickness, PAPER_B_BASE);
        sd.data[j]     = Math.min(255, Math.max(0, R * 255));
        sd.data[j + 1] = Math.min(255, Math.max(0, G * 255));
        sd.data[j + 2] = Math.min(255, Math.max(0, B * 255));
        sd.data[j + 3] = 255;
      }
    }
    sctx.putImageData(sd, 0, 0);
    swatchDiv.appendChild(sc);

    const lbl = document.createElement('div');
    lbl.className = 'pigment-label';
    lbl.innerHTML = 'Rainbow';

    wrap.appendChild(swatchDiv);
    wrap.appendChild(lbl);

    wrap.addEventListener('click', () => {
      currentPigment = RAINBOW_INDEX;
      document.querySelectorAll('.pigment').forEach(el => el.classList.remove('active'));
      wrap.classList.add('active');
      pigmentsRoot.dispatchEvent(new CustomEvent('pigmentchange', { detail: { pigment: currentPigment } }));
    });

    root.appendChild(wrap);
  }

  // Masking-fluid swatch (v0.13). Painted on first to reserve paper —
  // any subsequent pigment/water/lift skips masked cells. Rendered as
  // a pale yellow blob with a darker yellow speckled rim to match the
  // visual appearance of real masking fluid (which is typically a
  // yellowish-amber liquid latex). Active state still picks it up via
  // the .active class so the user can see which brush is selected.
  {
    const wrap = document.createElement('div');
    wrap.className = 'pigment' + (currentPigment === MASK_INDEX ? ' active' : '');
    wrap.title = 'Mask — paints masking fluid that reserves paper from any subsequent painting. Remove with the "Remove mask" button.';
    wrap.dataset.idx = MASK_INDEX;

    const swatchDiv = document.createElement('div');
    swatchDiv.className = 'pigment-swatch';

    const sc = document.createElement('canvas');
    sc.width = 56; sc.height = 56;
    const sctx = sc.getContext('2d');
    const sd = sctx.createImageData(56, 56);
    for (let y = 0; y < 56; y++) {
      for (let x = 0; x < 56; x++) {
        const dx = x - 28, dy = y - 28;
        const d2 = dx*dx + dy*dy;
        const j = (y * 56 + x) * 4;
        if (d2 > 28*28) {
          sd.data[j] = 0; sd.data[j+1] = 0; sd.data[j+2] = 0; sd.data[j+3] = 0;
          continue;
        }
        // Soft pale-yellow with darker speckle around the edge ring.
        // The speckle helps it read as a special/non-pigment tool
        // similar to how Water and Lift have textured appearances.
        const speckle = 0.90 + 0.18 * smoothNoise(x * 0.32, y * 0.32);
        const dist = Math.sqrt(d2);
        const edgeRing = dist > 22 ? (dist - 22) / 6 : 0;  // 0 inner, 1 outer
        // Blend pale yellow (center) → darker amber-yellow (edge)
        const R = (0.96 - edgeRing * 0.10) * speckle;
        const G = (0.90 - edgeRing * 0.14) * speckle;
        const B = (0.55 - edgeRing * 0.22) * speckle;
        sd.data[j]     = Math.min(255, R * 255);
        sd.data[j + 1] = Math.min(255, G * 255);
        sd.data[j + 2] = Math.min(255, B * 255);
        sd.data[j + 3] = 255;
      }
    }
    sctx.putImageData(sd, 0, 0);
    swatchDiv.appendChild(sc);

    const lbl = document.createElement('div');
    lbl.className = 'pigment-label';
    lbl.innerHTML = 'Mask';

    wrap.appendChild(swatchDiv);
    wrap.appendChild(lbl);

    wrap.addEventListener('click', () => {
      currentPigment = MASK_INDEX;
      document.querySelectorAll('.pigment').forEach(el => el.classList.remove('active'));
      wrap.classList.add('active');
      pigmentsRoot.dispatchEvent(new CustomEvent('pigmentchange', { detail: { pigment: currentPigment } }));
    });

    root.appendChild(wrap);
  }

  // v0.97 — Ink swatch. Single-channel near-black pigment that renders
  // as a darkening multiplier on top of K-M, not via K-M math itself.
  // The swatch can't use kmReflect() because ink has no K/S — render
  // it directly as a dark fill instead. Speckle and gradient match
  // the other special swatches for visual consistency.
  //
  // When ink is the active pigment, paintAt routes deposits to the
  // dedicated ink[] channel with its own paint/water load defaults
  // (1.0 / 0.05 respectively — see inkPaintLoad / inkWaterLoad).
  // The global paint/water load sliders in the playground UI still
  // control the K-M pigments; they don't affect ink loads.
  {
    const wrap = document.createElement('div');
    wrap.className = 'pigment' + (currentPigment === INK_INDEX ? ' active' : '');
    wrap.title = 'Ink — crisp near-black marks. High paint load + low water load by default: lays down dark and stays put, only blooms when external wet pigment reaches it. Adjust via inkPaintLoad() / inkWaterLoad().';
    wrap.dataset.idx = INK_INDEX;

    const swatchDiv = document.createElement('div');
    swatchDiv.className = 'pigment-swatch';

    const sc = document.createElement('canvas');
    sc.width = 56; sc.height = 56;
    const sctx = sc.getContext('2d');
    const sd = sctx.createImageData(56, 56);
    for (let y = 0; y < 56; y++) {
      for (let x = 0; x < 56; x++) {
        const dx = x - 28, dy = y - 28;
        const d2 = dx*dx + dy*dy;
        const j = (y * 56 + x) * 4;
        if (d2 > 28*28) {
          sd.data[j] = 0; sd.data[j+1] = 0; sd.data[j+2] = 0; sd.data[j+3] = 0;
          continue;
        }
        // Render the actual ink-on-paper appearance by passing the
        // paper base color through the same darkening multiplier the
        // render loop uses. Speckle + subtle gradient give a wash of
        // varying ink thickness rather than a flat black disc.
        const speckle = 0.92 + 0.12 * smoothNoise(x * 0.3, y * 0.3);
        // Mostly-saturated ink across the swatch, with a slight thinning
        // toward the top — matches the "thicker bottom" feel of K-M
        // swatches and reads as a wet-into-wet stroke rather than print.
        const inkConc = (0.88 + 0.08 * (y / 56)) * speckle;
        const darken = 1 - inkConc * INK_ALPHA;
        const R = PAPER_R_BASE * darken;
        const G = PAPER_G_BASE * darken;
        const B = PAPER_B_BASE * darken;
        sd.data[j]     = Math.min(255, R * 255);
        sd.data[j + 1] = Math.min(255, G * 255);
        sd.data[j + 2] = Math.min(255, B * 255);
        sd.data[j + 3] = 255;
      }
    }
    sctx.putImageData(sd, 0, 0);
    swatchDiv.appendChild(sc);

    const lbl = document.createElement('div');
    lbl.className = 'pigment-label';
    lbl.innerHTML = 'Ink';

    wrap.appendChild(swatchDiv);
    wrap.appendChild(lbl);

    wrap.addEventListener('click', () => {
      currentPigment = INK_INDEX;
      document.querySelectorAll('.pigment').forEach(el => el.classList.remove('active'));
      wrap.classList.add('active');
      pigmentsRoot.dispatchEvent(new CustomEvent('pigmentchange', { detail: { pigment: currentPigment } }));
    });

    root.appendChild(wrap);
  }
}


// ============================================================
// PAPER WETNESS PRESETS (v2 lib addition)
// ============================================================
// Five named presets mapping to evaporation-rate multipliers.
// Default ("wetOnWet") applied at init below.
const EVAP_PRESETS = {
  flooded:   1,    // half-life ~9.5s — pooled water, dramatic blooms
  wetOnWet:  3,    // half-life ~3.2s — soft Curtis-style bleed
  damp:      8,    // half-life ~1.2s — edges firmer, controlled
  dryBrush:  18,   // half-life ~0.5s — granular, paint sits in place
  boneDry:   50,   // half-life ~0.2s — almost dry-on-paper
};
function setEvaporationMult(mult) {
  if (!isFinite(mult) || mult < 0.1) mult = 0.1;
  if (mult > 200) mult = 200;
  evaporationRate = Math.pow(0.9988, mult);
}
function applyEvapPreset(presetName) {
  const mult = EVAP_PRESETS[presetName];
  if (mult === undefined) return false;
  setEvaporationMult(mult);
  return true;
}

// ============================================================
// TEXT PAINTING (v2 lib addition)
// ============================================================
const TEXT_FONT_SIZE = 84;
const TEXT_SAMPLE_STEP = 4;
const TEXT_PAINT_STRENGTH = 0.40;

function paintText(text, opts) {
  if (!text) return 0;
  opts = opts || {};
  const fontSize = opts.fontSize || TEXT_FONT_SIZE;
  const sampleStep = opts.sampleStep || TEXT_SAMPLE_STEP;
  const strength = opts.strength || TEXT_PAINT_STRENGTH;
  const pigment = opts.pigment !== undefined ? opts.pigment : currentPigment;
  const centerGX = opts.x !== undefined ? opts.x : GW * 0.5;
  const centerGY = opts.y !== undefined ? opts.y : GH * 0.5;

  const tmp = document.createElement('canvas');
  const tctx = tmp.getContext('2d');
  const fontSpec = 'bold ' + fontSize + 'px Georgia, serif';
  tctx.font = fontSpec;
  const metrics = tctx.measureText(text);
  const padX = Math.ceil(fontSize * 0.1);
  const padY = Math.ceil(fontSize * 0.1);
  const w = Math.max(1, Math.ceil(metrics.width) + padX * 2);
  const h = Math.ceil(fontSize * 1.4) + padY * 2;
  tmp.width = w;
  tmp.height = h;
  tctx.font = fontSpec;
  tctx.textBaseline = 'middle';
  tctx.fillStyle = '#000';
  tctx.fillText(text, padX, h * 0.5);

  const img = tctx.getImageData(0, 0, w, h).data;
  const rect = canvas.getBoundingClientRect();
  const pxToGridRadius = (GW / rect.width) * 0.5;
  const brushPx = sampleStep * 1.6;

  markCanvasActive();

  const startX = centerGX - w * 0.5;
  const startY = centerGY - h * 0.5;
  let painted = 0;
  for (let py = 0; py < h; py += sampleStep) {
    for (let px = 0; px < w; px += sampleStep) {
      const idx = (py * w + px) * 4;
      if (img[idx + 3] < 128) continue;
      const gx = startX + px;
      const gy = startY + py;
      if (gx < 0 || gx >= GW || gy < 0 || gy >= GH) continue;
      paintAt(gx, gy, brushPx * pxToGridRadius, pigment, strength);
      painted++;
    }
  }
  return painted;
}

// ============================================================
// RASTER IMAGE PAINTING (v0.49)
// ============================================================
// paintImage(source, opts?) — sample pixels from a raster image and
// stamp watercolor paint based on their colors. Each pixel decomposes
// into a rose+yellow+blue mix via the same CMY algorithm as
// approximateColor in traceSVG. Sample spacing scales with brush
// radius (same logic as the SVG outline trace v0.47 fix), so a small
// brush yields many tight samples and a large brush yields few wide
// ones.
//
// source can be:
//   - File / Blob (from <input type="file">)
//   - HTMLImageElement (already loaded or loading)
//   - URL string (e.g. '/path/to/photo.jpg' or data: URL)
//
// Returns Promise<number> resolving to the count of stamps painted.
// Loading is async (Image.onload waits for decode); the actual
// painting is synchronous once the image is decoded — like fillInstant
// for SVG, the whole image appears in one frame rather than animating.
//
// opts (all optional):
//   brushSize:      display pixels — drives sample spacing. Default = active brush.
//   strength:       stamp strength 0..1. Default = active pressure.
//   pigment:        fallback for fully-transparent/skipped pixels (rare). Default = active.
//   alphaThreshold: 0..1, pixels below this skip. Default 0.05.
//   density:        multiplier on sample spacing. <1 = denser (slower, more accurate),
//                   >1 = sparser. Default 1.
//   flipY:          mirror the image vertically. Default false.
//   maxStamps:      hard cap on stamps to prevent runaway sampling on huge images.
//                   Default 20000. Step is auto-adjusted upward to fit.
//
// Notes on color:
//   - White pixels (R=G=B=1) decompose to weights [0,0,0] → no paint.
//     Photo backgrounds that are pure white naturally vanish, leaving
//     the subject. Most photos have off-white backgrounds though, so
//     expect a faint wash anywhere.
//   - Dark pixels (R=G=B=0) decompose to [1,1,1] → all three pigments
//     at max → muddy dark. Photo blacks land as deep watercolor blacks
//     (mixed, not opaque).
//   - Saturated colors decompose intuitively: red → rose+yellow,
//     green → yellow+blue, etc.
//
// Performance: the synchronous stamp pass calls paintAt up to 3× per
// sample (one per non-zero pigment weight). With default settings on
// a 1024×768 photo, that's ~12k samples × ~2 calls = ~24k paintAt
// calls — runs in well under a second. The maxStamps cap prevents
// pathological cases (tiny brush + huge image) from freezing the UI.

function _loadImageSource(source) {
  // v0.49 fix — reject with descriptive Error objects, not raw Event
  // instances. Browsers don't put anything useful on the error event
  // for Image, so the catch site got "[object Event]" which gave the
  // user nothing to act on. Now we construct an Error with the source
  // info we have (File name, MIME type, size) so the message actually
  // points at the problem — typically HEIC / TIFF / RAW formats the
  // browser can't decode, or a corrupted file.
  function describeSource(src) {
    if (typeof src === 'string') {
      return src.length > 80 ? src.slice(0, 77) + '...' : src;
    }
    if (typeof Blob !== 'undefined' && src instanceof Blob) {
      const parts = [];
      if (src.name) parts.push(src.name);
      if (src.type) parts.push(src.type);
      if (typeof src.size === 'number') parts.push(src.size + ' bytes');
      return parts.length ? parts.join(', ') : 'Blob';
    }
    if (typeof HTMLImageElement !== 'undefined' && src instanceof HTMLImageElement) {
      return src.src || 'HTMLImageElement';
    }
    return String(src);
  }

  // Already-loaded image element → reuse directly
  if (typeof HTMLImageElement !== 'undefined' && source instanceof HTMLImageElement) {
    if (source.complete && source.naturalWidth > 0) return Promise.resolve(source);
    return new Promise((resolve, reject) => {
      source.addEventListener('load', () => resolve(source), { once: true });
      source.addEventListener('error', () => {
        reject(new Error('Image load failed: ' + describeSource(source)));
      }, { once: true });
    });
  }
  // File or Blob → object URL + Image
  const isBlob = (typeof Blob !== 'undefined' && source instanceof Blob);
  const isFile = (typeof File !== 'undefined' && source instanceof File);
  if (isBlob || isFile) {
    // If the MIME type is set and clearly not an image, fail fast with
    // a helpful message instead of letting the browser fail silently.
    if (source.type && !source.type.startsWith('image/')) {
      return Promise.reject(new Error(
        'Not an image file: ' + describeSource(source) +
        ' — paintImage accepts JPEG, PNG, WebP, GIF, AVIF (and SVG for browsers that decode it as a raster).'
      ));
    }
    let url;
    try {
      url = URL.createObjectURL(source);
    } catch (e) {
      return Promise.reject(new Error(
        'Failed to create object URL for ' + describeSource(source) + ': ' + e.message
      ));
    }
    const img = new Image();
    return new Promise((resolve, reject) => {
      img.addEventListener('load', () => {
        URL.revokeObjectURL(url);
        if (img.naturalWidth === 0 || img.naturalHeight === 0) {
          reject(new Error(
            'Image decoded with zero dimensions: ' + describeSource(source) +
            ' — file may be corrupted, or the browser cannot decode this format ' +
            '(HEIC / HEIF on some browsers, TIFF, RAW formats, etc.).'
          ));
          return;
        }
        resolve(img);
      }, { once: true });
      img.addEventListener('error', () => {
        URL.revokeObjectURL(url);
        reject(new Error(
          'Image decode failed: ' + describeSource(source) +
          ' — file may be corrupted, or the browser cannot decode this format ' +
          '(common culprits: HEIC / HEIF on some browsers, TIFF, RAW formats).'
        ));
      }, { once: true });
      img.src = url;
    });
  }
  // String → URL or data URL
  if (typeof source === 'string') {
    const img = new Image();
    // crossOrigin so we can read pixels from cross-origin URLs (server
    // must send CORS headers; data: URLs and same-origin always work).
    if (!source.startsWith('data:')) img.crossOrigin = 'anonymous';
    return new Promise((resolve, reject) => {
      img.addEventListener('load', () => {
        if (img.naturalWidth === 0 || img.naturalHeight === 0) {
          reject(new Error('Image decoded with zero dimensions: ' + describeSource(source)));
          return;
        }
        resolve(img);
      }, { once: true });
      img.addEventListener('error', () => {
        // Distinguish CORS failures from network/decode failures by
        // probing fetch — fetch surfaces the real reason where Image
        // collapses everything into a generic error event.
        let hint = '';
        if (!source.startsWith('data:') && source.startsWith('http')) {
          hint = ' (possible causes: network failure, 404, or cross-origin without CORS headers)';
        }
        reject(new Error('Image load failed: ' + describeSource(source) + hint));
      }, { once: true });
      img.src = source;
    });
  }
  return Promise.reject(new Error(
    'paintImage: unsupported source type ' + Object.prototype.toString.call(source) +
    ' — expected File, Blob, HTMLImageElement, or URL string'
  ));
}

function paintImage(source, opts) {
  opts = opts || {};
  return _loadImageSource(source).then((img) => {
    const iw = img.naturalWidth  || img.width;
    const ih = img.naturalHeight || img.height;
    if (!iw || !ih) return 0;

    // Draw into off-screen canvas at native resolution and read pixels
    const off = document.createElement('canvas');
    off.width = iw;
    off.height = ih;
    const ctx = off.getContext('2d', { willReadFrequently: true });
    ctx.drawImage(img, 0, 0);
    let pxData;
    try {
      pxData = ctx.getImageData(0, 0, iw, ih).data;
    } catch (e) {
      // Tainted canvas (cross-origin without CORS). Can't read pixels.
      console.warn('paintImage: cannot read pixels (tainted canvas?)', e);
      return 0;
    }

    // Aspect-fit into the active painting area. With bounds:
    // fit into the supplied rect (grid coords). Without: 70% of
    // canvas, centered (matches SVG_TRACE_FIT default).
    //
    // v0.96 — bounds option. Mirrors traceSVG's bounds support
    // (see line ~6307 / v0.53). Lets the caller place a rasterized
    // image at an arbitrary canvas position, e.g. baking SVG text
    // into a specific card region.
    let fitScale, offsetX, offsetY;
    if (opts.bounds && typeof opts.bounds === 'object') {
      const bw = +opts.bounds.w, bh = +opts.bounds.h;
      const bx = +opts.bounds.x, by = +opts.bounds.y;
      const sbx = bw / iw, sby = bh / ih;
      fitScale = Math.min(sbx, sby);
      const drawnW = iw * fitScale, drawnH = ih * fitScale;
      offsetX = bx + (bw - drawnW) * 0.5;
      offsetY = by + (bh - drawnH) * 0.5;
    } else {
      const fitFraction = SVG_TRACE_FIT;
      fitScale = Math.min((GW * fitFraction) / iw, (GH * fitFraction) / ih);
      const drawW = iw * fitScale;
      const drawH = ih * fitScale;
      offsetX = (GW - drawW) * 0.5;
      offsetY = (GH - drawH) * 0.5;
    }

    // Sample step in image pixels. We want stamps spaced at ~0.85 *
    // brushRadius in GRID cells, then convert that to image-pixel
    // spacing via fitScale (grid_cells_per_image_pixel).
    const brushPx = opts.brushSize !== undefined ? +opts.brushSize : brushSize;
    const brushR = (brushPx / 2) / SCALE;
    const density = opts.density !== undefined ? +opts.density : 1;
    const targetStepGrid = Math.max(0.5, brushR * 0.85 * density);
    let stepPx = Math.max(1, Math.round(targetStepGrid / fitScale));

    // Cap total stamps: if the image+step combo would produce too many,
    // step up the spacing until we're under the cap. Protects against
    // huge images × tiny brushes locking up the UI.
    const maxStamps = opts.maxStamps !== undefined ? +opts.maxStamps : 20000;
    const cols0 = Math.ceil(iw / stepPx);
    const rows0 = Math.ceil(ih / stepPx);
    if (cols0 * rows0 > maxStamps) {
      const ratio = Math.sqrt((cols0 * rows0) / maxStamps);
      stepPx = Math.max(1, Math.round(stepPx * ratio));
    }

    const fallbackPigment = opts.pigment !== undefined
      ? _resolvePigmentOption(opts.pigment)
      : currentPigment;
    const strength = opts.strength !== undefined ? +opts.strength : _brushPressure;
    const alphaThresh = ((opts.alphaThreshold !== undefined ? +opts.alphaThreshold : 0.05) * 255) | 0;
    const flipY = opts.flipY === true;
    const flipX = opts.flipX === true;

    // v0.97 — When opts.pigment is explicitly a special-sentinel
    // pigment (INK/WATER/MASK/PAPER/LIFT — all negative indices),
    // the per-pixel RGB → rose/yellow/blue mix is meaningless. The
    // caller is saying "deposit this image into the ink (or other
    // special) channel, alpha-driven, not color-driven." Force
    // single-pigment dispatch.
    //
    // For K-M pigments (rose/yellow/blue, indices 0/1/2), the mix
    // path still runs by default — preserving backward compatibility
    // for callers who pass an explicit K-M pigment as a fallback hint
    // but expect the SVG colors to do the actual routing. Set
    // opts.forcePigment to bypass the mix path and force every stamp
    // into the chosen pigment.
    const forceSingle =
      (opts.pigment !== undefined && fallbackPigment < 0) ||
      opts.forcePigment === true;

    markCanvasActive();
    const stampState = { brushR: brushR, strength: strength, pigment: fallbackPigment };

    let stamps = 0;
    for (let py = 0; py < ih; py += stepPx) {
      // Center the sample within its block to reduce aliasing
      const sy = Math.min(ih - 1, py + (stepPx >> 1));
      const dyy = flipY ? (ih - 1 - sy) : sy;
      const rowBase = dyy * iw;
      const gy = offsetY + sy * fitScale;
      if (gy < 0 || gy >= GH) continue;
      for (let px = 0; px < iw; px += stepPx) {
        const sx = Math.min(iw - 1, px + (stepPx >> 1));
        const dxx = flipX ? (iw - 1 - sx) : sx;
        const i = (rowBase + dxx) * 4;
        const a = pxData[i + 3];
        if (a < alphaThresh) continue;
        const gx = offsetX + sx * fitScale;
        if (gx < 0 || gx >= GW) continue;
        // Alpha factor lets semi-transparent pixels deposit less paint
        const alphaFactor = a / 255;
        if (forceSingle) {
          // Skip pixels that the SVG renders as paper background. We
          // can't use the rose/yellow/blue weights test here, so use
          // a simple luminance threshold: if the pixel is near-white,
          // it's not part of the glyph fill.
          const r = pxData[i]     / 255;
          const g = pxData[i + 1] / 255;
          const b = pxData[i + 2] / 255;
          const lum = 0.2126 * r + 0.7152 * g + 0.0722 * b;
          if (lum > 0.92) continue;
          // Strength modulated by darkness — darker pixels deposit
          // more (mirrors what the mix-weights path does for color).
          const darkness = 1 - lum;
          _paintSvgPoint(
            { x: gx, y: gy, paint: { type: 'single', pigment: fallbackPigment } },
            { brushR: brushR, strength: strength * alphaFactor * darkness, pigment: fallbackPigment }
          );
        } else {
          const r = pxData[i]     / 255;
          const g = pxData[i + 1] / 255;
          const b = pxData[i + 2] / 255;
          const weights = _rgbToPigmentMix([r, g, b]);
          // Skip pure-white pixels — all weights zero, no paint deposited
          if (weights[0] < 0.005 && weights[1] < 0.005 && weights[2] < 0.005) continue;
          // Reuse the SVG paint helper for consistent multi-stamp dispatch
          _paintSvgPoint(
            { x: gx, y: gy, paint: { type: 'mix', weights: weights } },
            { brushR: brushR, strength: strength * alphaFactor, pigment: fallbackPigment }
          );
        }
        stamps++;
      }
    }
    return stamps;
  });
}


const SVG_TRACE_FIT = 0.70;
const SVG_POINTS_PER_FRAME = 10;
const SVG_SAMPLE_DENSITY_CELLS = 2.0;
const SVG_TRACE_STRENGTH = 0.42;
const SVG_TRACE_BRUSH_PX = 9;

let svgTraceState = null;

function pathStringFromSvgElement(el) {
  const tag = el.tagName.toLowerCase();
  if (tag === 'path') return el.getAttribute('d') || '';
  if (tag === 'line') {
    const x1 = el.getAttribute('x1') || 0, y1 = el.getAttribute('y1') || 0;
    const x2 = el.getAttribute('x2') || 0, y2 = el.getAttribute('y2') || 0;
    return 'M' + x1 + ' ' + y1 + ' L' + x2 + ' ' + y2;
  }
  if (tag === 'polyline' || tag === 'polygon') {
    const pts = (el.getAttribute('points') || '').trim().split(/[\s,]+/).map(Number);
    if (pts.length < 4) return '';
    let d = 'M' + pts[0] + ' ' + pts[1];
    for (let i = 2; i + 1 < pts.length; i += 2) {
      d += ' L' + pts[i] + ' ' + pts[i + 1];
    }
    if (tag === 'polygon') d += ' Z';
    return d;
  }
  if (tag === 'rect') {
    const x = +(el.getAttribute('x') || 0);
    const y = +(el.getAttribute('y') || 0);
    const w = +(el.getAttribute('width')  || 0);
    const h = +(el.getAttribute('height') || 0);
    return 'M' + x + ' ' + y + ' h' + w + ' v' + h + ' h' + (-w) + ' Z';
  }
  if (tag === 'circle') {
    const cx = +(el.getAttribute('cx') || 0);
    const cy = +(el.getAttribute('cy') || 0);
    const r = +(el.getAttribute('r') || 0);
    return 'M' + (cx - r) + ' ' + cy +
      ' a' + r + ',' + r + ' 0 1,0 ' + (2 * r) + ',0' +
      ' a' + r + ',' + r + ' 0 1,0 ' + (-2 * r) + ',0';
  }
  if (tag === 'ellipse') {
    const cx = +(el.getAttribute('cx') || 0);
    const cy = +(el.getAttribute('cy') || 0);
    const rx = +(el.getAttribute('rx') || 0);
    const ry = +(el.getAttribute('ry') || 0);
    return 'M' + (cx - rx) + ' ' + cy +
      ' a' + rx + ',' + ry + ' 0 1,0 ' + (2 * rx) + ',0' +
      ' a' + rx + ',' + ry + ' 0 1,0 ' + (-2 * rx) + ',0';
  }
  return '';
}

// v0.28 — Pigment-name resolution shared between traceSVG, paintText,
// and any other API path that wants to accept a string or numeric
// pigment indicator. Returns a numeric index or throws on unknown
// names. Recognizes the same string set as the pigment() API:
//   'rose', 'yellow', 'blue', 'cerulean' (alias), 'rainbow',
//   'water', 'lift', 'mask'.
function _resolvePigmentOption(p) {
  if (typeof p === 'number') return p | 0;
  if (typeof p !== 'string') return currentPigment;
  const name = p.toLowerCase();
  const named = { water: WATER_INDEX, lift: LIFT_INDEX,
                  rainbow: RAINBOW_INDEX, mask: MASK_INDEX,
                  paper: PAPER_INDEX, ink: INK_INDEX,
                  rose: 0, yellow: 1, blue: 2, cerulean: 2 };
  if (name in named) return named[name];
  throw new Error('Unknown pigment: ' + p);
}

// v0.41 — Map an SVG color string to a pigment index. Standard
// "chroma-key" colors used by SVG authors to declare pigment per
// element / per path; unrecognized colors return null so the caller
// can fall back to opts.pigment or the active brush.
//
//   rose    = #FF0000 (pure red)         → 0
//   yellow  = #FFFF00 (pure yellow)      → 1
//   blue    = #0000FF (pure blue)        → 2
//   mask    = #00FF00 (pure green)       → MASK_INDEX
//   rainbow = #FF00FF (pure magenta)     → RAINBOW_INDEX
//
// v0.43 — Refactored to share parsing with _parseSvgColor (the more
// permissive parser used by the approximation path). Same strict
// match semantics: only the exact pure primaries return a pigment
// index; anything else returns null.
//
// v0.80 — Also recognize the K-M rendered hex values of each pigment
// at typical wash thickness (x=1.0 over white paper). These are the
// colors a designer would copy from the docs to mean "draw this in
// quinacridone rose / hansa yellow / cerulean blue" — natural to
// reach for, but they don't match any chroma-key. Now they do.
//   #A50E53 → quinacridone rose
//   #E3AF08 → hansa yellow
//   #108BA0 → cerulean blue
function _colorToPigment(color) {
  const rgb = _parseSvgColor(color);
  if (rgb === null) return null;
  // Round to 0..255 ints and check for the exact trigger primaries.
  const r = Math.round(rgb[0] * 255);
  const g = Math.round(rgb[1] * 255);
  const b = Math.round(rgb[2] * 255);
  if (r === 255 && g === 0   && b === 0  ) return 0;              // rose (chroma-key)
  if (r === 255 && g === 255 && b === 0  ) return 1;              // yellow (chroma-key)
  if (r === 0   && g === 0   && b === 255) return 2;              // blue (chroma-key)
  if (r === 0   && g === 255 && b === 0  ) return MASK_INDEX;     // mask
  if (r === 255 && g === 0   && b === 255) return RAINBOW_INDEX;  // rainbow
  // v0.80 — pigment-rendered triggers (K-M at x=1.0 over white)
  if (r === 0xA5 && g === 0x0E && b === 0x53) return 0;           // quinacridone rose
  if (r === 0xE3 && g === 0xAF && b === 0x08) return 1;           // hansa yellow
  if (r === 0x10 && g === 0x8B && b === 0xA0) return 2;           // cerulean blue
  return null;
}

// v0.43 — Parse a CSS/SVG color string into [r, g, b] components in
// 0..1, or null if unparseable. Supports:
//   - 3-digit hex:  #F00
//   - 6-digit hex:  #FF0000
//   - rgb(r,g,b):   absolute 0..255 OR percentages
//   - rgba(...):    alpha ignored
//   - named colors: a curated subset covering common usage
// Returns null for 'none', 'transparent', empty, null, or unrecognized.
//
// Named colors omit the trigger set (red/yellow/blue/lime/magenta/
// fuchsia) since those go through _colorToPigment for trigger handling
// first. If approximation reaches here with one of those names, the
// caller should already have intercepted it.
function _parseSvgColor(c) {
  if (!c || typeof c !== 'string') return null;
  let s = c.trim().toLowerCase();
  if (!s || s === 'none' || s === 'transparent' || s === 'currentcolor') {
    return null;
  }
  // 3-digit hex
  let m = s.match(/^#([0-9a-f])([0-9a-f])([0-9a-f])$/);
  if (m) return [
    parseInt(m[1] + m[1], 16) / 255,
    parseInt(m[2] + m[2], 16) / 255,
    parseInt(m[3] + m[3], 16) / 255,
  ];
  // 6-digit hex
  m = s.match(/^#([0-9a-f]{2})([0-9a-f]{2})([0-9a-f]{2})$/);
  if (m) return [
    parseInt(m[1], 16) / 255,
    parseInt(m[2], 16) / 255,
    parseInt(m[3], 16) / 255,
  ];
  // rgb() or rgba() — absolute (0..255) or percentage; alpha ignored.
  // Accepts both comma and whitespace-separated forms.
  m = s.match(/^rgba?\s*\(\s*([\d.]+)\s*(%?)[\s,]+([\d.]+)\s*(%?)[\s,]+([\d.]+)\s*(%?)(?:[\s,]+[\d.]+\s*%?)?\s*\)$/);
  if (m) {
    const parse = (v, isPct) => {
      const n = parseFloat(v);
      if (!isFinite(n)) return null;
      return isPct ? n / 100 : n / 255;
    };
    const r = parse(m[1], m[2] === '%');
    const g = parse(m[3], m[4] === '%');
    const b = parse(m[5], m[6] === '%');
    if (r === null || g === null || b === null) return null;
    return [
      Math.max(0, Math.min(1, r)),
      Math.max(0, Math.min(1, g)),
      Math.max(0, Math.min(1, b)),
    ];
  }
  // Named CSS colors (subset). Useful for SVGs authored in tools that
  // emit names instead of hex. The CSS spec has ~140 names; this is
  // the practical subset for hand-authored watercolor SVGs.
  const named = {
    red:        [1.000, 0.000, 0.000],
    yellow:     [1.000, 1.000, 0.000],
    blue:       [0.000, 0.000, 1.000],
    green:      [0.000, 0.502, 0.000],
    lime:       [0.000, 1.000, 0.000],
    cyan:       [0.000, 1.000, 1.000],
    aqua:       [0.000, 1.000, 1.000],
    magenta:    [1.000, 0.000, 1.000],
    fuchsia:    [1.000, 0.000, 1.000],
    orange:     [1.000, 0.647, 0.000],
    purple:     [0.502, 0.000, 0.502],
    pink:       [1.000, 0.753, 0.796],
    brown:      [0.647, 0.165, 0.165],
    black:      [0.000, 0.000, 0.000],
    white:      [1.000, 1.000, 1.000],
    gray:       [0.502, 0.502, 0.502],
    grey:       [0.502, 0.502, 0.502],
    silver:     [0.753, 0.753, 0.753],
    navy:       [0.000, 0.000, 0.502],
    teal:       [0.000, 0.502, 0.502],
    olive:      [0.502, 0.502, 0.000],
    maroon:     [0.502, 0.000, 0.000],
    indigo:     [0.294, 0.000, 0.510],
    violet:     [0.933, 0.510, 0.933],
    gold:       [1.000, 0.843, 0.000],
    coral:      [1.000, 0.498, 0.314],
    salmon:     [0.980, 0.502, 0.447],
    khaki:      [0.941, 0.902, 0.549],
    turquoise:  [0.251, 0.878, 0.816],
    crimson:    [0.863, 0.078, 0.235],
    skyblue:    [0.529, 0.808, 0.922],
    lightblue:  [0.678, 0.847, 0.902],
    lightgreen: [0.565, 0.933, 0.565],
    darkgreen:  [0.000, 0.392, 0.000],
    darkblue:   [0.000, 0.000, 0.545],
    darkred:    [0.545, 0.000, 0.000],
  };
  if (s in named) return named[s];
  return null;
}

// v0.43 — Decompose an RGB color into proportional weights of the
// three watercolor pigments (rose, yellow, blue). Based on subtractive
// color theory: each pigment absorbs its complementary wavelength.
//   rose ≈ magenta → absorbs green → weight = 1 - g
//   yellow         → absorbs blue  → weight = 1 - b
//   blue ≈ cyan    → absorbs red   → weight = 1 - r
// The result feeds the multi-stamp painter in svgTraceStep, where each
// non-zero weight produces one paintAt call at strength * weight.
// Brighter (closer to white) colors → smaller weights → less pigment.
// Darker colors → larger weights → more pigment (and more wetness).
// Pure white returns all zeros (no paint at all).
function _rgbToPigmentMix(rgb) {
  return [
    Math.max(0, Math.min(1, 1 - rgb[1])),  // rose
    Math.max(0, Math.min(1, 1 - rgb[2])),  // yellow
    Math.max(0, Math.min(1, 1 - rgb[0])),  // blue
  ];
}

// v0.41 — Read a presentation property from an SVG element, checking
// both the direct attribute and the inline style attribute. Direct
// attribute wins (matches SVG's specified precedence: presentation
// attributes are overridden by style, but for the purposes of the
// chroma-key heuristic the simpler rule is fine — most authoring tools
// emit one or the other, not both).
function _getSvgPresentationValue(el, name) {
  const attr = el.getAttribute && el.getAttribute(name);
  if (attr) return attr;
  const style = el.getAttribute && el.getAttribute('style');
  if (style) {
    // Look for `name: value` (or `name:value`) anywhere in the style
    // string, terminating at `;` or end-of-string. Escape the name
    // (which is always 'fill' or 'stroke' here — no regex chars).
    const m = style.match(new RegExp('(?:^|;)\\s*' + name + '\\s*:\\s*([^;]+)'));
    if (m) return m[1].trim();
  }
  return null;
}

// v0.45 — Convert a single CSS color string into a paint descriptor.
// Returns one of:
//   { type: 'single', pigment: idx }       — exact trigger primary
//   { type: 'mix',    weights: [r, y, b] } — CMY decomposition
//   null                                   — not parseable or unwanted
function _resolveColorToPaint(colorStr, triggerColors, approximateColor) {
  if (!colorStr || colorStr === 'none' || colorStr === 'transparent') {
    return null;
  }
  if (triggerColors) {
    const pig = _colorToPigment(colorStr);
    if (pig !== null) return { type: 'single', pigment: pig };
  }
  if (approximateColor) {
    const rgb = _parseSvgColor(colorStr);
    if (rgb !== null) return { type: 'mix', weights: _rgbToPigmentMix(rgb) };
  }
  return null;
}

// v0.41 / v0.43 / v0.45 / v0.48 — Walk up the SVG DOM tree collecting
// both stroke and fill paint descriptors. Returns:
//   { stroke, fill, strokeBlocked, fillBlocked, strokeSeen, fillSeen }
// Each paint is a descriptor or null. The four boolean flags describe
// what we observed on the way up:
//   strokeBlocked / fillBlocked — found an explicit 'none' or
//                                 'transparent' value, which (per the
//                                 SVG cascade) stops further inheritance
//                                 AND tells us the author wanted no
//                                 paint of that kind. Different from a
//                                 missing attribute.
//   strokeSeen / fillSeen        — found a non-none value somewhere on
//                                 the way up. Set whether or not the
//                                 color resolved to a recognized paint.
//                                 Used by the caller to route the
//                                 fallback brush to the right slot.
function _resolveSvgPaints(el, svgRoot, triggerColors, approximateColor) {
  let strokePaint = null, fillPaint = null;
  let strokeBlocked = false, fillBlocked = false;
  let strokeSeen = false, fillSeen = false;
  let cur = el;
  for (let depth = 0; cur && cur !== svgRoot && depth < 32; depth++) {
    // STROKE: walk up only while neither seen nor blocked at a child
    if (!strokeSeen && !strokeBlocked) {
      const v = _getSvgPresentationValue(cur, 'stroke');
      if (v === 'none' || v === 'transparent') {
        strokeBlocked = true;
      } else if (v) {
        strokeSeen = true;
        strokePaint = _resolveColorToPaint(v, triggerColors, approximateColor);
      }
    }
    if (!fillSeen && !fillBlocked) {
      const v = _getSvgPresentationValue(cur, 'fill');
      if (v === 'none' || v === 'transparent') {
        fillBlocked = true;
      } else if (v) {
        fillSeen = true;
        fillPaint = _resolveColorToPaint(v, triggerColors, approximateColor);
      }
    }
    if ((strokeSeen || strokeBlocked) && (fillSeen || fillBlocked)) break;
    cur = cur.parentNode;
  }
  return {
    stroke: strokePaint, fill: fillPaint,
    strokeBlocked, fillBlocked,
    strokeSeen, fillSeen,
  };
}

// v0.28 — SVG trace now uses the active brush instead of hardcoded
// SVG_TRACE_BRUSH_PX / SVG_TRACE_STRENGTH. Optional opts override per-
// call: { pigment, brushSize, strength, flipY, flipX, ... }.
//
// v0.42 — flipY default flipped to FALSE. Standard SVG sources
// (Illustrator, Inkscape, Figma, web exports) and Canvas / CSS all
// use Y-down — no flip is needed and the trace appears correctly.
// The v0.28..v0.41 default of TRUE was a misreading and made standard
// SVGs render upside-down. Pass flipY: true explicitly for genuinely
// Y-up sources (rare). flipX added in v0.42 for the analogous case
// where an SVG needs horizontal mirroring.
function loadSVGAndTrace(svgText, opts) {
  opts = opts || {};
  // v0.90 — `animate: false` is the canonical user-facing flag for
  // "draw the SVG instantly, no animation." Map to the older internal
  // `instant: true` for backward compatibility with code that sets
  // either. If both are set explicitly, the more-restrictive wins
  // (animate:false beats instant:false; instant:true beats animate:true).
  if (opts.animate === false) opts.instant = true;
  const parser = new DOMParser();
  const doc = parser.parseFromString(svgText, 'image/svg+xml');
  const svg = doc.querySelector('svg');
  if (!svg) throw new Error('No <svg> root found');

  let viewBox = svg.getAttribute('viewBox');
  let vbX = 0, vbY = 0, vbW = +(svg.getAttribute('width') || 100), vbH = +(svg.getAttribute('height') || 100);
  if (viewBox) {
    const parts = viewBox.trim().split(/[\s,]+/).map(Number);
    if (parts.length === 4) { vbX = parts[0]; vbY = parts[1]; vbW = parts[2]; vbH = parts[3]; }
  }

  const svgNS = 'http://www.w3.org/2000/svg';
  const tmpSvg = document.createElementNS(svgNS, 'svg');
  document.body.appendChild(tmpSvg);

  const allPoints = [];
  // v0.41 / v0.43 — Per-point paint descriptor, parallel to allPoints.
  // Each entry is either { type:'single', pigment: idx } or
  // { type:'mix', weights: [r,y,b] }. Resolved per geometry element
  // from the SVG's fill/stroke attributes; falls back to the call's
  // opts.pigment (or currentPigment) for elements with no recognized
  // color.
  const allPaints = [];
  // v0.31 — pathStartsRaw[i] = index in allPoints where the i-th
  // SVG path's samples begin. Used downstream for the 'penStroke'
  // easing + perStrokePauseMs behavior (pauses at path boundaries).
  const pathStartsRaw = [0];
  // v0.41 / v0.43 — Resolve the trace-call's fallback pigment up-front
  // so we can resolve per-element paints against it. opts.pigment is
  // the "default if the SVG doesn't say otherwise."
  const fallbackPigment = opts.pigment !== undefined
    ? _resolvePigmentOption(opts.pigment)
    : currentPigment;
  // v0.43 — Two color-resolution options. Backwards compat: `colorMap`
  // from v0.41 is accepted as an alias for `triggerColors`.
  //   triggerColors (default true):   recognize the five chroma-key
  //                                   colors (#FF0000 etc.) and route
  //                                   the element to the matching
  //                                   pigment / sentinel.
  //   approximateColor (default false): parse any color and decompose
  //                                   into a rose+yellow+blue mix via
  //                                   subtractive color theory.
  // Both can be on simultaneously — triggers win for exact matches,
  // approximation handles the rest.
  const triggerColors = opts.triggerColors !== undefined
    ? !!opts.triggerColors
    : (opts.colorMap !== undefined ? !!opts.colorMap : true);
  const approximateColor = opts.approximateColor === true;

  // v0.45 — Hoist scale + offsets BEFORE the loop. Previously these
  // were computed AFTER, but the fill-stamp path needs them during
  // element iteration to convert SVG-coordinate sample spacing into
  // a grid-radius-relative density.
  //
  // v0.53 — Optional bounds override. opts.bounds = { x, y, w, h } in
  // GRID coordinates lets the caller place the SVG inside an arbitrary
  // rect on the canvas instead of the default 70% centered fit. The
  // SVG still aspect-fits within the rect; if the rect aspect doesn't
  // match the SVG aspect, the smaller dimension is the constraint and
  // the SVG is centered within the rect.
  let sFit, offsetX_pre, offsetY_pre;
  if (opts.bounds && typeof opts.bounds === 'object') {
    const bw = +opts.bounds.w, bh = +opts.bounds.h;
    const bx = +opts.bounds.x, by = +opts.bounds.y;
    const sbx = bw / vbW, sby = bh / vbH;
    sFit = Math.min(sbx, sby);
    const drawnW = vbW * sFit, drawnH = vbH * sFit;
    offsetX_pre = bx + (bw - drawnW) * 0.5;
    offsetY_pre = by + (bh - drawnH) * 0.5;
  } else {
    const sx = (GW * SVG_TRACE_FIT) / vbW;
    const sy = (GH * SVG_TRACE_FIT) / vbH;
    sFit = Math.min(sx, sy);
    offsetX_pre = GW * 0.5 - (vbW * sFit) * 0.5;
    offsetY_pre = GH * 0.5 - (vbH * sFit) * 0.5;
  }

  // v0.45 — Pre-resolve brush radius (in grid cells) so fill sampling
  // can space its stamps relative to it. Outline-tracing uses the same
  // radius downstream.
  const brushPx = opts.brushSize !== undefined ? +opts.brushSize : brushSize;
  const brushR_pre = (brushPx / 2) / SCALE;

  // v0.45 — Fill-shapes mode. When ON (default), elements with a
  // non-trivial fill get their INTERIOR stamped — sample points in a
  // regular grid over the bounding box, keep the ones inside the path,
  // and paintAt each with the fill paint. Combines naturally with the
  // outline-tracing path: a shape with both stroke and fill traces its
  // outline AND stamps its interior. Pure-stroke shapes only outline.
  // Pure-fill shapes only stamp.
  const fillShapes = opts.fillShapes !== false;
  // v0.46 — fillInstant. When TRUE (default), all fill stamps paint
  // SYNCHRONOUSLY during loadSVGAndTrace, before the trace animation
  // even starts. Only outline samples go into the animated queue. The
  // visual effect: filled regions appear as washes (the wet brush is
  // "stamped on all at once"), while outlines reveal animatedly over
  // the duration. This matches watercolor practice — lay down a wash,
  // then ink the details. Set FALSE to make fills animate point-by-
  // point through the same grid as outlines (the v0.45 behavior — read
  // as a sweep across the shape rather than a wash appearing).
  const fillInstant = opts.fillInstant !== false;
  // Fill-stamp spacing in SVG units, derived from brush radius in grid
  // units. The factor (0.85) controls overlap: 1.0 = stamps just touch,
  // <1.0 = stamps overlap (denser coverage), >1.0 = gaps between stamps
  // (dappled). 0.85 is a tight but not redundant default.
  const fillSpacingSvg = sFit > 0 ? (brushR_pre * 0.85) / sFit : 0;

  // v0.46 — Hoist flip/strength reads BEFORE the loop. The fillInstant
  // path paints synchronously during the loop and needs the final
  // grid coordinates (post-scale + post-flip) to call paintAt with.
  const flipY = opts.flipY !== undefined ? !!opts.flipY : false;
  const flipX = opts.flipX !== undefined ? !!opts.flipX : false;
  const strengthForTrace = opts.strength !== undefined ? +opts.strength : _brushPressure;

  // v0.47 — Outline stamp spacing now scales with brush radius. With a
  // small brush, fixed 2-cell sample spacing left visible gaps between
  // stamps — strokes read as dotted lines rather than continuous marks.
  // The fix is two-step: (a) scale the per-element initial sample rate
  // along each path so we generate enough source samples, and (b) scale
  // the downsample threshold so we keep them at brush-relative density.
  //
  // Target spacing = 0.5 * brush radius (grid cells) → ~50% overlap
  // between consecutive stamps. Floor at 0.5 cells so a 1-pixel brush
  // doesn't try to sample at sub-cell precision.
  const outlineSpacingCells = Math.max(0.5, brushR_pre * 0.5);
  const outlineSpacingCellsSq = outlineSpacingCells * outlineSpacingCells;
  // Initial sample step along each path, in SVG units. Sample at half
  // the desired final density for a safety margin (downsampling will
  // thin to the target rate).
  const outlineSampleStepSvg = sFit > 0
    ? Math.max(0.05, (outlineSpacingCells * 0.5) / sFit)
    : 1.0;

  const geomEls = svg.querySelectorAll('path,line,polyline,polygon,rect,circle,ellipse');
  for (const el of geomEls) {
    const d = pathStringFromSvgElement(el);
    if (!d) continue;
    const p = document.createElementNS(svgNS, 'path');
    p.setAttribute('d', d);
    tmpSvg.appendChild(p);
    let len = 0;
    try { len = p.getTotalLength(); } catch (e) { tmpSvg.removeChild(p); continue; }
    if (!isFinite(len) || len <= 0) { tmpSvg.removeChild(p); continue; }

    // v0.45 / v0.48 — Resolve stroke and fill paints independently.
    // The resolver always runs (even with both color flags off) so we
    // can detect attribute *presence* — see fallback block below.
    let strokePaint = null, fillPaint = null;
    const paints = _resolveSvgPaints(el, svg, triggerColors, approximateColor);
    strokePaint = paints.stroke;
    fillPaint   = paints.fill;

    // v0.48 — Fallback routing now respects which attribute the SVG
    // author actually wrote. The original rule (v0.41–v0.47) always
    // routed the fallback to the OUTLINE slot, which produced wrong
    // results for shapes whose fill happened not to resolve — an
    // unrecognized hex like #222222 (with approximateColor off) would
    // get OUTLINED in the active brush when the author clearly wanted
    // it FILLED. New rules:
    //   - If a fill attribute was seen (recognized or not), the shape
    //     should be FILLED. With the fill paint if it resolved; with
    //     the active brush otherwise.
    //   - Same for stroke.
    //   - If both attributes were seen, both happen (fill stamps +
    //     outline trace), each getting its own fallback as needed.
    //   - Only when NEITHER attribute is seen ANYWHERE on the way up
    //     (truly unstyled element) does the fallback brush trace the
    //     outline — matching the "trace this SVG in my active brush"
    //     contract from before per-attribute resolution existed.
    //   - Explicit 'none' or 'transparent' (fillBlocked / strokeBlocked)
    //     suppresses the corresponding paint entirely. fill="none"
    //     stroke="none" produces nothing — author asked for nothing.
    if (paints.fillSeen && !fillPaint) {
      fillPaint = { type: 'single', pigment: fallbackPigment };
    }
    if (paints.strokeSeen && !strokePaint) {
      strokePaint = { type: 'single', pigment: fallbackPigment };
    }
    if (!paints.fillSeen && !paints.fillBlocked &&
        !paints.strokeSeen && !paints.strokeBlocked) {
      // Truly unstyled — trace outline in active brush
      strokePaint = { type: 'single', pigment: fallbackPigment };
    }

    // v0.45 — When fillShapes is off but the element has a fill, route
    // that fill to the OUTLINE so the shape still gets painted. This
    // preserves the v0.44 behavior ("filled SVGs trace their outline
    // in the fill color") for users who opt out of fill stamping.
    if (!fillShapes && !strokePaint && fillPaint) {
      strokePaint = fillPaint;
      fillPaint = null;
    }

    // v0.45 — FILL STAMPING. For elements with a recognized fill, sample
    // a regular grid over the path's bounding box, keep points inside
    // the fill, and add them to the points list with the fill paint.
    // Fill stamps come BEFORE outline strokes in the array, so when
    // both are present, the outline appears on top of the fill (which
    // is the natural watercolor "wash then ink the edge" order).
    if (fillShapes && fillPaint && fillSpacingSvg > 0) {
      let bbox = null;
      try { bbox = p.getBBox(); } catch (e) { bbox = null; }
      if (bbox && bbox.width > 0 && bbox.height > 0) {
        // Hard cap on samples per shape — protects against pathological
        // SVGs with huge viewBoxes and tiny brush radius that would
        // try to stamp millions of points. 10000 stamps is plenty for
        // any reasonable fill.
        const xCount = Math.ceil(bbox.width / fillSpacingSvg);
        const yCount = Math.ceil(bbox.height / fillSpacingSvg);
        const tooMany = xCount * yCount > 10000;
        if (!tooMany) {
          // v0.46 — Build the per-element fill-paint state used by
          // _paintSvgPoint when fillInstant is on. The synchronous path
          // calls paintAt directly with scaled coordinates and the
          // pre-resolved brush radius / strength.
          const instantState = fillInstant
            ? { brushR: brushR_pre, strength: strengthForTrace, pigment: fallbackPigment }
            : null;
          for (let yy = bbox.y; yy <= bbox.y + bbox.height; yy += fillSpacingSvg) {
            for (let xx = bbox.x; xx <= bbox.x + bbox.width; xx += fillSpacingSvg) {
              let inside = false;
              try {
                // Modern API: pass a DOMPointInit { x, y }
                inside = p.isPointInFill({ x: xx, y: yy });
              } catch (e) {
                // Older browsers want an SVGPoint
                try {
                  const root = tmpSvg.ownerSVGElement || tmpSvg;
                  if (root.createSVGPoint) {
                    const pt = root.createSVGPoint();
                    pt.x = xx; pt.y = yy;
                    inside = p.isPointInFill(pt);
                  }
                } catch (e2) { /* give up, skip this point */ }
              }
              if (!inside) continue;
              if (fillInstant) {
                // v0.46 — Stamp synchronously at scaled grid coords.
                // The shape appears as one wash, not as a swept-through
                // grid of points across the animation duration.
                const gx = offsetX_pre + (flipX ? (vbW - (xx - vbX)) : (xx - vbX)) * sFit;
                const gy = offsetY_pre + (flipY ? (vbH - (yy - vbY)) : (yy - vbY)) * sFit;
                _paintSvgPoint({ x: gx, y: gy, paint: fillPaint }, instantState);
              } else {
                // Animated mode (the v0.45 behavior): queue the points
                // for the trace step to paint over time.
                allPoints.push({ x: xx, y: yy });
                allPaints.push(fillPaint);
              }
            }
          }
          // Mark end of the fill segment as a path boundary so per-
          // stroke pauses work correctly across the fill/outline split.
          // Only meaningful when fillInstant is OFF (otherwise the fill
          // points are already painted and don't need an animation
          // boundary).
          if (!fillInstant && allPoints.length > (pathStartsRaw[pathStartsRaw.length - 1] || 0)) {
            pathStartsRaw.push(allPoints.length);
          }
        }
      }
    }

    // OUTLINE TRACING (the original behavior). Skip if there's no
    // stroke paint AND a fill was already stamped — outlining an
    // already-stamped shape in some non-recognized stroke color would
    // be confusing. The fallback-pigment route above ensures
    // strokePaint is set when neither stroke nor fill is resolved.
    if (strokePaint) {
      // v0.47 — Sample step scales with brush radius. A 10000-point
      // hard cap protects against very long paths × tiny brushes from
      // generating millions of source samples.
      const samples = Math.min(10000, Math.max(2, Math.ceil(len / outlineSampleStepSvg)));
      for (let s = 0; s <= samples; s++) {
        const pt = p.getPointAtLength((s / samples) * len);
        allPoints.push({ x: pt.x, y: pt.y });
        allPaints.push(strokePaint);
      }
      pathStartsRaw.push(allPoints.length);
    }

    tmpSvg.removeChild(p);
  }
  document.body.removeChild(tmpSvg);
  if (allPoints.length === 0) return 0;

  // v0.45 — Scale + offsets were hoisted before the geomEls loop (the
  // fill-stamp path needs them). Alias to the local names used below.
  const s = sFit;
  const offsetX = offsetX_pre;
  const offsetY = offsetY_pre;

  // v0.42 — flipY default is now FALSE. Standard SVG (Illustrator,
  // Inkscape, Figma, web design exports) uses Y-down — same as Canvas,
  // same as CSS — so no flip should be needed and the trace should
  // come out right-side-up. The previous v0.28..v0.41 default of TRUE
  // was based on a misreading of the SVG spec and made standard
  // Y-down SVGs render upside-down. Pass `flipY: true` explicitly if
  // you have a genuinely Y-up SVG source (rare — old CAD exports,
  // plot-style diagrams drawn in Cartesian convention).
  //
  // v0.42 also adds `flipX` (default false) for SVGs that need
  // horizontal mirroring — typically a content issue (parent group
  // has transform="scale(-1,1)" that isn't being applied during
  // pathStringFromSvgElement), but exposing the option here gives a
  // straightforward fix without needing to edit the SVG.
  // v0.46 — flipX/flipY were hoisted above the geomEls loop (the
  // fillInstant path needs them during iteration). Just use the
  // hoisted bindings.
  const scaledPoints = allPoints.map((pt, i) => ({
    x: offsetX + (flipX ? (vbW - (pt.x - vbX)) : (pt.x - vbX)) * s,
    y: offsetY + (flipY ? (vbH - (pt.y - vbY)) : (pt.y - vbY)) * s,
    paint: allPaints[i],
  }));

  // Down-sample to roughly one point per outlineSpacingCells grid
  // cells (v0.47 — was a fixed SVG_SAMPLE_DENSITY_CELLS constant; now
  // scales with brush radius so small brushes get tight stamps and big
  // brushes don't oversample). We also remap path-start indices
  // through the downsample so pauses still land on real path
  // boundaries.
  const downSampled = [];
  const pathStarts = [0];
  let nextRawBoundary = pathStartsRaw.length > 1 ? pathStartsRaw[1] : -1;
  let nextBoundaryIdx = 1;
  let lastX = -1e9, lastY = -1e9;
  for (let i = 0; i < scaledPoints.length; i++) {
    const pt = scaledPoints[i];
    const dx = pt.x - lastX, dy = pt.y - lastY;
    if (dx * dx + dy * dy >= outlineSpacingCellsSq) {
      downSampled.push(pt);
      lastX = pt.x; lastY = pt.y;
    }
    // Remap path boundary: when we cross the next raw boundary, mark
    // the current downsampled position as the start of the next path.
    while (nextRawBoundary >= 0 && i + 1 >= nextRawBoundary) {
      pathStarts.push(downSampled.length);
      nextBoundaryIdx++;
      nextRawBoundary = nextBoundaryIdx < pathStartsRaw.length
                        ? pathStartsRaw[nextBoundaryIdx] : -1;
    }
  }

  // v0.28 — Use the active brush instead of hardcoded constants.
  // Resolve pigment by name if a string was supplied (e.g. 'rose'),
  // otherwise default to the currently-active pigment. Same for size,
  // strength — fall through to live state if not specified.
  // v0.41 — The "pigment" stored in svgTraceState is now just the
  // fallback used if a point doesn't carry its own pig. Per-point
  // pigments override.
  // v0.45 — brushPx and brushR were hoisted above the geomEls loop
  // (fill stamping needs them). Just alias.
  // v0.46 — strength was also hoisted (fillInstant needs it during the
  // loop). Just alias.
  const pigment = fallbackPigment;
  const strength = strengthForTrace;
  const brushR = brushR_pre;

  // v0.30 — Trace speed control. Three modes:
  //   instant: true      → paint every point in one frame (synchronous,
  //                        no animation). For thumbnails on page load.
  //   durationMs: <ms>   → spread the trace over roughly that many ms.
  //                        Uses the easing function for shape.
  //   (neither)          → default ~10 points/frame, original behavior.
  //
  // v0.31 — easing. When durationMs is set, the trace honors an
  // easing curve mapping elapsed-time-fraction to point-fraction. See
  // _applyEasing below for the available curves.
  const totalPts = downSampled.length;
  let ppf = SVG_POINTS_PER_FRAME;
  if (opts.instant) {
    ppf = totalPts;
  } else if (typeof opts.durationMs === 'number' && opts.durationMs > 0) {
    const framesAvailable = Math.max(1, Math.ceil(opts.durationMs / (1000 / 60)));
    ppf = Math.max(1, Math.ceil(totalPts / framesAvailable));
  }

  svgTraceState = {
    points: downSampled,
    pathStarts: pathStarts,
    idx: 0,
    pigment: pigment,
    brushR: brushR,
    strength: strength,
    pointsPerFrame: ppf,
    // v0.31 — time-based easing fields. When durationMs is set, the
    // step function ignores pointsPerFrame and computes targetIdx
    // from elapsed time + easing.
    startTime: (typeof performance !== 'undefined' ? performance.now() : Date.now()),
    durationMs: opts.durationMs,
    easing: opts.easing || 'linear',
    perStrokePauseMs: typeof opts.perStrokePauseMs === 'number'
                      ? opts.perStrokePauseMs : 0,
  };
  markCanvasActive();

  // v0.90 — `animate: false` is the user-facing alias for the
  // pre-existing `instant: true` flag. Both mean: paint every point
  // synchronously in one frame, no animation. Internally we use the
  // `instant` boolean since it's the older name and is referenced in
  // a few other places; opts.animate === false is normalized to
  // opts.instant = true above (before this point).
  //
  // BUG FIX (v0.90): the original instant loop just called
  // svgTraceStep() until idx reached total. But if the caller ALSO
  // passed durationMs, svgTraceStep would take the time-based branch
  // which compares elapsed-ms against durationMs — in a synchronous
  // loop, zero ms elapses, so targetIdx stays 0 and the loop hangs.
  // We work around by clearing st.durationMs for the synchronous
  // run, forcing the older per-frame chunk path which advances idx
  // unconditionally. The user-facing durationMs becomes a no-op for
  // animate:false, which matches the semantic — there's no animation
  // to spread over time.
  if (opts.instant) {
    if (svgTraceState) svgTraceState.durationMs = 0;
    let safetyIterations = 0;
    const maxIterations = svgTraceState ? svgTraceState.points.length + 10 : 0;
    while (svgTraceState &&
           svgTraceState.idx < svgTraceState.points.length &&
           safetyIterations < maxIterations) {
      svgTraceStep();
      safetyIterations++;
    }
    // svgTraceStep nulls svgTraceState when idx reaches total; if
    // for any reason it didn't, null it explicitly so subsequent
    // calls aren't confused by stale state.
    svgTraceState = null;
  }

  return totalPts;
}

// v0.31 — Easing curves. Map an "elapsed fraction" (0..1) to a "drawn
// fraction" (0..1). All return 0 at 0 and 1 at 1. Names match common
// CSS / animation libraries so values feel familiar.
function _applyEasing(t, name) {
  if (t <= 0) return 0;
  if (t >= 1) return 1;
  switch (name) {
    case 'linear':     return t;
    case 'easeIn':     return t * t;
    case 'easeOut':    return 1 - (1 - t) * (1 - t);
    case 'easeInOut':  return t < 0.5
                              ? 2 * t * t
                              : 1 - 2 * (1 - t) * (1 - t);
    // 'penStroke' — meant to mimic a human drawing: a brief hesitation
    // at the start (acceleration), steady drawing speed in the middle,
    // brief slowdown at end of stroke. Pairs naturally with
    // perStrokePauseMs > 0 for per-path pauses.
    case 'penStroke':  return t < 0.15 ? (t / 0.15) * 0.10
                              : t > 0.85 ? 0.90 + ((t - 0.85) / 0.15) * 0.10
                              : 0.10 + ((t - 0.15) / 0.70) * 0.80;
    default:           return t;   // unknown name → linear
  }
}

function svgTraceStep() {
  if (!svgTraceState) return;
  const st = svgTraceState;
  const total = st.points.length;

  // v0.31 — time-based path when durationMs is set. Otherwise fall
  // through to the original per-frame chunk behavior.
  if (st.durationMs && st.durationMs > 0) {
    const now = (typeof performance !== 'undefined' ? performance.now() : Date.now());
    const elapsed = now - st.startTime;

    // Per-stroke pauses: subtract total pause-time-already-spent from
    // the effective elapsed timer so the easing curve maps onto active
    // drawing time only. pauseDebt is the cumulative pause time that
    // should have happened by the user's current point progress.
    let pauseDebt = 0;
    if (st.perStrokePauseMs > 0 && st.pathStarts && st.pathStarts.length > 1) {
      // Count how many path-boundaries we've crossed.
      let crossings = 0;
      for (let i = 1; i < st.pathStarts.length; i++) {
        if (st.idx >= st.pathStarts[i]) crossings++;
      }
      pauseDebt = crossings * st.perStrokePauseMs;
    }
    const effElapsed = Math.max(0, elapsed - pauseDebt);
    const t = Math.min(1, effElapsed / st.durationMs);
    const easedT = _applyEasing(t, st.easing);
    const targetIdx = Math.min(total, Math.floor(easedT * total));

    // Paint from current idx forward to the target. Cap per-frame at
    // a reasonable upper bound so a long pause-then-resume doesn't
    // dump hundreds of points in one frame and spike CPU; the next
    // frame catches up if needed.
    const cap = Math.max(SVG_POINTS_PER_FRAME, Math.ceil(total / 20));
    let painted = 0;
    while (st.idx < targetIdx && painted < cap) {
      // Check if we just crossed a stroke boundary — if pauses are
      // enabled, pause here until pauseDebt allows resuming.
      if (st.perStrokePauseMs > 0 && st.pathStarts && st.idx > 0) {
        const justCrossed = st.pathStarts.indexOf(st.idx) > 0;
        if (justCrossed && elapsed < pauseDebt + st.perStrokePauseMs) {
          break;
        }
      }
      const pt = st.points[st.idx];
      // v0.41 / v0.43 — per-point paint descriptor. Single pigment →
      // one paintAt call. Mix → one paintAt per non-zero weight, each
      // at strength scaled by the weight.
      _paintSvgPoint(pt, st);
      st.idx++;
      painted++;
    }
    if (t >= 1 && st.idx >= total) svgTraceState = null;
    return;
  }

  // Original behavior — fixed points per frame.
  const limit = st.pointsPerFrame || SVG_POINTS_PER_FRAME;
  for (let i = 0; i < limit && st.idx < total; i++, st.idx++) {
    const pt = st.points[st.idx];
    _paintSvgPoint(pt, st);
  }
  if (st.idx >= total) svgTraceState = null;
}

function cancelSVGTrace() { svgTraceState = null; }

// v0.43 — Per-point dispatch. Single-pigment paint → one paintAt call.
// Mix paint → one paintAt per non-zero weight, each at strength scaled
// by the weight. The simulation's KM compositor then renders the
// combined deposited pigment as the approximated color naturally.
//
// Wetness consequence: a mix-paint point can fire 2-3 paintAt calls
// at the same (x, y), which is 2-3× the wetness of a single-pigment
// stamp. That extra wetness causes more bleed for mid-saturation and
// dark colors. This is actually accurate to real watercolor — mixing
// two pigments physically does deposit more wet paint than using one.
// If it's too much for a given use case, scale down brush strength
// or waterLoad before calling traceSVG.
function _paintSvgPoint(pt, st) {
  const paint = pt.paint;
  if (!paint) {
    // Defensive fallback for points missing a paint descriptor
    paintAt(pt.x, pt.y, st.brushR, st.pigment, st.strength);
    return;
  }
  if (paint.type === 'single') {
    paintAt(pt.x, pt.y, st.brushR, paint.pigment, st.strength);
    return;
  }
  // type === 'mix' — three weights for rose/yellow/blue
  const w = paint.weights;
  // Pigment indices 0/1/2 match the order of weights[r, y, b]
  if (w[0] > 0.005) paintAt(pt.x, pt.y, st.brushR, 0, st.strength * w[0]);
  if (w[1] > 0.005) paintAt(pt.x, pt.y, st.brushR, 1, st.strength * w[1]);
  if (w[2] > 0.005) paintAt(pt.x, pt.y, st.brushR, 2, st.strength * w[2]);
}

// Apply the default paper-wetness preset matching the v0.26.2 default.
applyEvapPreset('wetOnWet');


// ============================================================
// PER-INSTANCE INIT (replaces module-level init in original)
// ============================================================
// In standalone mode the original calls generatePaper() + initialState()
// at top-level. In library mode we do it here after all functions are
// defined but before the loop starts.

generatePaper();
// Re-initialize the canvas dimensions now that the target element's
// bounding rect is known. The sim arrays were sized based on
// instanceWindow.innerWidth/Height at top-of-file, so this is mostly
// to set canvas pixel dimensions.
// (canvas + ctx are already initialized earlier in the render block.)

// Initial wet paper (no splotches — empty canvas, like in the
// original after a Reset).
for (let i = 0; i < N; i++) {
  wet[i] = 0.62;
}
markCanvasActive();
setActiveRectFull();
render(true);


// ============================================================
// POINTER PAINTING (v2) — mouse + touch input
// v0.28 — adds mobile mode + palm rejection
// ============================================================
// Pointer events unify mouse + touch + pen on modern browsers. The
// per-frame applyPendingPaint() handles interpolation, so fast drags
// (whether mouse or finger) produce continuous strokes via stamped
// midpoints rather than dotted lines.
//
// v0.28 — mobile mode. Auto-detected from `(pointer: coarse)` media
// query but the caller can override via options.mobile, and the host
// UI can toggle at runtime via inst.mobile(true|false). When mobile
// mode is on, three palm-rejection heuristics filter accidental
// contact:
//   1. CONTACT SIZE — palms produce wide PointerEvent.width/height.
//      Touches with width or height > PALM_CONTACT_PX are dropped.
//   2. PEN LOCKOUT — once a pen-type pointer is active, any concurrent
//      touch-type events are palm. Standard iPad-with-Apple-Pencil
//      pattern: the palm rests while you draw.
//   3. FIRST-TOUCH-WINS — once painting starts on pointerId X, ignore
//      additional touches until the active one ends. Filters
//      multi-touch palm landings.
// In mouse / non-mobile mode, none of these gates apply: pointer
// events fall through as before.

// Detection: matchMedia('(pointer: coarse)') is the standard signal
// for touch-primary devices. Available in all modern browsers.
function _detectMobile() {
  if (typeof window === 'undefined' || !window.matchMedia) return false;
  try {
    return window.matchMedia('(pointer: coarse)').matches;
  } catch (_) {
    // Fallback for environments without matchMedia
    return ('ontouchstart' in window) || (navigator.maxTouchPoints > 0);
  }
}

const _mobileDetected = _detectMobile();
let _mobileMode = options.mobile !== undefined ? !!options.mobile : _mobileDetected;
// v0.34 — cursor preview flag. The lib doesn't render the cursor itself
// (the host wiring manages its own DOM element), but the lib owns the
// "should this exist?" boolean so it can be set via create-options and
// flipped at runtime via api.cursorPreview(v). The wiring listens for
// the 'cursorpreviewchange' CustomEvent on targetEl to enable/disable
// its cursor element. Default: ON when not a touch-primary device,
// OFF on mobile (where the user's finger already shows brush position).
let _cursorPreview = options.cursorPreview !== undefined
  ? !!options.cursorPreview
  : !_mobileDetected;

// v0.37 — gouache mode. When true, the active PIGMENTS array swaps to
// PIGMENTS_OPAQUE — high-scattering K/S values that render vibrantly
// on dark paper, mimicking opaque watercolor (gouache). Off by default
// to preserve traditional transparent watercolor behavior. Flipping at
// runtime swaps the array binding, re-uploads WebGL pigment uniforms,
// and forces a full re-render so already-deposited pigment is
// composited under the new physics.
//
// v0.51 — Accepts 'auto' (LERP based on paper darkness) in addition
// to boolean values. Initial state for 'auto' is set up below.
let _gouacheMode;
if (options.gouacheMode === 'auto') {
  _gouacheMode = 'auto';
  _recomputeLerpedPigments(_paperDarkness());
  PIGMENTS = PIGMENTS_LERPED;
} else if (options.gouacheMode !== undefined) {
  _gouacheMode = !!options.gouacheMode;
  if (_gouacheMode) PIGMENTS = PIGMENTS_OPAQUE;
} else {
  _gouacheMode = false;
}
const PALM_CONTACT_PX = 40;  // contacts wider than this are palms

const _pointerEnabled = options.pointer !== false;
let _isPainting = false;
let _lastGX = 0, _lastGY = 0;
let _pendingPaintX = null, _pendingPaintY = null;
let _activePointerId = null;
let _activePointerType = null;
// v0.28 — captured at pointer-down so move events use the same strength
// as the initial dab (rather than each PointerEvent.pressure varying
// within the same stroke).
let _strokeStrength = 0.7;

function _clientToGrid(e) {
  const rect = canvas.getBoundingClientRect();
  const cx = (e.clientX - rect.left) / rect.width;
  const cy = (e.clientY - rect.top)  / rect.height;
  return { gx: cx * GW, gy: cy * GH };
}

// Returns true if this event should be ignored as a palm contact.
// Only active when mobile mode is on; otherwise always returns false.
function _isPalmEvent(e) {
  if (!_mobileMode) return false;
  // 1. Contact size — palms produce wide contacts. width/height are in
  //    CSS pixels; not all browsers populate them (some return 1×1 even
  //    for real fingers). Treat 1×1 as "no info, don't filter."
  if (e.pointerType === 'touch' && e.width > 1 && e.height > 1) {
    if (e.width > PALM_CONTACT_PX || e.height > PALM_CONTACT_PX) return true;
  }
  // 2. Pen lockout — once we're painting with pen, drop touch.
  if (_activePointerType === 'pen' && e.pointerType === 'touch') return true;
  // 3. First-touch-wins — additional touches while painting are palm.
  if (_isPainting && _activePointerId !== null && e.pointerId !== _activePointerId) {
    return true;
  }
  return false;
}

function _onPointerDown(e) {
  if (!_pointerEnabled) return;
  // v0.90 — pause gates pointer input. With acceptInput true, the
  // user can paint into the frozen canvas; deposits are visible
  // immediately (via _pauseDirty + one-shot render) but don't
  // evolve via the sim until resume(). Without acceptInput,
  // pointer input is dropped entirely.
  if (_paused && !_pauseAcceptInput) return;
  if (_isPalmEvent(e)) return;
  e.preventDefault();
  _isPainting = true;
  _activePointerId = e.pointerId;
  _activePointerType = e.pointerType;
  const { gx, gy } = _clientToGrid(e);
  const r = (brushSize / 2) / SCALE;
  // v0.28 — strength from _brushPressure (was hardcoded 0.7), optionally
  // modulated by PointerEvent.pressure for stylus users. e.pressure
  // defaults to 0.5 for mouse events with no force; we only consult it
  // when _usePointerPressure is on so mouse strokes don't dim.
  let strength = _brushPressure;
  if (_usePointerPressure && e.pressure > 0) {
    strength *= e.pressure * 2;  // *2 since 0.5 is "neutral" → no change
  }
  // Remember the strength for this stroke so move events match the
  // down event (each PointerEvent has its own .pressure value, but the
  // user usually expects consistent strength per stroke).
  _strokeStrength = strength;
  paintAt(gx, gy, r, currentPigment, strength);
  _lastGX = gx; _lastGY = gy;
  canvas.setPointerCapture && canvas.setPointerCapture(e.pointerId);
}

function _onPointerMove(e) {
  if (!_isPainting || !_pointerEnabled) return;
  // v0.90 — same logic as _onPointerDown: drop moves when paused
  // without acceptInput. (If _isPainting were true at pause time,
  // it would mean a stroke was in progress; but we set _isPainting
  // back to false in pause(), so this is defensive.)
  if (_paused && !_pauseAcceptInput) return;
  // Only follow the active pointer. Other moves (e.g. palm dragging
  // while pen draws) get dropped here too.
  if (_activePointerId !== null && e.pointerId !== _activePointerId) return;
  if (_isPalmEvent(e)) return;
  e.preventDefault();
  const { gx, gy } = _clientToGrid(e);
  _pendingPaintX = gx;
  _pendingPaintY = gy;
}

function _onPointerUp(e) {
  if (!_isPainting) return;
  // Only end painting when the active pointer ends.
  if (_activePointerId !== null && e.pointerId !== _activePointerId) return;
  _isPainting = false;
  _activePointerId = null;
  _activePointerType = null;
  _pendingPaintX = null;
  _pendingPaintY = null;
  // v0.98 — clear dry-brush motion tracking so the next stroke starts
  // with no inherited direction. paintAt's 250ms freshness check
  // would clear it anyway, but explicit is better.
  _lastStampX = -1;
  _lastStampY = -1;
  canvas.releasePointerCapture && canvas.releasePointerCapture(e.pointerId);
}

// v0.29 — Continuous flow. When the pointer is pressed and held
// stationary, this lets pigment + water keep flowing into the wet area
// each frame, mimicking a brush or marker pressed against wet paper.
// Without this, pointerdown fires one stamp and then nothing happens
// until you move. With it on, holding the brush in place builds a
// growing puddle that bleeds outward through the sim's diffusion.
//
// Strength tuning: 0.12 per frame at 60fps is ~7x weaker than a
// single per-stamp deposit (0.7) but accumulates to a similar amount
// of pigment over ~1 second of holding still — which is roughly how
// long a wet brush takes to noticeably bleed in real life. Lower
// strength would feel too sluggish; higher would oversaturate before
// the user notices and lifts.
const CONTINUOUS_FLOW_STRENGTH = 0.12;
let _continuousFlow = options.continuousFlow !== undefined ? !!options.continuousFlow : true;

// Interpolated paint: along the path from _lastG to _pendingPaint,
// stamp every ~brushSize/2 pixels worth of distance. Without this, fast
// drags would skip cells and produce broken strokes.
//
// v0.29 — also handles the no-motion case: if the pointer is held
// stationary with continuousFlow on, we keep pumping pigment + water
// at the last known position.
function applyPendingPaint() {
  if (_pendingPaintX === null) {
    // No new position queued. If a stroke is still in progress AND
    // continuous flow is on, drip at the held position.
    if (_isPainting && _continuousFlow) {
      const r = (brushSize / 2) / SCALE;
      paintAt(_lastGX, _lastGY, r, currentPigment, CONTINUOUS_FLOW_STRENGTH);
    }
    return;
  }
  const gx = _pendingPaintX, gy = _pendingPaintY;
  const r = (brushSize / 2) / SCALE;
  // v0.28 — stamp spacing = r * _brushFlow (was hardcoded 0.4). Smaller
  // _brushFlow → more stamps per stroke → smoother continuous look;
  // larger → fewer stamps → dabbed/dotted look. The 0.5 floor prevents
  // pathological behavior at tiny brush sizes.
  const stampSpacing = Math.max(0.5, r * _brushFlow);
  const dx = gx - _lastGX, dy = gy - _lastGY;
  const dist = Math.sqrt(dx * dx + dy * dy);
  if (dist < stampSpacing) {
    paintAt(gx, gy, r, currentPigment, _strokeStrength);
  } else {
    const steps = Math.ceil(dist / stampSpacing);
    for (let s = 1; s <= steps; s++) {
      const f = s / steps;
      paintAt(_lastGX + dx * f, _lastGY + dy * f, r, currentPigment, _strokeStrength);
    }
  }
  _lastGX = gx; _lastGY = gy;
  _pendingPaintX = null;
  _pendingPaintY = null;
}

if (_pointerEnabled) {
  canvas.style.touchAction = 'none';   // prevent scroll on touch drag
  canvas.addEventListener('pointerdown', _onPointerDown);
  canvas.addEventListener('pointermove', _onPointerMove);
  canvas.addEventListener('pointerup',   _onPointerUp);
  canvas.addEventListener('pointercancel', _onPointerUp);
  canvas.addEventListener('pointerleave',  _onPointerUp);
}


// ============================================================
// PERFORMANCE INSTRUMENTATION (v2 lib addition — extracted from v0.19)
// ============================================================
// Tracks per-frame timings in a ring buffer and exposes the data via
// perfMetrics(). The host UI (v0.27's overlay) polls this and updates
// its DOM — the lib itself doesn't touch perf-related elements.
//
// Overhead when off: a single boolean check at each timing point.
// When on: 4-6 performance.now() calls per frame + Float32Array writes.
const PERF_BUFFER_SIZE = 120;          // ~2 sec at 60 fps
let perfEnabled = false;
let perfFrameIdx = 0;
const perfRing = {
  frame:  new Float32Array(PERF_BUFFER_SIZE),
  sim:    new Float32Array(PERF_BUFFER_SIZE),
  render: new Float32Array(PERF_BUFFER_SIZE),
  extra:  new Float32Array(PERF_BUFFER_SIZE),
  wash:   new Float32Array(PERF_BUFFER_SIZE),
};
let perfHeapStart = null;
let perfLoafCount = 0;
let perfLoafObserver = null;

function perfActivate(on) {
  perfEnabled = !!on;
  if (perfEnabled) {
    perfFrameIdx = 0;
    perfLoafCount = 0;
    if (performance.memory) perfHeapStart = performance.memory.usedJSHeapSize;
    // Long Animation Frame observer (Chromium-only currently). Counts
    // frames that blocked the main thread > 50ms.
    if (!perfLoafObserver && typeof PerformanceObserver !== 'undefined') {
      try {
        perfLoafObserver = new PerformanceObserver((list) => {
          perfLoafCount += list.getEntries().length;
        });
        perfLoafObserver.observe({ type: 'long-animation-frame', buffered: true });
      } catch (e) { /* type not supported on this browser; harmless */ }
    }
  }
}

function perfPercentile(arr, p) {
  const copy = Array.from(arr);
  copy.sort((a, b) => a - b);
  const idx = Math.min(copy.length - 1, Math.floor(p * copy.length));
  return copy[idx];
}
function perfMean(arr) {
  let s = 0;
  for (let i = 0; i < arr.length; i++) s += arr[i];
  return s / arr.length;
}
// v0.48 — Bug fix: this function was previously reading bindings named
// activeRectMinX / activeRectMaxX / ... which never existed anywhere in
// the lib (the real bindings are activeMinX / activeMaxX / etc.). The
// `typeof === 'undefined'` guard masked the typo silently, so the perf
// overlay's "active cells" readout has been stuck at 0 (0.0%) since
// perfMetrics() was added in v0.27. Now uses the correct names and
// reports the actual sim-active bounding box.
//
// Note this is the AREA of the axis-aligned bounding rectangle, not
// the count of cells with content. See perfLiveCells() below for the
// content-aware count. The bounding-rect metric is the perf-relevant
// one (= number of cells simStep visits per step); the live-cells
// metric is the human-relevant one (= cells that actually have paint).
function perfActiveCells() {
  if (typeof activeMinX === 'undefined' || activeMinX > activeMaxX) return 0;
  return (activeMaxX - activeMinX + 1) *
         (activeMaxY - activeMinY + 1);
}

// v0.48 — Count cells inside the active rect that actually have
// pigment/pressure above threshold. This is the metric most users
// expect when they read "active cells" — actual paint, not bounding
// box area. Two splotches in opposite corners would report ~100% on
// the bounding-rect metric but only a few percent on this one.
//
// O(rect_area), but only called from perfMetrics, which the host
// polls at ~6.7 Hz when the perf overlay is open. Zero cost when
// perf is off (perfMetrics isn't called).
function perfLiveCells() {
  if (activeRectIsEmpty()) return 0;
  const g0 = g[0], g1 = g[1], g2 = g[2];
  const thr = ACTIVE_THRESHOLD;
  let count = 0;
  for (let y = activeMinY; y <= activeMaxY; y++) {
    const yo = y * GW;
    for (let x = activeMinX; x <= activeMaxX; x++) {
      const i = yo + x;
      if (g0[i] > thr || g1[i] > thr || g2[i] > thr || pressure[i] > thr) {
        count++;
      }
    }
  }
  return count;
}

// v0.49 — Sum total pigment "mass" across the ENTIRE grid, not just
// the active rect. This is the cell-level sum of suspended (g) and
// deposited (d) pigment over all three pigment channels — the raw
// quantity of paint on the canvas regardless of whether the cell is
// currently "active" by the simulation's threshold.
//
// Useful for:
//   - Verifying paint conservation (paintAt deposits add up, lift /
//     fade subtract; with no input the total should stay flat ± noise).
//   - Diagnosing the active-rect optimization: if pigmentTotal is
//     non-zero but the rect is empty (or much smaller than expected),
//     it indicates residue or cells the shrink-scan missed.
//   - Building "how much paint did the user apply" UIs.
//
// O(N) per call (~540k cells on default grid), all 6 arrays touched
// linearly. Cheap on modern CPUs — well under a millisecond — and
// only called from perfMetrics (which only runs while the perf
// overlay is open). Returns three numbers in a single object:
//   suspended — total mass in the water layer (g[0..2])
//   deposited — total mass fixed on paper (d[0..2])
//   total     — suspended + deposited
function perfTotalPigment() {
  const g0 = g[0], g1 = g[1], g2 = g[2];
  const d0 = d[0], d1 = d[1], d2 = d[2];
  let suspended = 0, deposited = 0;
  for (let i = 0; i < N; i++) {
    suspended += g0[i] + g1[i] + g2[i];
    deposited += d0[i] + d1[i] + d2[i];
  }
  return { suspended: suspended, deposited: deposited, total: suspended + deposited };
}

// Snapshot of current perf state. The host polls this periodically
// (every ~10 frames is plenty) and renders the values into its overlay.
function perfMetrics() {
  const f50 = perfPercentile(perfRing.frame, 0.50);
  const f95 = perfPercentile(perfRing.frame, 0.95);
  const f99 = perfPercentile(perfRing.frame, 0.99);
  const fAvg = perfMean(perfRing.frame);
  const fps = fAvg > 0 ? 1000 / fAvg : 0;
  // v0.48 — Two distinct "active" metrics, see perfActiveCells() and
  // perfLiveCells() docstrings. The host overlay typically wants
  // liveCells (actual content) but rectCells is informative for
  // understanding sim cost.
  const rectCells = perfActiveCells();
  const live = perfLiveCells();
  const totalCells = GW * GH;
  // v0.49 — Sum pigment mass across the ENTIRE grid, regardless of
  // active-rect membership. See perfTotalPigment() docstring.
  const pig = perfTotalPigment();
  let heapDeltaMB = null;
  if (performance.memory && perfHeapStart != null) {
    heapDeltaMB = (performance.memory.usedJSHeapSize - perfHeapStart) / 1048576;
  }
  return {
    enabled: perfEnabled,
    fps:        fps,
    framep50:   f50,
    framep95:   f95,
    framep99:   f99,
    sim:        perfMean(perfRing.sim),
    render:     perfMean(perfRing.render),
    extra:      perfMean(perfRing.extra),
    wash:       perfMean(perfRing.wash),
    // activeCells = cells with content above threshold (what people
    // intuitively mean by "active"). activeRectCells = bbox area the
    // sim iterates over per step (the perf-relevant figure).
    activeCells:     live,
    activeRectCells: rectCells,
    totalCells:      totalCells,
    activePct:       totalCells > 0 ? (live / totalCells * 100) : 0,
    activeRectPct:   totalCells > 0 ? (rectCells / totalCells * 100) : 0,
    // v0.49 — Total pigment mass across the entire grid.
    pigmentSuspended: pig.suspended,
    pigmentDeposited: pig.deposited,
    pigmentTotal:     pig.total,
    heapDeltaMB: heapDeltaMB,
    longAnimationFrames: perfLoafObserver ? perfLoafCount : null,
  };
}

// ============================================================
// PER-INSTANCE MAIN LOOP
// ============================================================
// Single RAF token per instance. destroy() cancels it.
let rafToken = null;
function loop() {
  // v2 perf instrumentation: gated on perfEnabled. When off the calls
  // compile down to a single boolean check at each gate — negligible.
  const t0 = perfEnabled ? performance.now() : 0;

  // v0.90 — applyPendingPaint runs whether or not we're paused. With
  // acceptInput pause it actually does work (user is painting into
  // the frozen canvas). Without acceptInput, pointer events have
  // been short-circuited at the event listener so _pendingPaintX is
  // never set and this is a no-op anyway.
  applyPendingPaint && applyPendingPaint();
  // Animation/visualization/wash steps mutate sim parameters or
  // pigment over time. They're conceptually part of "the sim
  // running" so they should pause too.
  if (!_paused) {
    if (typeof animationStep === 'function') animationStep();
    if (typeof visualizationStep === 'function') visualizationStep();
  }
  // svgTraceStep is a render-time animation (each frame stamps
  // more pigment along the path) — it runs even when paused because
  // the user can call traceSVG to programmatically deposit pigment
  // on a paused canvas. Same logic as splash() / paintAt(): the
  // deposit happens; the sim picks it up on resume.
  if (typeof svgTraceStep === 'function') svgTraceStep();
  const tExtra = perfEnabled ? performance.now() : 0;

  // All three frame counters must increment every frame. Without
  // framesSinceIdleCheck++ the idle-skip check at shouldRunSim() is
  // permanently stuck below IDLE_CHECK_INTERVAL and the sim never
  // enters its idle path — every frame runs simStep + render even
  // when the canvas is completely settled. (This was a real bug in
  // an earlier draft of the lib.)
  framesSincePaint++;
  framesSinceIdleCheck++;
  framesSinceFade++;

  const tBeforeSim = perfEnabled ? performance.now() : 0;
  // v0.90 — pause gates the physics step. Everything else upstream
  // can still run (input deposits new pigment, render commits it),
  // but the actual simulation (advection, pressure, diffusion,
  // edge effects) is frozen until resume().
  const runSim = !_paused && shouldRunSim();
  if (runSim) {
    simStep();
    simStep();
  }
  const tAfterSim = perfEnabled ? performance.now() : 0;

  // v0.90 — render path: runs whenever runSim ran (normal case), OR
  // when paused-with-input has dirty cells from a deposit this frame.
  // _pauseDirty is set by markCanvasActive when paused, so any
  // deposit (programmatic OR pointer) flips it. We render once and
  // clear the flag — subsequent idle frames don't re-render.
  const shouldRender = runSim || _pauseDirty;
  if (_pauseDirty) _pauseDirty = false;
  if (shouldRender) {
    // v2 — route to GPU when useGPU. CPU render() handles its own
    // forceFull/active-rect logic; gpuRender always does a full pass.
    if (typeof useGPU !== 'undefined' && useGPU && gpuAvailable) {
      gpuRender();
    } else {
      render();
    }
  }
  const tAfterRender = perfEnabled ? performance.now() : 0;

  // Time-wash animator: each frame, if a time-of-day wash is active,
  // step its painter forward. Pauses with the sim.
  if (!_paused && typeof timeWash !== 'undefined' && timeWash !== null) {
    timeWashStep && timeWashStep();
  }

  // Pigment fade. v0.33 — when the sim is idle (no wet, no suspended
  // pigment moving), the per-frame render is skipped. But fadeStep
  // modifies d[] regardless, so without a forced render, the visible
  // pigment doesn't update on a dry canvas. Fix: if fade ran AND we
  // didn't render this frame, do a forced render + invalidate the
  // idle state so the active-rect machinery covers the whole canvas
  // for the fade pass.
  // v0.90 — fade pauses with the sim; otherwise pigment slowly
  // disappears from a paused canvas, which violates the "frozen
  // state" expectation.
  if (!_paused && fadeEnabled && framesSinceFade >= FADE_TICK_INTERVAL) {
    framesSinceFade = 0;
    fadeStep();
    if (!runSim) {
      // Sim is idle but fade just changed pigment. Force a full render
      // so the fade is visible. Also wake the sim briefly — fade may
      // expose previously-static cells that need future paints to
      // re-mark them active. simIsIdle stays true so we don't pay
      // simStep cost.
      setActiveRectFull();
      if (typeof useGPU !== 'undefined' && useGPU && gpuAvailable) {
        gpuRender();
      } else {
        render(true);
      }
    }
  }

  if (perfEnabled) {
    const tEnd = performance.now();
    const i = perfFrameIdx++ % PERF_BUFFER_SIZE;
    perfRing.frame[i]  = tEnd - t0;
    perfRing.sim[i]    = tAfterSim - tBeforeSim;
    perfRing.render[i] = tAfterRender - tAfterSim;
    perfRing.extra[i]  = tExtra - t0;
    perfRing.wash[i]   = tEnd - tAfterRender;
  }

  rafToken = requestAnimationFrame(loop);
}
rafToken = requestAnimationFrame(loop);


// ============================================================
// INSTANCE API (returned to caller)
// ============================================================
const api = {
  target: targetEl,
  canvas: canvas,

  // Backgrounds
  setBackground(name) { startTimeWash(name); return api; },
  isBackgroundRunning() { return typeof timeWash !== 'undefined' && timeWash !== null; },

  // Animations
  setAnimation(name, opts) {
    opts = opts || {};
    if (opts.replace !== false && typeof clearAllAnimationState === 'function') {
      clearAllAnimationState();
    }
    animationMode = name || 'off';
    return api;
  },
  getAnimation() { return typeof animationMode !== 'undefined' ? animationMode : 'off'; },

  // Visualizations
  setVisualization(name, opts) {
    opts = opts || {};
    if (opts.replace !== false && typeof clearAllVisualizationState === 'function') {
      clearAllVisualizationState();
    }
    visualizationMode = name || 'off';
    return api;
  },
  getVisualization() { return typeof visualizationMode !== 'undefined' ? visualizationMode : 'off'; },

  // Splash, rewet, dry, reset
  splash(arg1, arg2, opts) { splash(arg1, arg2, opts); return api; },
  splashPresets()    { return splashPresets(); },
  rewet()            { rewet();     return api; },
  dry()              { dryPaper();  return api; },
  reset()            { resetSim();  return api; },

  // v2 — Brush controls.
  // brushSize is in display pixels (diameter). The library converts
  // to grid units internally. Pigment indices: 0=rose, 1=yellow,
  // 2=blue, or named brushes 'water', 'lift', 'rainbow', 'mask'.
  brushSize(v) {
    if (v !== undefined) brushSize = Math.max(1, +v);
    return brushSize;
  },
  pigment(v) {
    if (v === undefined) return currentPigment;
    if (typeof v === 'string') {
      // v0.32 — accept the same name set as _resolvePigmentOption,
      // so callers don't trip on rose/yellow/blue/cerulean working
      // in traceSVG opts but not as a direct pigment(name) call.
      currentPigment = _resolvePigmentOption(v);
    } else {
      currentPigment = v|0;
    }
    return api;
  },
  // List of pigments + the named brushes available.
  pigments() {
    return [
      { index: 0, name: PIGMENTS[0].name },
      { index: 1, name: PIGMENTS[1].name },
      { index: 2, name: PIGMENTS[2].name },
      { index: WATER_INDEX,   name: 'water' },
      { index: LIFT_INDEX,    name: 'lift' },
      { index: RAINBOW_INDEX, name: 'rainbow' },
      { index: MASK_INDEX,    name: 'mask' },
      { index: PAPER_INDEX,   name: 'paper' },
    ];
  },

  // v2 — Paint at grid coordinates directly. The same call used by
  // animations/visualizations internally. Useful for choreographed
  // painting from a parent script.
  // v0.32 — accept name strings (e.g. 'rose', 'water', 'paper') in
  // addition to numeric indices, matching traceSVG/paintText behavior.
  paintAt(gx, gy, gridRadius, pigmentIdx, strength) {
    if (typeof pigmentIdx === 'string') {
      pigmentIdx = _resolvePigmentOption(pigmentIdx);
    }
    paintAt(gx, gy, gridRadius, pigmentIdx, strength);
    return api;
  },

  // v2 — Paper-wetness presets. Five named steps from flooded → boneDry.
  paperWetness(preset) {
    if (preset === undefined) return null;   // no getter for now
    if (!applyEvapPreset(preset)) {
      throw new Error('Unknown paper-wetness preset: ' + preset +
        '. Valid: ' + Object.keys(EVAP_PRESETS).join(', '));
    }
    return api;
  },
  paperWetnessPresets() { return Object.keys(EVAP_PRESETS); },

  // v0.52 — Numeric evaporation multiplier. The docs have claimed this
  // method exists since v0.30, but it was never wired up (an oversight
  // — the underlying setEvaporationMult was present but only reachable
  // through `paperWetness('damp')` etc., not directly).
  //
  // Accepts either:
  //   - A preset name string ('flooded' / 'wetOnWet' / 'damp' /
  //     'dryBrush' / 'boneDry') → forwards to paperWetness().
  //   - A numeric multiplier in [0.1, 200] → applied directly.
  //     evaporationRate = 0.9988^mult, so mult=1 ≈ 0.9988 (very wet),
  //     mult=50 ≈ 0.94 (bone dry).
  //   - undefined → returns the current effective multiplier.
  evaporation(value) {
    if (value === undefined) {
      // Derive multiplier from current rate. Inverse of setEvaporationMult.
      const m = Math.log(evaporationRate) / Math.log(0.9988);
      return isFinite(m) ? m : 1;
    }
    if (typeof value === 'string') {
      if (!applyEvapPreset(value)) {
        throw new Error('Unknown paper-wetness preset: ' + value +
          '. Valid: ' + Object.keys(EVAP_PRESETS).join(', '));
      }
    } else {
      setEvaporationMult(+value);
    }
    return api;
  },

  // v0.30 — Sketch mode. Bundles a set of brush + paper settings tuned
  // for crisp fine-line drawings (felt-tip pen aesthetic). Intended for
  // SVG-traced thumbnails and other "drawing"-style uses where bleed is
  // unwanted. Pure setter — no separate mode flag, no state to restore;
  // it just calls the underlying API methods. Caller can override any
  // individual setting after by calling the corresponding method.
  //
  // Applied settings:
  //   brushSize(opts.brushSize ?? 7)        — fine tip
  //   paintLoad(opts.paintLoad ?? 1.6)      — denser pigment per dab
  //   waterLoad(opts.waterLoad ?? 0.25)     — minimal moisture
  //   pressure(opts.pressure ?? 0.95)       — firm strokes
  //   paperWetness(opts.paperWetness ?? 'boneDry')  — no bleed
  //   continuousFlow(false)                 — pure stamps, no hold-drip
  //   edgeDarkening(false)                  — clean lines, no rim
  //   fadePainting(false)                   — strokes persist
  //
  // Returns the instance for chaining: wc.sketchMode().traceSVG(svg).
  sketchMode(opts) {
    opts = opts || {};
    api.brushSize(opts.brushSize !== undefined ? opts.brushSize : 7);
    api.paintLoad(opts.paintLoad !== undefined ? opts.paintLoad : 1.6);
    api.waterLoad(opts.waterLoad !== undefined ? opts.waterLoad : 0.25);
    api.pressure(opts.pressure !== undefined ? opts.pressure : 0.95);
    api.paperWetness(opts.paperWetness || 'boneDry');
    api.continuousFlow(false);
    api.edgeDarkening(false);
    api.fadePainting(false);
    return api;
  },

  // v0.30 — Obliterate. Visually destroys the current drawing via a
  // wet wash. Three modes:
  //
  //   mode: 'water'   — splash water onto the canvas, lifting all
  //                     deposited pigment back into suspension. The
  //                     pigment swirls outward as it diffuses. Best
  //                     for "rinse" or "wash away" feel.
  //
  //   mode: 'pigment' — paint several large opaque dabs over the
  //                     sketch in the configured color. Best for
  //                     "cover up" feel — sketch disappears under a
  //                     wash of color.
  //
  //   mode: 'paper'   — paint several large dabs with the paper
  //                     brush, clearing the sketch back to paper
  //                     color. Best for "erase" or "reveal page"
  //                     feel — sketch disappears, paper remains.
  //                     (v0.32)
  //
  // Returns a Promise that resolves after durationMs (default 500).
  obliterate(opts) {
    opts = opts || {};
    const mode = opts.mode || 'water';
    const duration = opts.durationMs !== undefined ? +opts.durationMs : 500;
    const cx = opts.x !== undefined ? +opts.x : GW * 0.5;
    const cy = opts.y !== undefined ? +opts.y : GH * 0.5;
    const radiusFraction = opts.radiusFraction !== undefined ? +opts.radiusFraction : 0.7;
    const intensity = opts.intensity || 'normal';

    if (mode === 'water') {
      const presetMap = {
        gentle:  'fineSpritz',
        normal:  'default',
        extreme: 'bigSplash',
      };
      const presetName = presetMap[intensity] || 'default';
      splash([{ x: cx, y: cy }], presetName);
    } else if (mode === 'pigment') {
      const pig = opts.pigment !== undefined
        ? _resolvePigmentOption(opts.pigment)
        : currentPigment;
      splash([{ x: cx, y: cy }], 'default');
      const r = Math.min(GW, GH) * radiusFraction * 0.5;
      const intensityMul = intensity === 'gentle' ? 0.6
                        : intensity === 'extreme' ? 1.4 : 1.0;
      const dabStrength = Math.min(1.0, 0.9 * intensityMul);
      paintAt(cx, cy, r, pig, dabStrength);
      paintAt(cx + r * 0.5, cy, r * 0.7, pig, dabStrength * 0.7);
      paintAt(cx - r * 0.5, cy, r * 0.7, pig, dabStrength * 0.7);
      paintAt(cx, cy + r * 0.5, r * 0.7, pig, dabStrength * 0.7);
      paintAt(cx, cy - r * 0.5, r * 0.7, pig, dabStrength * 0.7);
    } else if (mode === 'paper') {
      // v0.32 — Paper mode. Wipes the sketch back to canvas color.
      // Uses the same five-dab pattern as 'pigment' but with the
      // paper-brush sentinel, which clears deposited + suspended
      // pigment in the footprint and adds wetness for a wash effect.
      const r = Math.min(GW, GH) * radiusFraction * 0.5;
      const intensityMul = intensity === 'gentle' ? 0.7
                        : intensity === 'extreme' ? 1.2 : 1.0;
      const dabStrength = Math.min(1.0, 0.95 * intensityMul);
      paintAt(cx, cy, r, PAPER_INDEX, dabStrength);
      paintAt(cx + r * 0.5, cy, r * 0.7, PAPER_INDEX, dabStrength * 0.85);
      paintAt(cx - r * 0.5, cy, r * 0.7, PAPER_INDEX, dabStrength * 0.85);
      paintAt(cx, cy + r * 0.5, r * 0.7, PAPER_INDEX, dabStrength * 0.85);
      paintAt(cx, cy - r * 0.5, r * 0.7, PAPER_INDEX, dabStrength * 0.85);
    } else {
      throw new Error('Watercolor.obliterate: mode must be \'water\', \'pigment\', or \'paper\', got: ' + mode);
    }

    markCanvasActive();
    return new Promise((resolve) => setTimeout(resolve, duration));
  },

  // v2 — Text painting. Stamps the text via paintAt over an off-screen
  // canvas render of the text bitmap. Returns the number of dabs painted.
  paintText(text, opts) { return paintText(text, opts); },
  paintImage(source, opts) { return paintImage(source, opts); },

  // v2 — SVG tracing. Pass SVG markup as a string. The library walks
  // geometry elements, samples points along each path, and paints them.
  //
  // v0.28 — accepts opts to customize the trace:
  //   pigment: name or index (default: current pigment)
  //   brushSize: diameter in display pixels (default: current brushSize)
  //   strength: 0..1 stamp strength (default: current pressure())
  //   flipY: invert vertical orientation. Default true.
  //
  // v0.30 — speed control:
  //   instant: true      → paint everything in one synchronous frame.
  //                        For thumbnails on page load.
  //   durationMs: <ms>   → spread the trace over roughly this many ms
  //                        (at 60fps). Useful for choreographed
  //                        animations.
  //   (neither)          → default ~10 points per frame.
  traceSVG(svgText, opts) {
    return loadSVGAndTrace(svgText, opts);
  },
  cancelSVGTrace() { cancelSVGTrace(); return api; },

  // v2 — Mask brush. The MASK pigment freezes cells when painted via
  // paintAt(..., pigment='mask'). removeMask() clears the entire mask.
  removeMask() { removeMask(); return api; },

  // v0.95 — Stamp a rounded rectangle directly into the mask
  // field. Crisper edges and faster than approximating with many
  // overlapping paintAt(MASK_INDEX) circle stamps.
  //
  //   wc.maskRect(x, y, w, h)              — square corners
  //   wc.maskRect(x, y, w, h, 12)          — uniform 12px corners
  //   wc.maskRect(x, y, w, h, [8, 8, 0, 0]) — rounded top, square bottom
  //
  // x/y/w/h are display pixels (same coord space as
  // getBoundingClientRect, host.clientWidth, etc.). radii follows
  // the CanvasRenderingContext2D.roundRect() spec — see the
  // implementation comment for the array-shape interpretations.
  // Mask cells are set to 1.0 (fully frozen).
  maskRect(displayX, displayY, displayW, displayH, radii) {
    maskRectDisplay(displayX, displayY, displayW, displayH, radii);
    return api;
  },

  // v0.96 — Inverse of maskRect. Clears mask cells inside a
  // rounded rectangle so subsequent paint operations can deposit
  // there. Useful for "open a window" effects in masked regions
  // (link hover splashes inside a masked card, for example).
  //
  //   wc.unmaskRect(linkX, linkY, linkW, linkH)        // square
  //   wc.unmaskRect(linkX, linkY, linkW, linkH, 4)     // rounded
  //
  // If un-masking clears the last masked cells in the field, the
  // mask system flips off entirely (mask-tracking returns to its
  // fast no-mask path). Otherwise the global maskRect bounding box
  // is left alone; the per-cell mask check inside sim functions
  // still gives correct results — just slightly less efficient
  // than a tight bbox would be.
  unmaskRect(displayX, displayY, displayW, displayH, radii) {
    unmaskRectDisplay(displayX, displayY, displayW, displayH, radii);
    return api;
  },

  // v0.97 — Ink pigment. A separate single-channel layer alongside
  // the K-M pigments. Renders as a darkening multiplier on top of
  // the pigment-rendered color. Default high paint load + low water
  // load: crisp deposits that bloom only when external wet pigment
  // reaches them.
  //
  // Usage matches the regular pigment API:
  //   wc.pigment('ink');
  //   wc.paintAt(gx, gy, gridR);          // strength = current
  //   wc.paintAt(gx, gy, gridR, 'ink', s); // explicit
  //
  // Per-pigment load defaults (independent of paintLoad/waterLoad
  // globals which apply to K-M pigments):
  //
  //   wc.inkPaintLoad(v?)  — default 1.0 (saturate immediately)
  //   wc.inkWaterLoad(v?)  — default 0.05 (minimal self-bleed)
  //
  //   wc.clearInk()        — zero out the ink field everywhere
  inkPaintLoad(v) {
    if (v !== undefined) {
      const n = +v;
      if (!isFinite(n) || n < 0) {
        console.warn('inkPaintLoad: expected non-negative number, got', v);
        return inkPaintLoadDefault;
      }
      inkPaintLoadDefault = n;
    }
    return inkPaintLoadDefault;
  },
  inkWaterLoad(v) {
    if (v !== undefined) {
      const n = +v;
      if (!isFinite(n) || n < 0) {
        console.warn('inkWaterLoad: expected non-negative number, got', v);
        return inkWaterLoadDefault;
      }
      inkWaterLoadDefault = n;
    }
    return inkWaterLoadDefault;
  },
  clearInk() {
    for (let i = 0; i < N; i++) ink[i] = 0;
    inkActive = false;
    if (useGPU) gpuRender(); else render(true);
    return api;
  },

  // v0.98 — Dry brush mode. First-class brush behavior alongside
  // pigment selection. When mode is 'dry', paint deposit through
  // paintAt is modulated by paper-tooth rejection + bristle skip +
  // motion-direction anisotropy. Composes with all K-M pigments
  // (rose, yellow, blue) — pick a pigment, then pick how to apply
  // it. Currently only K-M pigments respect dry mode; ink, water,
  // lift, mask, and paper brushes ignore it (their semantics
  // don't have a "dry vs wet" analog).
  //
  //   wc.brushMode()           → 'wet' | 'dry'
  //   wc.brushMode('dry')      → switch to dry mode
  //   wc.brushMode('wet')      → switch back to wet (normal)
  //
  //   wc.dryness()             → 0..1 composite slider
  //   wc.dryness(0.5)          → half-dry: visible paper texture, mild
  //                              streaking, some water reduction
  //
  // Sub-knobs for fine control. Each defaults to a value that
  // produces a balanced look when combined under the composite
  // slider; tune individually if you want, e.g., paper texture
  // without directional streaking.
  //
  //   wc.dryPaperReject(v?)    → strength of paperH-driven rejection (default 0.65)
  //   wc.dryAnisotropy(v?)     → motion-direction streak strength    (default 0.6)
  //   wc.dryBrushSkip(v?)      → fine random per-cell skip variance  (default 0.5)
  brushMode(v) {
    if (v !== undefined) {
      // 'dry' is a legacy alias for 'crayon' (the original v0.98
      // shipped just 'wet' and 'dry'; renaming 'dry' to 'crayon'
      // keeps the old call site working).
      const valid = new Set(['wet', 'crayon', 'dry', 'dryBrush', 'salt', 'splatter']);
      if (!valid.has(v)) {
        console.warn("brushMode: expected one of 'wet', 'crayon', 'dryBrush', 'salt', 'splatter' (got", v, ')');
        return _brushMode;
      }
      _brushMode = v;
      // Reset last-stamp tracking when mode changes mid-stroke so
      // the first textured stamp doesn't inherit a stale direction.
      _lastStampX = -1;
      _lastStampY = -1;
    }
    return _brushMode;
  },
  dryness(v) {
    if (v !== undefined) {
      const n = +v;
      if (!isFinite(n) || n < 0 || n > 1) {
        console.warn('dryness: expected number in 0..1, got', v);
        return _drynessAmount;
      }
      _drynessAmount = n;
    }
    return _drynessAmount;
  },
  dryPaperReject(v) {
    if (v !== undefined) {
      const n = +v;
      if (!isFinite(n) || n < 0 || n > 1) {
        console.warn('dryPaperReject: expected number in 0..1, got', v);
        return _dryPaperReject;
      }
      _dryPaperReject = n;
    }
    return _dryPaperReject;
  },
  dryAnisotropy(v) {
    if (v !== undefined) {
      const n = +v;
      if (!isFinite(n) || n < 0 || n > 1) {
        console.warn('dryAnisotropy: expected number in 0..1, got', v);
        return _dryAnisotropy;
      }
      _dryAnisotropy = n;
    }
    return _dryAnisotropy;
  },
  dryBrushSkip(v) {
    if (v !== undefined) {
      const n = +v;
      if (!isFinite(n) || n < 0 || n > 1) {
        console.warn('dryBrushSkip: expected number in 0..1, got', v);
        return _dryBrushSkip;
      }
      _dryBrushSkip = n;
    }
    return _dryBrushSkip;
  },

  // v2 — Render real KM-compositor pigment swatches into the given
  // root element. Same visuals as v0.26.2's swatches (paper texture,
  // edge fade, granulation). Click handlers update the current pigment
  // and dispatch a 'pigmentchange' CustomEvent on the root element so
  // the host can react (highlight active, update cursor preview).
  // Re-call after paperColor() changes to rebuild swatches.
  buildPigmentSwatches(rootEl) {
    buildPigmentSwatches(rootEl);
    return api;
  },

  // v2 — Paper color (RGB in 0..1 floats). Changes the substrate that
  // Kubelka-Munk renders against. Re-renders the canvas immediately so
  // the change is visible without waiting for the next sim step.
  paperColor(r, g, b) {
    if (r === undefined) {
      return { r: PAPER_R_BASE, g: PAPER_G_BASE, b: PAPER_B_BASE };
    }
    PAPER_R_BASE = Math.max(0, Math.min(1, +r));
    PAPER_G_BASE = Math.max(0, Math.min(1, +g));
    PAPER_B_BASE = Math.max(0, Math.min(1, +b));
    // v0.51 — While in auto gouache mode, re-LERP the active pigment
    // set whenever paper changes. The paper drives the gouache
    // amount, so dragging the picker from cream to charcoal smoothly
    // morphs the pigments from transparent watercolor to fully
    // opaque gouache. Outside of auto mode, the toggle controls the
    // pigment set and paper changes only affect the substrate. The
    // dispatch lets UI swatches refresh to show the new pigment
    // appearance.
    if (_gouacheMode === 'auto') {
      _recomputeLerpedPigments(_paperDarkness());
      setActiveRectFull();
      targetEl.dispatchEvent(new CustomEvent('gouachechange', {
        detail: { enabled: _gouacheMode, lerpAmount: _gouacheLerpT },
      }));
    }
    render(true);
    return api;
  },

  // v2 — Current rainbow brush RGB color (0..1 per channel). Useful for
  // UI cursor previews that want to track the rainbow cycle.
  rainbowColor() {
    updateRainbowWeights(performance.now());
    // Mix the three pigment K/S triplets weighted by rainbowW for a
    // rough approximation of the current rainbow color.
    return {
      r: PIGMENTS[0].S[0]*rainbowW[0] + PIGMENTS[1].S[0]*rainbowW[1] + PIGMENTS[2].S[0]*rainbowW[2],
      g: PIGMENTS[0].S[1]*rainbowW[0] + PIGMENTS[1].S[1]*rainbowW[1] + PIGMENTS[2].S[1]*rainbowW[2],
      b: PIGMENTS[0].S[2]*rainbowW[0] + PIGMENTS[1].S[2]*rainbowW[1] + PIGMENTS[2].S[2]*rainbowW[2],
    };
  },

  // v2 — Resolution. SCALE = display pixels per simulation cell.
  // 1.0 = highest detail (1.5M cells at 1080p, expensive). 6.0 = fastest
  // (10× fewer cells, broad bleeds). Calling rebuildScale reallocates
  // every state array, regenerates paper, and resets the canvas.
  // Dispatches 'rescaled' CustomEvent on targetEl when done.
  scale(v) {
    if (v === undefined) return SCALE;
    const n = +v;
    if (!isFinite(n) || n < 1 || n > 6) {
      throw new Error('Watercolor.scale: value must be 1..6, got ' + v);
    }
    rebuildScale(n);
    return api;
  },

  // v2 — Fade half-life in milliseconds. Controls the rate at which
  // deposited pigment decays when fadePainting is on. Range 1000..60000.
  // Half-life of 5000ms means deposited pigment loses half its density
  // every 5 seconds.
  fadeHalfLife(ms) {
    if (ms === undefined) return fadeHalfLifeMs;
    setFadeHalfLifeMs(+ms);
    return api;
  },

  // v2 — WebGL render path (extracted from v0.20). Lazy-init on first
  // toggle; subsequent toggles flip the flag. webglAvailable() returns
  // the result of init (latched after first attempt).
  webgl(v) {
    if (v === undefined) return useGPU;
    if (v && !gpuInitTried) initWebGL();
    if (v && !gpuAvailable) {
      console.warn('Watercolor.webgl(true): WebGL2 init failed; using CPU path.');
      useGPU = false;
      return false;
    }
    useGPU = !!v;
    // Force a render pass on the new path immediately so the toggle feels
    // instantaneous instead of waiting for the next sim step.
    if (useGPU) gpuRender(); else render(true);
    return useGPU;
  },
  webglAvailable() {
    if (!gpuInitTried) initWebGL();
    return gpuAvailable;
  },
  webglDebugTint(v) {
    if (v !== undefined) gpuDebugTint = !!v;
    return gpuDebugTint;
  },
  // v0.89 — Quality preset. Bundles scale, advection mode, and a few
  // feature toggles into named tiers. No runtime adaptation — this is
  // a manual knob that embedders can expose to their users via
  // "Quality: High / Medium / Low" UI, or call once at init based on
  // their own heuristic.
  //
  // Trade-offs by preset:
  //   'high'    — scale 1.5, fine grain. Best on desktop.
  //   'medium'  — scale 2.0, library default. Good general baseline.
  //   'low'     — scale 2.75, forces wetnessHeatmap off (skips
  //               overlay pass each frame). Good on phones.
  //   'minimum' — scale 3.5, donor-cell advection, no cursor preview,
  //               no heatmap. Last-resort fallback. WARNING: brings
  //               back the cardinal cross artifact (donor-cell mode);
  //               only use when frame budget is genuinely critical.
  //
  // Reads scale via the api (which triggers a rescale + reallocation)
  // so this is not a free call — expect a frame-or-two pause when
  // applied. Doesn't touch user-set values for things outside the
  // preset's scope (gravity strength, edge mode, mask state, etc.).
  //
  // Calling with no arg returns the most-recently-applied preset
  // name, or null if quality() has never been called.
  quality(preset) {
    if (preset === undefined) return _qualityCurrent;
    const presets = {
      'high':    { scale: 1.5,  advection: 'semilag',  heatmap: null, cursor: true  },
      'medium':  { scale: 2.0,  advection: 'semilag',  heatmap: null, cursor: true  },
      'low':     { scale: 2.75, advection: 'semilag',  heatmap: false, cursor: true  },
      'minimum': { scale: 3.5,  advection: 'standard', heatmap: false, cursor: false },
    };
    const p = presets[preset];
    if (!p) {
      console.warn('quality: expected one of "high"|"medium"|"low"|"minimum", got', preset);
      return _qualityCurrent;
    }
    api.scale(p.scale);
    api.advectionMode(p.advection);
    if (p.heatmap === false) api.wetnessHeatmap(false);
    // heatmap === null means "don't touch user's setting" (high/medium presets)
    api.cursorPreview(p.cursor);
    _qualityCurrent = preset;
    return preset;
  },

  // v0.90 — Pause the simulation. Stops simStep, fadeStep, time-wash,
  // and animation steps. The rAF loop continues so input can still
  // produce renders (when acceptInput is true) and so resume() takes
  // effect immediately on the next frame.
  //
  //   wc.pause()                            — freeze sim, ignore input
  //   wc.pause({ acceptInput: true })       — freeze sim, accept paint input
  //
  // While paused-with-acceptInput, the user (or programmatic code via
  // splash/paintAt/traceSVG) can deposit new pigment. Each deposit
  // triggers a one-shot render so the user sees their stroke
  // immediately. The deposits sit inert until resume() — they don't
  // bleed, flow, or evaporate while paused.
  //
  // Pointer events on the canvas are ignored when paused without
  // acceptInput. The canvas's CSS pointer-events is unchanged
  // (parent overlays and other listeners still work normally); only
  // the lib's own pointer handlers short-circuit.
  pause(opts) {
    opts = opts || {};
    if (_paused) {
      // Already paused — just update acceptInput if it changed.
      _pauseAcceptInput = !!opts.acceptInput;
      return api;
    }
    _paused = true;
    _pauseAcceptInput = !!opts.acceptInput;
    _pauseStartedAt = (typeof performance !== 'undefined' ? performance.now() : Date.now());
    // If a stroke was in progress when pause was called and we're
    // not accepting input, end it cleanly so the user can't return
    // to a half-state on resume.
    if (!_pauseAcceptInput) {
      _isPainting = false;
      _activePointerId = null;
      _pendingPaintX = null;
      _pendingPaintY = null;
    }
    return api;
  },

  // v0.90 — Resume from pause. Adjusts wall-clock timer references
  // for any animations that were mid-flight at pause time, so they
  // pick up where they left off instead of jumping ahead by the
  // pause duration.
  resume() {
    if (!_paused) return api;
    const now = (typeof performance !== 'undefined' ? performance.now() : Date.now());
    const pauseDuration = now - _pauseStartedAt;
    // SVG trace state has a wall-clock startTime; shift it forward
    // by the pause duration so easing continues from where it was.
    if (typeof svgTraceState !== 'undefined' && svgTraceState && svgTraceState.startTime) {
      svgTraceState.startTime += pauseDuration;
    }
    _paused = false;
    _pauseAcceptInput = false;
    _pauseDirty = false;
    // The sim has been frozen for an arbitrary amount of time; cells
    // may have been marked dirty by deposits during pause. Force a
    // wake so the sim restarts processing them.
    markCanvasActive();
    return api;
  },

  // v0.90 — Pause state inspector. Returns false when running,
  // or an object { acceptInput: boolean } when paused. Using a
  // falsy-or-object return lets callers do both
  // `if (wc.paused())` and `wc.paused()?.acceptInput`.
  paused() {
    if (!_paused) return false;
    return { acceptInput: _pauseAcceptInput };
  },

  // v0.80 — Toggle the amber overlay that visualizes masked cells.
  // When false, mask freezing is unchanged (flow continues to skip
  // masked cells) but the tint is hidden so masked regions render as
  // ordinary paper/pigment. Useful for screenshots or when the mask
  // shouldn't compete visually with the wash. Default true.
  maskTint(v) {
    if (v !== undefined) {
      _maskTintVisible = !!v;
      // Force an immediate render so the toggle feels instant.
      if (useGPU) gpuRender(); else render(true);
    }
    return _maskTintVisible;
  },

  // v0.86 — Wetness heatmap overlay. Visualizes wet[] as a two-color
  // gradient on top of the painting. Cells below MASK_THRESHOLD render
  // transparent so dry areas show the painting underneath unchanged.
  //
  //   wc.wetnessHeatmap()                                   // returns boolean
  //   wc.wetnessHeatmap(true)                               // enable
  //   wc.wetnessHeatmap(false)                              // disable
  //   wc.wetnessHeatmap(true, '#fcf3a7', '#296fa7')         // enable + set colors
  //   wc.wetnessHeatmap({ enabled: true, low: '#abc', high: '#def' })
  //
  // Colors accept '#rgb', '#rrggbb', or [r, g, b] 0..255 arrays.
  wetnessHeatmap(arg1, lowColor, highColor) {
    // Read mode
    if (arg1 === undefined) return _wetnessHeatmapEnabled;
    // Object form
    let enabled, low, high;
    if (typeof arg1 === 'object' && arg1 !== null && !Array.isArray(arg1)) {
      enabled = !!arg1.enabled;
      low = arg1.low;
      high = arg1.high;
    } else {
      enabled = !!arg1;
      low = lowColor;
      high = highColor;
    }
    _wetnessHeatmapEnabled = enabled;
    if (low !== undefined)  _wetnessLowColor  = _parseHeatmapColor(low,  _wetnessLowColor);
    if (high !== undefined) _wetnessHighColor = _parseHeatmapColor(high, _wetnessHighColor);
    // Force a render so the toggle/color change shows immediately even
    // if the sim is idle.
    if (useGPU) gpuRender(); else render(true);
    return _wetnessHeatmapEnabled;
  },

  // v0.81 — Edge boundary mode.
  //   'closed'         (default) — all four edges reflect; mass conserved.
  //                                Gravity bias NOT applied.
  //   'closed-gravity' (v0.88)  — closed edges (no drainage), but
  //                                gravity bias IS applied. Pigment piles
  //                                at downwind edges; pair with edgeFade()
  //                                to hide the buildup visually.
  //   'open'           — all four edges drain. No bias by default.
  //   'gravity'        — edges open in the direction of gravity; bias active.
  // See docs section "Edge modes" for visual description.
  edgeMode(v) {
    if (v !== undefined) {
      if (v !== 'closed' && v !== 'closed-gravity' && v !== 'open' && v !== 'gravity') {
        console.warn('edgeMode: expected "closed" | "closed-gravity" | "open" | "gravity", got', v);
        return _edgeMode;
      }
      _edgeMode = v;
      _recomputeEdgeState();
    }
    return _edgeMode;
  },
  // 8-compass direction. Ignored when edgeMode is 'closed'.
  // Pure cardinals: 'up' | 'right' | 'down' | 'left'.
  // Diagonals: 'up-right' | 'down-right' | 'down-left' | 'up-left'.
  gravityDirection(v) {
    if (v !== undefined) {
      if (!_COMPASS[v]) {
        console.warn('gravityDirection: unknown direction', v);
        return _gravityDir;
      }
      _gravityDir = v;
      _recomputeEdgeState();
    }
    return _gravityDir;
  },
  // 0.0 (no pull) to ~1.0 (a hard pull as strong as VEL_CLAMP itself).
  // Practical range: 0 to ~0.25. Values above 0.5 feel like the page
  // is being shaken rather than tilted.
  gravityStrength(v) {
    if (v !== undefined) {
      const n = +v;
      if (!isFinite(n)) {
        console.warn('gravityStrength: expected number, got', v);
        return _gravityStrength;
      }
      _gravityStrength = Math.max(0, n);
      _recomputeEdgeState();
    }
    return _gravityStrength;
  },

  // v0.88 — Edge fade. Smoothstep alpha falloff in the last N grid
  // cells at each edge. 0 disables. Independent of edge mode —
  // composes with closed / closed-gravity / open / gravity.
  //
  // Primary use case: pair with 'closed-gravity' mode to get gravity
  // dynamics (pigment drifts in a direction) without the visible
  // edge buildup that closed-mode would otherwise show. The pigment
  // is still mathematically present at the edge; the render just
  // makes it transparent.
  //
  //   wc.edgeFade()        // returns current value (number, 0 = off)
  //   wc.edgeFade(0)       // disable
  //   wc.edgeFade(24)      // 24-cell falloff zone at each edge
  edgeFade(v) {
    if (v !== undefined) {
      const n = +v;
      if (!isFinite(n)) {
        console.warn('edgeFade: expected number, got', v);
        return _edgeFadePixels;
      }
      _edgeFadePixels = Math.max(0, n);
      // Force a render so the change feels instantaneous.
      if (useGPU) gpuRender(); else render(true);
    }
    return _edgeFadePixels;
  },

  // v0.84 — Maximum per-cell velocity magnitude after the
  // pressure/viscosity/drag update. Auto-computed from SCALE by
  // default (so display-pixel speed is resolution-invariant), but
  // can be overridden manually. Pass `null` to restore the
  // auto-computed default and re-enable resolution-coupled recompute.
  //
  // CFL note: non-semi-Lagrangian advection modes (standard, clamp,
  // substep) require VEL_CLAMP * (DT * 0.7) * 2 < 1, i.e.
  // VEL_CLAMP < ~1.7. Above that, those modes will produce cardinal
  // cross artifacts again. Semi-Lagrangian (the default) has no CFL
  // bound, so high VEL_CLAMP values are safe in that mode. The lib
  // does NOT enforce the bound — the caller can pass any value and
  // see what happens, which is useful for stylistic exploration.
  velocityClamp(v) {
    if (v === undefined) return VEL_CLAMP;
    if (v === null) {
      _velocityClampManual = false;
      VEL_CLAMP = Math.min(1.5, 1.0 * inv_s);
      return VEL_CLAMP;
    }
    const n = +v;
    if (!isFinite(n) || n <= 0) {
      console.warn('velocityClamp: expected positive number or null, got', v);
      return VEL_CLAMP;
    }
    VEL_CLAMP = n;
    _velocityClampManual = true;
    return VEL_CLAMP;
  },

  // v2 — Performance instrumentation. perf(true) starts recording per-
  // frame timings into a ring buffer; perfMetrics() returns the current
  // snapshot (fps, p50/p95/p99 frame times, per-phase ms, active cells,
  // heap delta, Long Animation Frame count). The host UI polls this to
  // update its overlay — the lib doesn't touch DOM for perf display.
  // v0.28 — Mobile mode. Auto-detected via matchMedia('(pointer: coarse)')
  // but the caller can override via options.mobile, and the host UI can
  // flip at runtime here. When on, three palm-rejection heuristics gate
  // pointer events: contact-size, pen-then-touch lockout, and first-
  // touch-wins. See the POINTER PAINTING block for details.
  mobile(v) {
    if (v === undefined) return _mobileMode;
    _mobileMode = !!v;
    // If a stroke is in progress when mode changes, reset state so the
    // next pointer event starts cleanly without dangling active IDs.
    if (_isPainting) {
      _isPainting = false;
      _activePointerId = null;
      _activePointerType = null;
      _pendingPaintX = null;
      _pendingPaintY = null;
    }
    return _mobileMode;
  },
  // One-time device detection latched at create(). Useful for "is this
  // a touch device?" without forcing mobile mode to be on.
  mobileDetected() { return _mobileDetected; },

  // v0.34 — Cursor preview toggle. The lib doesn't render the cursor
  // element itself (the host wiring owns the DOM), but the canonical
  // "is the cursor preview on?" boolean lives here so it can be set
  // via { cursorPreview } in create-options and flipped via this
  // setter. The wiring listens for the 'cursorpreviewchange' event on
  // targetEl to enable/disable its cursor element.
  cursorPreview(v) {
    if (v === undefined) return _cursorPreview;
    _cursorPreview = !!v;
    targetEl.dispatchEvent(new CustomEvent('cursorpreviewchange', {
      detail: { enabled: _cursorPreview },
    }));
    return _cursorPreview;
  },

  // v0.37 — Gouache mode. Swaps the active pigment set between
  // PIGMENTS_TRANSPARENT (default, Curtis et al. 1997 watercolor K/S
  // values) and PIGMENTS_OPAQUE (high-scattering gouache values that
  // render vibrantly on dark paper). Toggling at runtime affects both
  // new strokes AND the rendering of already-deposited pigment — the
  // K/S values are read per-frame by the compositor, so existing
  // pigment in the d[]/g[] arrays just looks different under the new
  // physics. Useful: pair with paperColor() to switch between light-
  // mode (transparent on cream) and dark-mode (gouache on near-black)
  // themes without resetting the canvas. Dispatches 'gouachechange'
  // on targetEl so swatches and any host UI can refresh.
  //
  // v0.51 — Now accepts a third value 'auto', which LERPs between
  // the two pigment sets based on the perceptual luminance of the
  // current paper color. paperColor() changes while in auto mode
  // re-LERP automatically. Reading gouacheMode() returns one of
  // false | true | 'auto'. Also accepts a number in [0, 1] for direct
  // manual control of the LERP amount (escape hatch for testing /
  // procedural use); reading returns the boolean / 'auto' state, not
  // the numeric.
  gouacheMode(v) {
    if (v === undefined) return _gouacheMode;
    let next;
    if (v === 'auto') next = 'auto';
    else if (typeof v === 'number') {
      // Direct LERP. Recompute and set PIGMENTS to the LERPed array.
      // Treated as a transient/manual override — reading gouacheMode
      // back doesn't return the number, it returns the closest of
      // false/true/'auto' for the reader's sanity. The lerp value
      // itself is queryable via gouacheLerpAmount().
      next = v <= 0 ? false : v >= 1 ? true : 'auto';
      if (next === 'auto') _recomputeLerpedPigments(v);
    }
    else next = !!v;
    if (next === _gouacheMode) {
      // Special case: gouacheMode('auto') called while already in auto
      // should still re-LERP (paper may have changed and the caller
      // wants an explicit refresh). Skip the early return.
      if (next !== 'auto') return _gouacheMode;
    }
    _gouacheMode = next;
    if (next === 'auto') {
      // Re-LERP from current paper darkness unless a numeric override
      // already set the value above.
      if (typeof v !== 'number') _recomputeLerpedPigments(_paperDarkness());
      PIGMENTS = PIGMENTS_LERPED;
    } else {
      PIGMENTS = next ? PIGMENTS_OPAQUE : PIGMENTS_TRANSPARENT;
    }
    // Force a full re-render so already-deposited pigment recomposites
    // under the new K/S values. The CPU/GPU render paths read
    // PIGMENTS[i] at function entry every frame, so no caches to
    // invalidate — just need the next render to be full-canvas, not
    // active-rect-only.
    setActiveRectFull();
    if (typeof useGPU !== 'undefined' && useGPU && gpuAvailable) {
      gpuRender();
    } else {
      render(true);
    }
    targetEl.dispatchEvent(new CustomEvent('gouachechange', {
      detail: { enabled: _gouacheMode, lerpAmount: _gouacheLerpT },
    }));
    return _gouacheMode;
  },

  // v0.51 — Current LERP amount between transparent (0) and opaque (1)
  // pigments. Reads the value most recently used to compute
  // PIGMENTS_LERPED. While in auto mode this is the paper-darkness-
  // driven value; with explicit gouacheMode(0..1) calls it reflects
  // that value. Useful for UIs that want to display "how gouache-y"
  // the painting currently is.
  gouacheLerpAmount() {
    return _gouacheLerpT;
  },

  // v0.57 — Advection mode: 'standard' | 'clamp' | 'substep'. See
  // _advectionMode comment for what each does. Called with no arg
  // returns current mode; called with a string sets it (and validates).
  // Also returns the most recent substep count via .lastSubsteps when
  // current mode is 'substep' so the UI can show how hard the sim is
  // working post-deluge.
  advectionMode(v) {
    if (v === undefined) return _advectionMode;
    if (v !== 'standard' && v !== 'clamp' && v !== 'substep' && v !== 'semilag') {
      console.warn('advectionMode: invalid value', v,
        '— expected standard | clamp | substep | semilag');
      return _advectionMode;
    }
    _advectionMode = v;
    return _advectionMode;
  },
  // Most recent substep count from movePigment. 1 when mode is
  // 'standard' or 'clamp', or when 'substep' mode found CFL ≤ 1.
  // Higher right after a deluge while velocities are still large.
  advectionLastSubsteps() { return _lastAdvectionSubsteps; },

  perf(v) {
    if (v === undefined) return perfEnabled;
    perfActivate(!!v);
    return perfEnabled;
  },
  perfMetrics() { return perfMetrics(); },

  // Coordinate helpers
  grid: {
    get width()  { return GW; },
    get height() { return GH; },
  },
  toGrid(displayX, displayY) {
    // v0.94 — return shape changed from {x, y} to {gx, gy} to match
    // the lib's internal _clientToGrid convention and paintAt's
    // (gx, gy, ...) parameter names. Disambiguates grid coords from
    // display coords at call sites: `wc.toGrid(x, y).gx` reads as
    // unambiguously grid, where the old `.x` could be mistaken for
    // a display-pixel x. The .d.ts and playground docs example were
    // already documenting {gx, gy}; this brings the lib in line with
    // them rather than the other way around.
    const rect = canvas.getBoundingClientRect();
    return {
      gx: (displayX - rect.left) * (GW / rect.width),
      gy: (displayY - rect.top)  * (GH / rect.height),
    };
  },

  // Toggles
  edgeDarkening(v) {
    if (v !== undefined) edgeDarkeningEnabled = !!v;
    return edgeDarkeningEnabled;
  },
  pauseDrying(v) {
    if (v !== undefined) dryingPaused = !!v;
    return dryingPaused;
  },
  autoDryBackground(v) {
    if (v !== undefined) autoDryBackgroundOn = !!v;
    return autoDryBackgroundOn;
  },
  fadePainting(v) {
    if (v !== undefined) {
      const wasEnabled = fadeEnabled;
      fadeEnabled = !!v;
      // v0.50 — When fade transitions off→on, ensure the spring's
      // per-cell velocity arrays exist (lazy alloc on first enable)
      // and zero them so the spring starts every cell at rest. This
      // prevents stale velocities from a previous fade session
      // suddenly pulling currently-deposited paint toward zero when
      // the user re-enables fade after disabling it.
      if (fadeEnabled && !wasEnabled) {
        ensureFadeVelocityArrays();
        resetFadeVelocityArrays();
      }
    }
    return fadeEnabled;
  },
  transparent(v) {
    if (v !== undefined) transparentBg = !!v;
    return transparentBg;
  },
  // v0.89 — Host-element background. Accepts any valid CSS
  // background value: a solid color, linear-gradient(...),
  // radial-gradient(...), url(...), or any combination thereof.
  // Auto-enables transparent canvas mode so the background shows
  // through pigment-less areas. Pass null or '' to clear.
  //
  // Examples:
  //   wc.background('linear-gradient(180deg, #fef3c7, #ddd6fe)')
  //   wc.background('radial-gradient(circle at 30% 30%, #fef3c7, #f97316 80%)')
  //   wc.background('#1a1a1a')
  //   wc.background(null)   // clear, return to default paper
  //
  // The painting itself is unaffected — pigment is still composited
  // via Kubelka-Munk against the lib's internal paperColor. The
  // gradient only shows through in regions where alpha is below
  // ALPHA_FULL_AT (i.e., paper-thin or unpainted areas).
  background(value) {
    if (value === undefined) {
      return targetEl.style.background || '';
    }
    if (value === null || value === '') {
      targetEl.style.background = '';
      return '';
    }
    targetEl.style.background = String(value);
    // Auto-enable transparent canvas so the background can show
    // through. The caller can still flip transparent() back off
    // afterward if they want the gradient hidden by paper.
    transparentBg = true;
    if (useGPU) gpuRender(); else render(true);
    return targetEl.style.background;
  },
  // v2 — Canvas-scale override. Default is auto-computed from canvas
  // size; pass a number to override, or undefined to read current value.
  canvasScale(v) {
    if (v !== undefined && v > 0) _canvasScale = +v;
    return _canvasScale;
  },
  // v2 — Paint/water load multipliers (per-brush deposition strength).
  paintLoad(v) {
    // v0.60 — lowered min clamp from 0.1 to 0.001 so the slider can
    // approach effectively-zero deposit ("dry brush" levels where a
    // 200 px stamp is visually indistinguishable from paper). Was 0.1
    // historically because the slider couldn't go below 0.1 anyway;
    // now exposed.
    if (v !== undefined) paintLoadMult = Math.max(0.001, +v);
    return paintLoadMult;
  },
  waterLoad(v) {
    if (v !== undefined) waterLoadMult = Math.max(0.2, +v);
    return waterLoadMult;
  },

  // v0.28 — Brush dynamics. Three knobs that previously lived as
  // hardcoded constants in the pointer-event handlers and SVG tracer.
  //
  // pressure(v) — base stamp strength, 0..1. Default 0.7. Lower
  //   values dim every stamp (lighter brush); higher saturate faster.
  //   Applied uniformly across the stroke (set at pointer-down).
  pressure(v) {
    if (v === undefined) return _brushPressure;
    _brushPressure = Math.max(0, Math.min(1, +v));
    return _brushPressure;
  },
  // flow(v) — stamp spacing along a drag, as a fraction of brush
  //   radius. Default 0.4. Smaller = more stamps = smoother strokes
  //   (and more sim cost). Larger = fewer stamps = dotted/dabbed look.
  //   Range clamped to 0.05..2.0 to prevent pathological behavior.
  flow(v) {
    if (v === undefined) return _brushFlow;
    _brushFlow = Math.max(0.05, Math.min(2.0, +v));
    return _brushFlow;
  },
  // usePointerPressure(v) — when true, multiplies stamp strength by
  //   PointerEvent.pressure. Useful for stylus + tablet users; mostly
  //   harmless for mouse since the resulting strength is captured at
  //   pointer-down and held for the rest of the stroke. Default false
  //   because mouse browsers commonly report 0.5 (neutral) — turning
  //   this on without a stylus would shift the base by *1.0 (no change)
  //   but the variability per-event would create unintended dimming.
  usePointerPressure(v) {
    if (v === undefined) return _usePointerPressure;
    _usePointerPressure = !!v;
    return _usePointerPressure;
  },
  // continuousFlow(v) — when on, holding the pointer in place keeps
  //   pumping pigment/water at a reduced rate (CONTINUOUS_FLOW_STRENGTH
  //   = 0.12). Mimics how a real brush bleeds when held still on wet
  //   paper. Default on.
  continuousFlow(v) {
    if (v === undefined) return _continuousFlow;
    _continuousFlow = !!v;
    return _continuousFlow;
  },

  // v2 — PNG export. Returns a data URL the caller can use directly
  // (e.g. assign to an <a> href + download, or open in a new window).
  exportPNG(opts) {
    opts = opts || {};
    // Force a full re-render so the entire canvas is fresh in the
    // active buffer (active-rect optimization only updates dirty cells,
    // which is fine for live display but leaves stale rgba beyond the
    // rect on the rendered canvas — most of the time it matches, but
    // export deserves the safety of a forced full pass).
    render(true);
    // v0.64 — Composite paper color underneath unless `transparent` is
    // requested. The painting canvas has alpha = 0 in unpainted regions
    // (K-M produces semi-transparent edges and clean paper renders as
    // fully transparent so the body background shows through). For PNG
    // export the user expects a self-contained image: paper color
    // visible everywhere except where pigment dries it darker. We
    // build a fresh canvas, fill it with paper color, then draw the
    // sim canvas on top.
    const useTransparent = opts.transparent !== undefined
      ? !!opts.transparent
      : transparentBg;
    let exportCanvas;
    if (useTransparent) {
      exportCanvas = canvas;
    } else {
      exportCanvas = document.createElement('canvas');
      exportCanvas.width = canvas.width;
      exportCanvas.height = canvas.height;
      const ectx = exportCanvas.getContext('2d');
      // Paper fill — base RGB at full opacity. Matches the visible
      // paper color on screen (the body background CSS uses the same
      // values via paperColor()).
      const pr = Math.round(PAPER_R_BASE * 255);
      const pg = Math.round(PAPER_G_BASE * 255);
      const pb = Math.round(PAPER_B_BASE * 255);
      ectx.fillStyle = 'rgb(' + pr + ',' + pg + ',' + pb + ')';
      ectx.fillRect(0, 0, exportCanvas.width, exportCanvas.height);
      ectx.drawImage(canvas, 0, 0);
    }
    const mime = opts.mimeType || 'image/png';
    // v0.64 — If caller passes `asBlob: true`, return a Promise<Blob>
    // via toBlob — more reliable than data URL for large canvases
    // (some browsers truncate / fail silently on data URLs over a
    // few MB). Default stays the data-URL form for back-compat.
    if (opts.asBlob) {
      return new Promise((resolve, reject) => {
        exportCanvas.toBlob((blob) => {
          if (blob) resolve(blob);
          else reject(new Error('canvas.toBlob returned null — canvas may be tainted or too large'));
        }, mime, opts.quality);
      });
    }
    return exportCanvas.toDataURL(mime, opts.quality);
  },

  // State snapshot
  state() {
    return {
      gridWidth: GW, gridHeight: GH,
      displayWidth: DISPLAY_W, displayHeight: DISPLAY_H,
      brushSize: brushSize,
      pigment: currentPigment,
      canvasScale: _canvasScale,
      animationMode: typeof animationMode !== 'undefined' ? animationMode : 'off',
      visualizationMode: typeof visualizationMode !== 'undefined' ? visualizationMode : 'off',
      backgroundRunning: typeof timeWash !== 'undefined' && timeWash !== null,
      edgeDarkening: edgeDarkeningEnabled,
      fadePainting: fadeEnabled,
      pauseDrying: typeof dryingPaused !== 'undefined' ? dryingPaused : false,
      gouacheMode: _gouacheMode,
    };
  },

  // v0.52 — Preset save/load. Captures every user-controllable setting
  // (brush, paper, evaporation, modes, fade, animation, etc.) into a
  // plain serializable object that can be JSON-stringified, saved to
  // localStorage, shared between sessions, posted to a gist, etc.
  //
  // Excludes: the actual painted artwork (d[]/g[] arrays — that's
  // *content*, not settings), cursor state, system-dependent toggles
  // (WebGL, mobile mode), and debug instrumentation (perf overlay).
  //
  // The shape is documented by `version: 1`. Future preset formats
  // can bump the version and applyPreset can migrate forward; v1
  // presets will continue to apply correctly to forward-compatible
  // lib versions (unknown fields are silently ignored).
  getPreset() {
    // Derive evaporation multiplier from the stored rate.
    // setEvaporationMult does evapRate = 0.9988^mult, so:
    //   mult = log(rate) / log(0.9988)
    // Round to avoid tiny float artifacts in serialization.
    let evapMult = Math.log(evaporationRate) / Math.log(0.9988);
    if (!isFinite(evapMult)) evapMult = 1;
    evapMult = Math.round(evapMult * 100) / 100;
    return {
      version: 1,
      // Brush
      brushSize:     brushSize,
      pigment:       currentPigment,
      pressure:      _brushPressure,
      flow:          _brushFlow,
      paintLoad:     paintLoadMult,
      waterLoad:     waterLoadMult,
      // Paper / sim
      paperColor:    { r: PAPER_R_BASE, g: PAPER_G_BASE, b: PAPER_B_BASE },
      evaporation:   evapMult,
      gouacheMode:   _gouacheMode,
      edgeDarkening: edgeDarkeningEnabled,
      pauseDrying:   dryingPaused,
      transparent:   transparentBg,
      continuousFlow: _continuousFlow,
      // Fade
      fadePainting:   fadeEnabled,
      fadeHalfLifeMs: fadeHalfLifeMs,
      // Animation / visualization
      animationMode:     typeof animationMode !== 'undefined' ? animationMode : 'off',
      visualizationMode: typeof visualizationMode !== 'undefined' ? visualizationMode : 'off',
      // v0.57 — Advection mode. 'standard' is the default for back-
      // compat; presets saved before v0.57 won't carry this field
      // and will fall back to whatever the current instance has set.
      advectionMode:     _advectionMode,
    };
  },

  // applyPreset(obj) — restore settings from a preset object. Each
  // field is applied via the existing public API method, so all the
  // side effects (events, re-LERPs, re-renders, swatch refreshes)
  // fire naturally. Missing fields are skipped; unknown fields are
  // ignored. Order matters in a few cases:
  //   - paperColor before gouacheMode, so auto-LERP uses the new paper
  //   - animation/visualization last, since they may inject state
  //     that depends on other settings (paper color, pigment choice)
  // After all fields are applied, dispatches 'presetapplied' on the
  // host element so wiring can update sliders, swatches, toggles,
  // etc. to match the new state.
  applyPreset(p) {
    if (!p || typeof p !== 'object') {
      throw new Error('applyPreset: expected a preset object');
    }
    if (p.version !== undefined && p.version > 1) {
      console.warn('applyPreset: preset version', p.version,
        'is newer than this lib understands (v1). Applying best-effort.');
    }
    // Paper first — affects gouacheMode('auto') LERP downstream.
    if (p.paperColor && typeof p.paperColor === 'object') {
      api.paperColor(p.paperColor.r, p.paperColor.g, p.paperColor.b);
    }
    if (p.evaporation !== undefined)    api.evaporation(p.evaporation);
    if (p.gouacheMode !== undefined)    api.gouacheMode(p.gouacheMode);
    // Brush
    if (p.brushSize !== undefined)      api.brushSize(p.brushSize);
    if (p.pigment !== undefined)        api.pigment(p.pigment);
    if (p.pressure !== undefined)       api.pressure(p.pressure);
    if (p.flow !== undefined)           api.flow(p.flow);
    if (p.paintLoad !== undefined)      api.paintLoad(p.paintLoad);
    if (p.waterLoad !== undefined)      api.waterLoad(p.waterLoad);
    // Sim toggles
    if (p.edgeDarkening !== undefined)  api.edgeDarkening(p.edgeDarkening);
    if (p.pauseDrying !== undefined)    api.pauseDrying(p.pauseDrying);
    if (p.transparent !== undefined)    api.transparent(p.transparent);
    if (p.continuousFlow !== undefined) api.continuousFlow(p.continuousFlow);
    // Fade
    if (p.fadeHalfLifeMs !== undefined) api.fadeHalfLife(p.fadeHalfLifeMs);
    if (p.fadePainting !== undefined)   api.fadePainting(p.fadePainting);
    // Animation / visualization last
    if (p.animationMode !== undefined)
      api.setAnimation(p.animationMode === 'off' ? null : p.animationMode);
    if (p.visualizationMode !== undefined)
      api.setVisualization(p.visualizationMode === 'off' ? null : p.visualizationMode);
    // v0.57 — advection mode. Idempotent; safe to skip if absent.
    if (p.advectionMode !== undefined) api.advectionMode(p.advectionMode);
    targetEl.dispatchEvent(new CustomEvent('presetapplied', { detail: { preset: p } }));
    return api;
  },

  // Teardown
  destroy() {
    if (rafToken !== null) {
      cancelAnimationFrame(rafToken);
      rafToken = null;
    }
    // Remove pointer listeners
    if (_pointerEnabled) {
      canvas.removeEventListener('pointerdown', _onPointerDown);
      canvas.removeEventListener('pointermove', _onPointerMove);
      canvas.removeEventListener('pointerup',   _onPointerUp);
      canvas.removeEventListener('pointercancel', _onPointerUp);
      canvas.removeEventListener('pointerleave',  _onPointerUp);
    }
    if (canvas.parentNode) canvas.parentNode.removeChild(canvas);
  },
};

return api;

}  // end createInstance

// v0.86 — Polyfill `window` reference for non-browser contexts (Node
// without jsdom, Web Workers) so the IIFE doesn't ReferenceError on
// load. The lib's runtime methods (`create()` etc.) still require a
// DOM-shaped target; only the module loading is being made universal
// here.
var _globalRoot = typeof globalThis !== 'undefined' ? globalThis :
                  typeof window     !== 'undefined' ? window :
                  typeof self       !== 'undefined' ? self : {};
_globalRoot.Watercolor = { create: createInstance };
// v0.53 — Brand alias. `Washes` is the user-facing brand for the
// library; `Watercolor` is preserved as the long-standing internal /
// API name. Both refer to the same factory. Choose whichever reads
// better at your call site.
_globalRoot.Washes = _globalRoot.Watercolor;

// Mirror onto window if it exists (browser script-tag use cases).
if (typeof window !== 'undefined' && window !== _globalRoot) {
  window.Watercolor = _globalRoot.Watercolor;
  window.Washes = _globalRoot.Washes;
}

})();

// v0.86 — ESM export. `globalThis.Washes` was populated by the IIFE
// above. Re-export it so consumers can:
//   import { Washes } from 'washes';
//   import Washes from 'washes';
// Both forms point at the same factory.
export const Washes = globalThis.Washes;
export const Watercolor = globalThis.Watercolor;
export default Washes;
